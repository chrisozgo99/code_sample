import firestore from '@react-native-firebase/firestore';
import {Conversation} from '_utils';
var uuid = require('react-native-uuid');

/**
 * This function adds the conversation object to the database (into the messages collection) with all the fields inside the object.
 * It is called when the first message is sent in a conversation and generates an unique id which serves as a reference in the database
 *
 * @param {*} conversation conversation object added as a document to the messages collection in firebase
 */
async function addConversationToDatabase(conversation) {
    conversation._conversationID = uuid.v1();
    await firestore()
        .collection('messages')
        .doc(conversation._conversationID)
        .set(conversation);
}

/**
 * This function updates the conversation document in firebase, finding the document from it's conversationID. The function
 * is primarily used when a message is sent in a conversation, and used once when the conversationID is initially set.
 *
 * @param {*} conversation conversation object that must be updated in database
 */
function updateConversation(conversation) {
    firestore()
        .collection('messages')
        .doc(conversation._conversationID)
        .set(conversation);
}

/**
 * This function is run whenever users update their profile and their first name, last name, or profile picture changes.
 * The function queries all the conversations that the user is involved in, and updates them in one big batch commit.
 *
 * @param {*} user
 * @returns
 */
async function updateConversationDetails(user) {
    const updatingMessages = await firestore()
        .collection('messages')
        .where(
            user._userType === 'trainers'
                ? '_details.trainer.value'
                : '_details.client.value',
            '==',
            user._userID,
        )
        .get();

    const batch = firestore().batch();

    updatingMessages.docs.forEach(documentSnapshot => {
        if (user._userType === 'trainers') {
            batch.update(documentSnapshot._ref, {
                '_details.trainer.label': `${user._name.firstName} ${
                    user._name.lastName
                }`,
                '_details.trainer.profilePic': user._profilePic,
            });
        } else {
            batch.update(documentSnapshot._ref, {
                '_details.client.label': `${user._name.firstName} ${
                    user._name.lastName
                }`,
                '_details.client.profilePic': user._profilePic,
            });
        }
    });
    return batch.commit();
}

/**
 * This function checks if there is already a conversation document in the database created for a certain training video (so
 * that when the player presses message coach on a video page, a new conversation is not created each time if one already
 * exists) using a compound-query (looking at client ID and video details). If a document is found, a new conversation
 * object is created with the correct fields of that document and returned, and if document is not found, null is returned.
 * Then (in second .then()), the user is navigated to the conversation page along with a conversation object, either a new
 * conversation or the object with the same data as the document.
 *
 * @param {*} userID user ID
 * @param {*} video video info (drill, level, module)
 * @param {*} {navigation} navigation that takes page to Conversation page
 * @returns conversation page (with correct conversation object)
 */
async function isConversationInDatabase(details, video, {navigation}) {
    return firestore()
        .collection('messages')
        .where('_details.client.value', '==', details.client.value)
        .where('_video', '==', video)
        .get()
        .then(querySnapshot => {
            if (querySnapshot.docs.length === 1) {
                let doc = querySnapshot.docs[0].data();
                let convo = new Conversation(
                    doc._conversationID,
                    doc._details,
                    doc._messages,
                    doc._video,
                );
                return convo;
            } else {
                return null;
            }
        })
        .then(conversation => {
            if (conversation !== null) {
                navigation.navigate('Conversation', {
                    conversation: conversation,
                });
            } else {
                setTrainerToConversation(details, video);
                conversation = new Conversation(null, details, null, video);
                navigation.navigate('Conversation', {
                    conversation: conversation,
                });
            }
        });
}

/**
 * This function serves to add a reference to a location in AWS storage, in Firebase. The location is a
 * reference to a video message. It also handles the sending of compound messages, that is a message
 * containing text and a video, while still only updating Firebase one time.
 *
 * @param {*} details A map of the player, trainer, and the last time the conversation was updated
 * @param {*} video A map of the training module, level, and drill to which the conversation pertains
 * @param {*} videoMessage A map of the videoMessage, of type Message, containing the reference to AWS
 * @param {*} textMessage An option textMessage to accompany the video message
 * @param {*} {navigation} Allows navigation from within the function
 * @returns
 */
async function addVideoReferenceToConversation(
    details,
    video,
    videoMessage,
    textMessage,
    {navigation},
) {
    return firestore()
        .collection('messages')
        .where('_details.client.value', '==', details.client.value)
        .where('_video', '==', video)
        .get()
        .then(querySnapshot => {
            if (querySnapshot.docs.length === 1) {
                let doc = querySnapshot.docs[0].data();
                let convo = new Conversation(
                    doc._conversationID,
                    doc._details,
                    doc._messages,
                    doc._video,
                );
                return convo;
            } else {
                return null;
            }
        })
        .then(conversation => {
            if (textMessage._content.contents !== undefined) {
                if (conversation !== null) {
                    conversation.addMessageWithoutPushingToDatabase(
                        videoMessage,
                    );
                    return conversation;
                } else {
                    conversation = new Conversation(null, details, null, video);
                    conversation.addMessageWithoutPushingToDatabase(
                        videoMessage,
                    );
                    return conversation;
                }
            } else {
                if (conversation !== null) {
                    conversation.addMessage(videoMessage);
                    return conversation;
                } else {
                    conversation = new Conversation(null, details, null, video);
                    conversation.addMessage(videoMessage);
                    return conversation;
                }
            }
        })
        .then(conversation => {
            if (textMessage._content.contents !== undefined) {
                conversation.addMessageWithoutPushingToDatabase(textMessage);
                updateConversation(conversation);
            }
            navigation.navigate('Conversation', {
                conversation: conversation,
            });
        });
}

/**
 * This function is called from the isConversationInDatabase function only when a conversation does not already exist in the database.
 * It goes to the modules collection in the database and assigns the correct trainer to the conversation details.
 *
 * @param {*} details conversation details
 * @param {*} video conversation's video info (used to get the module)
 * @returns
 */
async function setTrainerToConversation(details, video) {
    return firestore()
        .collection('modules')
        .where('module.name', '==', video.module)
        .get()
        .then(querySnapshot => {
            let arrayOfTrainers = [];
            querySnapshot._docs[0]._data.module.trainers.forEach(trainer => {
                arrayOfTrainers.push(trainer);
                arrayOfTrainers[
                    arrayOfTrainers.length - 1
                ].lastReadMessage = Date.now();
            });
            return arrayOfTrainers;
        })
        .then(trainers => {
            //if Someone has a premium subscription (Use details.client to check) {
            //    Assign them Paul
            //}

            return trainers[Math.floor(Math.random() * trainers.length)];
        });
}

async function updateLastReadMessage(user, conversation) {
    if (user._userType === 'players' || user._userType === 'coaches') {
        await firestore()
            .collection('messages')
            .doc(conversation.conversationID)
            .update({
                '_details.client.lastReadMessage':
                    conversation.details.lastUpdated + 1,
            });
    } else if (user._userType === 'trainers') {
        await firestore()
            .collection('messages')
            .doc(conversation.conversationID)
            .update({
                '_details.trainer.lastReadMessage':
                    conversation.details.lastUpdated + 1,
            });
    }
    return await firestore()
        .collection('messages')
        .doc(conversation.conversationID)
        .get()
        .then(doc => {
            return doc.data();
        });
}

async function updateLastReadMessageInConversation(user, conversation) {
    if (user._userType === 'players' || user._userType === 'coaches') {
        await firestore()
            .collection('messages')
            .doc(conversation._conversationID)
            .update({
                '_details.client.lastReadMessage':
                    conversation._details.lastUpdated + 1,
            });
    } else if (user._userType === 'trainers') {
        await firestore()
            .collection('messages')
            .doc(conversation._conversationID)
            .update({
                '_details.trainer.lastReadMessage':
                    conversation._details.lastUpdated + 1,
            });
    }
    return await firestore()
        .collection('messages')
        .doc(conversation._conversationID)
        .get()
        .then(doc => {
            return doc.data();
        });
}

export {
    addConversationToDatabase,
    updateConversation,
    updateConversationDetails,
    isConversationInDatabase,
    addVideoReferenceToConversation,
    updateLastReadMessage,
    updateLastReadMessageInConversation,
    setTrainerToConversation,
};
