import {firebase} from '@react-native-firebase/app';
import {Alert} from 'react-native';
import storage from '@react-native-firebase/storage';
import {setUserInDatabase} from './db-calls';

/**
 * Function that takes the user image from their mobile device and saves it to
 * Firebase's storage in the cloud. The image is saved as the user's userID and
 * thus each user can only have one profile picture at a time. The user's profile
 * pic attribute in the database then contains a reference to a downloadable url
 * pertaining to the image in storage.
 *
 * @param {*} profilePicPath The local path of the picture the user has chosen
 * @param {*} userID The user's unique user ID
 * @param {*} {navigation} Gives ability to navigate from within the function
 * @param {*} nav Page to which the function should navigate
 */
async function pushImageToStorage(profilePicPath, user, {navigation}, nav) {
    const reference = firebase
        .storage()
        .ref('/images/profile-pics/' + user._userType + '/' + user._userID);
    await reference
        .putFile(profilePicPath)
        .then(async () => {
            user.profilePic = await reference.getDownloadURL();
        })
        .then(() => {
            setUserInDatabase(user);
        })
        .then(() => {
            navigation.navigate(nav, {
                user: user,
            });
        })
        .catch(error => Alert.alert(error));
}

/**
 * Function to edit (or not edit) an already existing profile picture.
 * To account for an unhandled promise exception if the user does not
 * pass in a profilePicPath different than the one already set, profilePicPath
 * can take a value of null, in which case the function will be ignored.
 * In any other case, the picture in storage is updated, as is the reference
 * to that picture in the user object.
 *
 * @param {*} profilePicPath The address in storage of the picture
 * @param {*} user The corresponding user object
 */
async function editImageInStorage(profilePicPath, user) {
    if (profilePicPath !== null) {
        if (
            profilePicPath !==
            'https://firebasestorage.googleapis.com/v0/b/drills-and-skills.appspot.com/o/images%2Fprofile-pics%2Fblank-profile-picture.png?alt=media&token=86e354ea-5008-41e4-b7ba-0f3486b13fb8'
        ) {
            const reference = firebase
                .storage()
                .ref(
                    '/images/profile-pics/' +
                        user._userType +
                        '/' +
                        user._userID,
                );
            await reference
                .putFile(profilePicPath)
                .then(async () => {
                    user.profilePic = await reference.getDownloadURL();
                })
                .catch(error => console.log(error));
        }
    }
}

/**
 * Function that allows the user to use the default profile picture as
 * their profile picture. It saves the reference in the database and then
 * navigates to a page of the user's choice.
 *
 * @param {*} user The user who wants the default profile picture
 * @param {*} {navigation} Gives the ability to navigate from within the functiton
 * @param {*} nav The page to which the function should navigate
 * @returns
 */
async function setDefaultImage(user, {navigation}, nav) {
    return await storage()
        .ref('/images/profile-pics/blank-profile-picture.png')
        .getDownloadURL()
        .then(url => (user.profilePic = url))
        .then(() => {
            setUserInDatabase(user);
        })
        .then(() => {
            navigation.navigate(nav, {
                user: user,
            });
        })
        .catch(error => console.log(error));
}

export {pushImageToStorage, editImageInStorage, setDefaultImage};
