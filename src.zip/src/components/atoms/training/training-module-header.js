import React from 'react';
import {View, Text, TouchableOpacity} from 'react-native';

function TrainingModuleHeader(props) {
    return (
        <TouchableOpacity
            style={{
                justifyContent: 'center',
                alignItems: 'center',
                paddingVertical: '15%',
                margin: '5%',
                backgroundColor: 'skyblue',
                borderRadius: 15,
            }}
            onPress={props.onPress}>
            <View>
                <Text style={{fontSize: 26}}>{props.title}</Text>
            </View>
        </TouchableOpacity>
    );
}

export default TrainingModuleHeader;
