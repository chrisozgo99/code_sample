/* eslint-disable react-native/no-inline-styles */
import React from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import {TouchableOpacityPNG} from '_atoms';

function TrainingDrill(props) {
    return (
        <View
            style={{
                width: 252,
                height: 172,
                marginRight: 15,
                marginLeft: 15,
                marginTop: 15,
                marginBottom: 15,
                borderRadius: 25,
                backgroundColor: '#e14821',
            }}>
            <TouchableOpacity onPress={props.onPressVideoThumbnail}>
                <TouchableOpacityPNG
                    png={props.videoThumbnail}
                    touchableOpacityStyle={props.touchableOpacityStyle}
                    imageStyle={props.imageStyle}
                    onPress={props.onPressVideoThumbnail}
                />
                <View
                    style={{
                        position: 'absolute',
                    }}>
                    <Text
                        style={{
                            paddingHorizontal: 25,
                            paddingTop: 106,
                            fontFamily: 'AmericanAuto-Bold',
                            fontSize: 25,
                            color: 'white',
                        }}>
                        {props.drill}
                    </Text>
                </View>
            </TouchableOpacity>
        </View>
    );
}

export default TrainingDrill;
