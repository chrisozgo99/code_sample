import React from 'react';
import {View, Text} from 'react-native';
import {TouchableOpacityPNG} from '_atoms';

function TrainingModuleBox(props) {
    return (
        <View>
            <TouchableOpacityPNG
                png={props.modulePNG}
                onPress={props.moduleOnPress}
                touchableOpacityStyle={props.touchableOpacityStyle}
                imageStyle={props.imageStyle}
            />
            <View style={{position: 'absolute'}}>
                <Text style={props.moduleTitleStyle}>{props.title}</Text>
            </View>
        </View>
    );
}

export default TrainingModuleBox;
