/* eslint-disable react-native/no-inline-styles */
import React from 'react';
import {SafeAreaView, View} from 'react-native';
import {TouchableOpacityButton} from '_atoms';

function VideoButtons(props) {
    return (
        <SafeAreaView
            style={{
                flex: 1,
                width: '100%',
                position: 'absolute',
                bottom: 0,
                marginBottom: '5%',
                flexDirection: 'row',
                justifyContent: 'space-evenly',
            }}>
            <View
                style={{
                    flex: 1 / 3,
                    marginTop: '2%',
                    alignItems: 'center',
                }}>
                <TouchableOpacityButton
                    viewStyles={{
                        flex: 1,
                        alignItems: 'center',
                        justifyContent: 'center',
                    }}
                    textStyles={{
                        fontFamily: 'AmericanAuto-Regular',
                        fontSize: 20,
                        color: 'white',
                        textAlign: 'center',
                    }}
                    text={props.leftButton}
                    onPress={props.onPressLeftButton}
                />
            </View>
            <View
                style={{
                    flex: 1 / 3,
                    alignItems: 'center',
                    justifyContent: 'center',
                    margin: 0,
                }}>
                {props.recordButton}
            </View>
            <View
                style={{
                    flex: 1 / 3,
                    alignItems: 'center',
                }}>
                {props.rightButton}
            </View>
        </SafeAreaView>
    );
}

export default VideoButtons;
