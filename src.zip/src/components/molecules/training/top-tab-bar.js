/* eslint-disable react-native/no-inline-styles */
import React, {useState} from 'react';
import {View, Text} from 'react-native';
import {TouchableOpacityButton} from '_atoms';

function TopTabBar(props) {
    return (
        <View
            style={{
                height: 36,
                width: '100%',
                borderRadius: 20,
                flexDirection: 'row',
                borderColor: '#E14821',
                borderWidth: 2,
                marginVertical: 20,
            }}>
            <View
                style={{
                    flex: 1 / 3,
                    alignItems: 'center',
                    justifyContent: 'center',
                    margin: 0,
                    backgroundColor: props.training ? '#E14821' : 'white',
                    borderRadius: 20,
                }}>
                <TouchableOpacityButton
                    onPress={() => props.navigation.navigate('TrainingModules')}
                    text="Training"
                    touchableOpacityStyles={{
                        height: '100%',
                        width: '100%',
                        alignItems: 'center',
                        justifyContent: 'center',
                    }}
                    textStyles={{
                        color: props.training ? 'white' : 'black',
                        fontFamily: 'AmericanAuto-Bold',
                        paddingTop: 4,
                        paddingRight: 5,
                    }}
                />
            </View>
            <View
                style={{
                    flex: 1 / 3,
                    alignItems: 'center',
                    justifyContent: 'center',
                    margin: 0,
                    backgroundColor: props.extra ? '#E14821' : 'white',
                    borderRadius: 20,
                }}>
                <TouchableOpacityButton
                    onPress={() => props.navigation.navigate('Extra')}
                    text="Tips"
                    touchableOpacityStyles={{
                        height: '100%',
                        width: '100%',
                        alignItems: 'center',
                        justifyContent: 'center',
                    }}
                    textStyles={{
                        color: props.extra ? 'white' : 'black',
                        fontFamily: 'AmericanAuto-Bold',
                        paddingTop: 4,
                    }}
                />
            </View>
            <View
                style={{
                    flex: 1 / 3,
                    alignItems: 'center',
                    justifyContent: 'center',
                    backgroundColor: props.about ? '#E14821' : 'white',
                    borderRadius: 20,
                }}>
                <TouchableOpacityButton
                    onPress={() => props.navigation.navigate('About')}
                    text="About"
                    touchableOpacityStyles={{
                        height: '100%',
                        width: '100%',
                        alignItems: 'center',
                        justifyContent: 'center',
                    }}
                    textStyles={{
                        color: props.about ? 'white' : 'black',
                        fontFamily: 'AmericanAuto-Bold',
                        paddingTop: 4,
                        paddingLeft: 5,
                    }}
                />
            </View>
        </View>
    );
}

export default TopTabBar;
