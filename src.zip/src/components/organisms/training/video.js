/* eslint-disable prettier/prettier */
import React from 'react';
import {SafeAreaView, View, Text} from 'react-native';
import {TouchableOpacitySVG, VideoPlayer} from '_atoms';

function Video(props) {
    var bottomText = (
        <View style={props.styles.buttonsView}>
            <View style={props.styles.requestVideoReviewView}>
                <TouchableOpacitySVG
                    svg={props.requestVideoReview}
                    onPress={props.onPressRequestVideoReview}
                />
            </View>
            <View style={props.styles.sendMessageView}>
                <TouchableOpacitySVG
                    svg={props.sendMessage}
                    onPress={props.onPressSendMessage}
                />
            </View>
        </View>
    );

    if (props.user._userType === 'coaches') {
        bottomText = (
            <View style={props.styles.buttonsView}>
                <View style={props.styles.sendMessageView}>
                    <TouchableOpacitySVG
                        svg={props.sendMessage}
                        onPress={props.onPressSendMessage}
                    />
                </View>
            </View>
        );
    }

    if (props.user._userType === 'trainers') {
        bottomText = (
            <View style={props.styles.guidelinesView}>
                <View style={props.styles.guidelinesTitleView}>
                    <Text style={props.styles.descriptionTitle}>Guidelines</Text>
                </View>
                <View style={props.styles.descriptionTitleView}>
                    <Text style={props.styles.description}>{props.guidelines}</Text>
                </View>
            </View>
        );
    }

    return (
        <SafeAreaView style={props.styles.topView}>
            <View style={props.styles.backButtonView}>
                <TouchableOpacitySVG
                    svg={props.back}
                    onPress={props.onPressBack}
                />
            </View>
            <View style={props.styles.titleAndSubtitleView}>
                <View style={props.styles.titleView}>
                    <Text style={props.styles.title}>{props.title}</Text>
                </View>
                <View style={props.styles.subtitleView}>
                    <Text style={props.styles.subtitle}>{props.subtitle}</Text>
                </View>
            </View>
            <View style={props.styles.videoView}>
                <VideoPlayer
                    height={props.height}
                    width={props.width}
                    source={props.source}
                    // playback={props.playback}
                />
            </View>
            <View style={props.styles.descriptionAndTitleView}>
                <View style={props.styles.descriptionTitleView}>
                    <Text style={props.styles.descriptionTitle}>
                        Description
                    </Text>
                </View>
                <View style={props.styles.descriptionView}>
                    <Text style={props.styles.description}>
                        {props.description}
                    </Text>
                </View>
            </View>
            {bottomText}
        </SafeAreaView>
    );
}

export default Video;
