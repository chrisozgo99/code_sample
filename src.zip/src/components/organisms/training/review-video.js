/* eslint-disable react-native/no-inline-styles */
import React from 'react';
import {
    SafeAreaView,
    View,
    Text,
    TouchableOpacity,
    KeyboardAvoidingView,
    ScrollView,
    Platform,
} from 'react-native';
import {TouchableOpacitySVG, ViewAndTextInput} from '_atoms';
import Video from 'react-native-video';

function ReviewVideo(props) {
    return (
        <KeyboardAvoidingView
            style={{flex: 1}}
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
            <SafeAreaView style={props.styles.topView}>
                <View style={props.styles.backButtonView}>
                    <TouchableOpacitySVG
                        buttonStyles={props.styles.backButton}
                        onPress={props.backOnPress}
                        svg={props.back}
                    />
                </View>
                <View style={props.styles.titleView}>
                    <Text style={props.styles.title}>{props.title}</Text>
                </View>
                <View style={props.styles.videoView}>
                    <Video
                        style={props.styles.video}
                        source={{uri: props.uri}}
                        controls={true}
                        paused={true}
                        playWhenInactive={true}
                        resizeMode="contain"
                    />
                </View>
                <TouchableOpacity
                    style={props.styles.touchableOpacityDownload}
                    onPress={props.onPressDownload}>
                    <View style={props.styles.downloadButtonView}>
                        <Text
                            style={{
                                color: 'white',
                                paddingRight: '4%',
                                fontWeight: 'bold',
                                fontSize: 20,
                            }}>
                            {props.download}
                        </Text>
                        {props.downloadSVG}
                    </View>
                </TouchableOpacity>
                <ViewAndTextInput
                    textInputViewStyles={props.styles.messageView}
                    textInputStyles={props.styles.message}
                    attributes={props.attributes}
                />
                <SafeAreaView style={props.styles.sendVideoView}>
                    <TouchableOpacitySVG
                        buttonStyles={props.styles.sendVideoButton}
                        onPress={props.onPressSendVideo}
                        svg={props.sendVideo}
                    />
                </SafeAreaView>
            </SafeAreaView>
        </KeyboardAvoidingView>
    );
}

export default ReviewVideo;
