import React from 'react';
import {SafeAreaView, View, Text, Linking} from 'react-native';
import {TouchableOpacitySVG} from '_atoms';
import {TopTabBar} from '_molecules';

function About(props) {
    const socialMediaIcons = props.icons.map(icon => {
        return (
            <View style={{margin: '3%'}} key={icon.link}>
                <TouchableOpacitySVG
                    svg={icon.svg}
                    onPress={() => Linking.openURL(icon.link)}
                    buttonStyles={props.styles.socialMediaIcons}
                />
            </View>
        );
    });

    return (
        <View style={props.styles.topView}>
            <View style={props.styles.titleView}>
                <Text style={props.styles.title}>{props.title}</Text>
            </View>
            <TopTabBar
                navigation={props.navigation}
                training={false}
                extra={false}
                about={true}
            />
            <View style={props.styles.contentView}>
                <View style={props.styles.messageView}>
                    <Text style={props.styles.message}>{props.message}</Text>
                </View>
            </View>
            <View style={props.styles.socialMediaIconsView}>
                {socialMediaIcons}
            </View>
        </View>
    );
}

export default About;
