import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
    topView: {
        backgroundColor: 'white',
        height: '100%',
    },
    headerView: {},
    titleText: {
        fontSize: 50,
        textAlign: 'left',
        fontFamily: 'AmericanAuto-Bold',
        marginTop: '25%',
        marginLeft: '10%',
    },
    trainingModuleBoxView: {
        height: 200,
        width: '80%',
        marginHorizontal: '10%',
        marginVertical: '3%',
        borderRadius: 32,
        backgroundColor: '#e14821',
    },
    touchableOpacityPNG: {
        justifyContent: 'center',
        alignItems: 'center',
        paddingVertical: '15%',
        backgroundColor: '#e14821',
        borderRadius: 32,
        height: '100%',
        width: '100%',
    },
    imagePNG: {
        height: 200,
        width: '100%',
        resizeMode: 'cover',
        borderRadius: 32,
    },
    moduleTitle: {
        paddingHorizontal: 25,
        paddingTop: 125,
        fontFamily: 'AmericanAuto-Bold',
        fontSize: 25,
        color: 'white',
    },
    flatListView: {
        height: '78%',
    },
});

export default styles;
