import React from 'react';
import {View, ActivityIndicator, StyleSheet} from 'react-native';
import {TouchableOpacitySVG, VideoNotch} from '_atoms';
import {VideoButtons} from '_molecules';
import {RNCamera} from 'react-native-camera';
import ImagePicker from 'react-native-image-picker';

import Record from '_assets/images/app/training/record-video.svg';
import Recording from '_assets/images/app/training/recording-video.svg';
import FlipCamera from '_assets/images/app/training/flip-camera.svg';
import Cancel from '_assets/images/white-back.svg';

var increment;
class RecordVideoScreen extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            camera: RNCamera.Constants.Type.front,
            secondsElapsed: 0,
            recording: false,
            processing: false,
            cancelled: false,
            uri: null,
        };
    }

    render() {
        const videoInfo = (
            this.props.navigation.state.params.videoInfo.module +
            this.props.navigation.state.params.videoInfo.level +
            this.props.navigation.state.params.videoInfo.drill
        ).replace(/\s/g, '');

        console.log(this.props.navigation.state.params);

        const {recording, processing} = this.state;

        let leftButton = 'Import';

        let recordButton = (
            <TouchableOpacitySVG
                svg={<Record />}
                onPress={() => {
                    this.startRecording();
                }}
            />
        );

        let rightButton = (
            <TouchableOpacitySVG
                buttonStyles={styles.flipCamera}
                svg={<FlipCamera />}
                onPress={() =>
                    this.setState({
                        camera:
                            this.state.camera === RNCamera.Constants.Type.back
                                ? RNCamera.Constants.Type.front
                                : RNCamera.Constants.Type.back,
                        secondsElapsed: 0,
                    })
                }
            />
        );

        if (recording) {
            recordButton = (
                <TouchableOpacitySVG
                    svg={<Recording />}
                    onPress={() => {
                        this.stopRecording();
                        if (this.state.uri !== null) {
                            setTimeout(() => {
                                this.props.navigation.navigate('ReviewVideo', {
                                    file: {
                                        uri: this.state.uri,
                                        name:
                                            videoInfo +
                                            new Date().getTime().toString(),
                                        type: 'video/mp4',
                                    },
                                    video: this.props.navigation.state.params
                                        .videoInfo,
                                    details: this.props.navigation.state.params
                                        .details,
                                });
                            }, 1000);
                        } else {
                            clearInterval(increment);
                            this.setState({
                                recording: false,
                                secondsElapsed: 0,
                            });
                            this.camera.stopRecording();
                        }
                    }}
                />
            );

            leftButton = `${Math.floor(
                this.state.secondsElapsed / 60,
            ).toString()}:${(
                '0' + (this.state.secondsElapsed % 60).toString()
            ).slice(-2)}`;

            rightButton = (
                <TouchableOpacitySVG
                    buttonStyles={styles.flipCamera}
                    svg={<Cancel />}
                    onPress={() => {
                        this.setState({cancelled: true});
                        this.stopRecording();
                    }}
                />
            );
        }

        if (processing) {
            recordButton = (
                <View style={styles.capture}>
                    <ActivityIndicator animating size={18} />
                </View>
            );
        }

        return (
            <View style={styles.container}>
                <RNCamera
                    ref={ref => {
                        this.camera = ref;
                    }}
                    style={styles.preview}
                    type={this.state.camera}
                    defaultVideoQuality={
                        RNCamera.Constants.VideoQuality['720p']
                    }
                    flashMode={RNCamera.Constants.FlashMode.on}
                    useNativeZoom={true}
                    zoom={0}
                    maxZoom={0.5}
                />
                <VideoNotch
                    videoQuality="720p"
                    frameRate="60FPS"
                    display={this.state.recording ? 'none' : 'flex'}
                    onPressBack={() => {
                        if (
                            this.props.navigation.state.params.videoInfo
                                .module === 'Jumpshot Tutor' ||
                            this.props.navigation.state.params
                                .comingFromConversationPage
                        ) {
                            this.props.navigation.navigate('TrainingModules');
                        } else {
                            this.props.navigation.navigate('Video');
                        }
                    }}
                />
                <VideoButtons
                    leftButton={leftButton}
                    onPressLeftButton={() => {
                        ImagePicker.launchImageLibrary(
                            {
                                mediaType: 'video',
                                durationLimit: 60,
                                allowsEditing: true,
                            },
                            callback => {
                                console.log(callback);
                                if (callback.uri) {
                                    this.props.navigation.navigate(
                                        'ReviewVideo',
                                        {
                                            file: {
                                                uri: callback.uri,
                                                name: (
                                                    this.props.navigation.state
                                                        .params.videoInfo
                                                        .module +
                                                    this.props.navigation.state
                                                        .params.videoInfo
                                                        .level +
                                                    this.props.navigation.state
                                                        .params.videoInfo
                                                        .drill +
                                                    +new Date()
                                                        .getTime()
                                                        .toString()
                                                ).replace(/\s/g, ''),
                                                type: 'video/mp4',
                                            },
                                            video: this.props.navigation.state
                                                .params.videoInfo,
                                            details: this.props.navigation.state
                                                .params.details,
                                        },
                                    );
                                }
                            },
                        );
                    }}
                    recordButton={recordButton}
                    rightButton={rightButton}
                    onPressRightButton={() => {
                        this.setState({
                            camera:
                                this.state.camera ===
                                RNCamera.Constants.Type.back
                                    ? RNCamera.Constants.Type.front
                                    : RNCamera.Constants.Type.back,
                            secondsElapsed: 0,
                        });
                    }}
                />
            </View>
        );
    }

    async startRecording() {
        const videoInfo = (
            this.props.navigation.state.params.videoInfo.module +
            this.props.navigation.state.params.videoInfo.level +
            this.props.navigation.state.params.videoInfo.drill +
            new Date().getTime().toString()
        ).replace(/\s/g, '');
        this.setState({recording: true, cancelled: false});
        increment = setInterval(
            () =>
                this.setState({secondsElapsed: this.state.secondsElapsed + 1}),
            1000,
        );
        const {uri, codec = 'mp4'} = await this.camera.recordAsync({
            quality: RNCamera.Constants.VideoQuality['720p'],
            maxDuration: 59,
        });
        this.setState({recording: false, processing: true});
        const type = 'video/mp4';
        clearInterval(increment);
        this.setState({processing: false, uri: uri, secondsElapsed: 0});
        if (!this.state.cancelled) {
            this.setState({
                recording: false,
                secondsElapsed: 0,
            });
            setTimeout(() => {
                this.props.navigation.navigate('ReviewVideo', {
                    file: {
                        uri: this.state.uri,
                        name: videoInfo,
                        type: type,
                    },
                    video: this.props.navigation.state.params.videoInfo,
                    details: this.props.navigation.state.params.details,
                });
            }, 1000);
        }
    }

    stopRecording() {
        this.setState({secondsElapsed: 0});
        this.camera.stopRecording();
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'column',
        backgroundColor: 'black',
        width: '100%',
    },
    preview: {
        flex: 1,
        height: '100%',
        width: '100%',
        justifyContent: 'space-evenly',
        alignItems: 'center',
    },
    capture: {
        backgroundColor: '#fff',
        borderRadius: 5,
        padding: 15,
        paddingHorizontal: 20,
        alignSelf: 'center',
        margin: 20,
    },
    flipCamera: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
});

export default RecordVideoScreen;
