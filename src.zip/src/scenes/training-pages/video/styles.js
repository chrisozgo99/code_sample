import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
    topView: {backgroundColor: 'black', height: '100%', width: '100%'},
    backButtonView: {
        alignItems: 'flex-end',
        justifyContent: 'flex-end',
        marginRight: '9%',
        marginTop: '2%',
        marginBottom: '6%',
    },
    titleAndSubtitleView: {},
    titleView: {marginLeft: '7%'},
    title: {color: 'white', fontSize: 50, fontFamily: 'AmericanAuto-Bold'},
    subtitleView: {},
    subtitle: {
        color: 'white',
        marginLeft: '7%',
        fontFamily: 'AmericanAuto-Bold',
        fontSize: 20,
    },
    videoView: {
        alignItems: 'center',
        height: '32.5%',
        borderRadius: 30,
    },
    descriptionAndTitleView: {marginHorizontal: '10%', marginTop: '-6%'},
    descriptionTitleView: {},
    descriptionTitle: {
        color: 'white',
        fontFamily: 'AmericanAuto-Bold',
        fontSize: 20,
        marginBottom: '5%',
    },
    descriptionView: {},
    description: {
        color: 'white',
        fontSize: 16,
        fontFamily: 'AmericanAuto-Regular',
    },
    buttonsView: {
        position: 'absolute',
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center',
        width: '100%',
    },
    requestVideoReviewView: {
        width: '100%',
        alignItems: 'center',
        marginBottom: '4%',
    },
    sendMessageView: {width: '100%', alignItems: 'center', marginBottom: '18%'},
    guidelinesView: {
        margin: '10%',
    },
});

export default styles;
