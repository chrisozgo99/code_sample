import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
    topView: {
        //top view styles
        backgroundColor: 'white',
        width: '100%',
        height: '100%',
    },
    headerView: {
        //header view styles
    },
    backButtonView: {
        //back button styling (copied from skill progressions styling)
        alignItems: 'flex-end',
        justifyContent: 'flex-end',
        marginRight: '7%',
        marginTop: '3%',
    },
    title: {
        //title styling (this one is copied and pasted from skill progressions styling)
        fontFamily: 'AmericanAuto-Bold',
        fontSize: 50,
        color: 'black',
        textAlign: 'left',
        marginLeft: '10%',
        lineHeight: 64,
        marginBottom: 20,
    },
    sectionTitleView: {
        backgroundColor: 'white',
    },
    sectionTitle: {
        //section title styling (currently section titles are "level 1" "level 2")
        fontFamily: 'AmericanAuto-Bold',
        fontSize: 25,
        marginLeft: 40,
    },
    touchableOpacityPNG: {
        //style for each individual drill box that takes you to the video page
        height: 172,
        width: 252,
        borderRadius: 25,
        backgroundColor: '#e14821',
        marginRight: '10%',
    },
    imagePNG: {
        //style for image that is on top of the touchable opacity
        height: 172,
        width: 252,
        borderRadius: 25,
        marginRight: '10%',
    },
});

export default styles;
