/* eslint-disable react-native/no-inline-styles */
import React, {useState, useEffect} from 'react';
import {View} from 'react-native';
import {ModuleVideoList} from '_molecules';

import {getTrainingModuleFromDatabase} from '_services';

import Back from '_assets/images/orange-back.svg';

import styles from './styles';

function ModuleScreen({navigation}) {
    const module = navigation.state.params.module;
    const [videos, setVideos] = useState([]);
    const [moduleVideosHasBeenSet, setModuleVideosHasBeenSet] = useState(false);

    useEffect(() => {
        if (!moduleVideosHasBeenSet) {
            getTrainingModuleFromDatabase(module).then(mod => {
                var moduleVideos = [];
                mod.module.videos.forEach(videoLevel => {
                    moduleVideos.push({
                        title: videoLevel.title,
                        data: [videoLevel.data],
                    });
                });
                setVideos(moduleVideos);
                setModuleVideosHasBeenSet(true);
            });
        }
    });

    return (
        <View style={{flex: 1, height: '100%', backgroundColor: 'white'}}>
            <ModuleVideoList
                title={module}
                back={<Back />}
                onPressBack={() => navigation.navigate('TrainingModules')}
                videos={videos}
                navigation={navigation}
                module={module}
                styles={styles}
            />
        </View>
    );
}

export default ModuleScreen;
