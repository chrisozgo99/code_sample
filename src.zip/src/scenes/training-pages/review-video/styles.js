import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
    topView: {
        // backgroundColor: 'black',
        height: '100%',
        width: '100%',
        position: 'relative',
        backgroundColor: 'black',
    },
    backButtonView: {
        flexDirection: 'column-reverse',
        alignItems: 'flex-end',
        marginTop: '2%',
        marginRight: '7%',
        marginBottom: '0%',
    },
    backButton: {},
    titleView: {position: 'relative'},
    title: {
        color: 'white',
        fontSize: 50,
        marginLeft: '10%',
        fontWeight: 'bold',
    },
    videoView: {
        padding: '0%',
        marginBottom: '0%',
        height: '40%',
        backgroundColor: 'black',
    },
    video: {
        marginTop: '10%',
        marginLeft: '10%',
        marginRight: '10%',
        height: '70%',
        width: '80%',
    },
    touchableOpacityDownload: {},
    downloadButtonView: {
        marginLeft: '10%',
        flexDirection: 'row',
        marginBottom: '2%',
    },
    messageView: {
        color: 'white',
        marginLeft: '10%',
        marginRight: '10%',
        marginBottom: '10%',
        borderBottomColor: 'white',
        borderBottomWidth: 2,
    },
    message: {
        color: 'white',
        paddingVertical: '7%',
        fontSize: 16,
        fontFamily: 'AmericanAuto-Regular',
    },
    sendVideoView: {
        width: '100%',
        alignItems: 'center',
        justifyContent: 'center',
        position: 'relative',
        bottom: 0,
    },
    sendVideoButton: {alignItems: 'center', marginTop: '5%'},
});

export default styles;
