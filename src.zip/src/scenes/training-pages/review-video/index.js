/* eslint-disable react-native/no-inline-styles */
import React, {useState, useEffect} from 'react';
import {View, Alert} from 'react-native';
import {ProgressBar} from '_atoms';
import {ReviewVideo} from '_organisms';
import CameraRoll from '@react-native-community/cameraroll';

import Back from '_assets/images/orange-back.svg';
import Download from '_assets/images/app/training/download.svg';
import SendVideo from '_assets/images/app/training/send-video.svg';

import styles from './styles';

import {addVideoReferenceToConversation} from '_services';
import {Message, getUserOnAppSide} from '_utils';

import functions from '@react-native-firebase/functions';
import {RNS3} from 'react-native-aws3';

function ReviewVideoScreen({navigation}) {
    const user = getUserOnAppSide(navigation);
    const file = navigation.state.params.file;
    const [message, setMessage] = useState();
    const [sendVideo, setSendVideo] = useState(<SendVideo />);
    const [gotKeys, setGotKeys] = useState(false);
    const [keys, setKeys] = useState({
        accessKeyId: null,
        secretAccessKey: null,
    });
    const videoInfo = (
        navigation.state.params.video.module +
        navigation.state.params.video.level +
        navigation.state.params.video.drill
    ).replace(/\s/g, '');
    const attributes = {
        placeholder: 'Add a comment',
        placeholderTextColor: '#FFF',
        value: message,
        onChangeText: text => setMessage(text),
    };

    const options = {
        keyPrefix: 'uploads/' + user._userID + '/' + videoInfo + '/',
        bucket: 'tank-season-videos',
        region: 'us-east-1',
        accessKey: keys.accessKeyId,
        secretKey: keys.secretAccessKey,
        successActionStatus: 201,
    };

    useEffect(() => {
        if (!gotKeys) {
            functions()
                .httpsCallable('getSecretKeyAppSide')()
                .then(response => {
                    setKeys({
                        accessKeyId: response.data.accessKeyId,
                        secretAccessKey: response.data.secretAccessKey,
                    });
                    setGotKeys(true);
                });
        }
    });

    return (
        <View
            style={{
                flex: 1,
                height: '100%',
                width: '100%',
                backgroundColor: 'black',
            }}>
            <ReviewVideo
                back={<Back />}
                backOnPress={() => navigation.navigate('RecordVideo')}
                title={'Review\nVideo'}
                uri={file.uri}
                download={'Download'}
                downloadSVG={<Download />}
                onPressDownload={() =>
                    CameraRoll.save(file.uri, {type: 'video'})
                }
                attributes={attributes}
                sendVideo={sendVideo}
                onPressSendVideo={() => {
                    // setSendVideo(<ActivityIndicator size={'large'} />);
                    if (options.accessKey !== null) {
                        RNS3.put(file, options)
                            .progress(e =>
                                setSendVideo(
                                    <View
                                        style={{
                                            width: '75%',
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                            marginRight: '75%',
                                            marginTop: '10%',
                                        }}>
                                        <ProgressBar
                                            progression={`${(e.loaded /
                                                e.total) *
                                                100}%`}
                                        />
                                    </View>,
                                ),
                            )
                            .then(response => {
                                if (response.status !== 201) {
                                    throw new Error(
                                        'Failed to upload video to S3',
                                    );
                                } else {
                                    const videoContent = {
                                        type: 'video',
                                        contents:
                                            response.body.postResponse.location,
                                    };

                                    const textContent = {
                                        type: 'text',
                                        contents:
                                            message === ''
                                                ? undefined
                                                : message,
                                    };

                                    const videoMessage = new Message(
                                        videoContent,
                                        user._userID,
                                        Date.now(),
                                    );

                                    const textMessage = new Message(
                                        textContent,
                                        user._userID,
                                        Date.now() + 1,
                                    );

                                    addVideoReferenceToConversation(
                                        navigation.state.params.details,
                                        navigation.state.params.video,
                                        videoMessage,
                                        textMessage,
                                        {navigation},
                                    );

                                    setMessage(undefined);

                                    setSendVideo(<SendVideo />);
                                }
                            });
                    } else {
                        Alert.alert('Error. Please try sending video again.');
                    }
                }}
                styles={styles}
            />
        </View>
    );
}

export default ReviewVideoScreen;
