//MOSTLY NOT MY WORK

import React, {useEffect} from 'react';
import {AppRegistry} from 'react-native';
import Navigator from '_navigations';
import messaging from '@react-native-firebase/messaging';
import {requestUserPermission, handleNotification} from '_services';

messaging().setBackgroundMessageHandler(async remoteMessage => {
    handleNotification(remoteMessage);
});

function HeadlessCheck({isHeadless}) {
    if (isHeadless) {
        // App has been launched in the background by iOS, ignore
        return null;
    }

    return <App />;
}

function App() {
    useEffect(() => {
        requestUserPermission();
        const unsubscribe = messaging().onMessage(async remoteMessage => {
            handleNotification(remoteMessage);
            console.log('Message Recived');
            console.log(remoteMessage);
            // const reciever = JSON.parse(remoteMessage.data.reciever);
            // const sender = JSON.parse(remoteMessage.data.sender);
            // const conversation = JSON.parse(remoteMessage.data.conversation);
            // console.log(conversation);
            // console.log(
            //     `The user "${reciever._name.firstName}" liked your picture "${
            //         conversation._conversationID
            //     }"`,
            // );
        });

        return unsubscribe;
    }, []);

    return <Navigator />;
}

AppRegistry.registerComponent('app', () => HeadlessCheck);

export default App;
