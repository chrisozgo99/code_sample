/* eslint-disable react-native/no-inline-styles */
import React from 'react';
import {View} from 'react-native';
import {TouchableOpacitySVG} from '_atoms';
import Background from '_assets/images/app/nav-bar/nav-bar.svg';
import Profile from '_assets/images/app/nav-bar/user-profile-icon.svg';
import JumpshotTutor from '_assets/images/app/nav-bar/jumpshot-tutor-icon.svg';
import Training from '_assets/images/app/nav-bar/training-icon.svg';
import Messages from '_assets/images/app/nav-bar/messages-icon.svg';
import Shop from '_assets/images/app/nav-bar/shop-icon.svg';

function NavBar(props) {

    return (
        <View>
            <Background />
            <View
                style={{
                    marginTop: '4%',
                    flexDirection: 'row',
                    position: 'absolute',
                }}>
                <TouchableOpacitySVG
                    svg={<Profile />}
                    onPress={() => {
                        props.navigation.navigate('ViewProfile');
                    }}
                    buttonStyles={{
                        marginLeft: '9.75%',
                        marginRight: '3.75%',
                        marginTop: '4%',
                    }}
                />
                <TouchableOpacitySVG
                    svg={<JumpshotTutor />}
                    onPress={() => {
                        props.navigation.navigate('Training');
                    }}
                    buttonStyles={{
                        marginHorizontal: '6.75%',
                        marginTop: '4%',
                    }}
                />
                <TouchableOpacitySVG
                    svg={<Training />}
                    onPress={() => {
                        props.navigation.navigate('Training');
                    }}
                    buttonStyles={{
                        marginHorizontal: '6.75%',
                    }}
                />
                <TouchableOpacitySVG
                    svg={<Messages />}
                    onPress={() => {
                        props.navigation.navigate('Messages');
                    }}
                    buttonStyles={{
                        marginHorizontal: '6.75%',
                        marginTop: '4%',
                    }}
                />
                <TouchableOpacitySVG
                    svg={<Shop />}
                    onPress={() => {
                        props.navigation.navigate('Shop');
                    }}
                    buttonStyles={{
                        marginLeft: '3.75%',
                        marginRight: '9.75%',
                        marginTop: '4%',
                    }}
                />
            </View>
        </View>
    );
}

export default NavBar;
