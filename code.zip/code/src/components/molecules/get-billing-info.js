//NOT MY WORK
import React, {useState} from 'react';
import {View, Text, StyleSheet, TextInput, Button} from 'react-native';
import stripe from 'tipsi-stripe';
import {createSubscription} from '_services';

function GetBillingInfo(props) {
    // FIXME: Developing this form with a bug so that the state is broken. Please fix
    var errors = props.billingInfo.validateBilling();
    var token = null;
    let handleCardPayPress = async () => {
        try {
            await stripe.setOptions({
                publishableKey: 'pk_test_ZWGYVk8KvWypcHortZxVdHJF006pIQdEWP',
                // merchantId: 'MERCHANT_ID', // Optional
                // androidPayMode: 'test', // Android only
            });
            token = null;
            const tokenFromStripe = await stripe.paymentRequestWithCardForm({
                // Only iOS support this options
                // smsAutofillDisabled: true,
                requiredBillingAddressFields: null,
                prefilledInformation: {
                    billingAddress: {
                        name: props.billingInfo._name,
                        line1: props.billingInfo._address,
                        city: props.billingInfo._city,
                        state: props.billingInfo._state,
                        country: 'US',
                        postalCode: props.billingInfo._zip,
                    },
                },
            });
            token = tokenFromStripe;
            console.log(tokenFromStripe);
            console.log(token);
            // FIXME: Make the process of getting the params for the following function automated
            createSubscription(
                'cus_HW1oMBTSUytBRH',
                token,
                'price_1Gq36CFt2vE1IrQX52w5YyMQ',
            );
        } catch (error) {
            console.log(error);
        }
    };

    return (
        <View>
            <View style={styles.mainContainer}>
                <View style={styles.InfoContainer}>
                    <View style={styles.elementRow}>
                        <View style={styles.elementColumn}>
                            <Text>Name</Text>
                            <TextInput
                                style={
                                    errors.name ? styles.error : styles.noError
                                }
                                value={props.billingInfo._name}
                                placeholder="Jane Doe"
                                onChangeText={text => {
                                    props.billingInfo._name = text;
                                }}
                            />
                        </View>
                    </View>
                    <View style={styles.elementRow}>
                        <View style={styles.elementColumn}>
                            <Text>Email</Text>
                            <TextInput
                                style={
                                    errors.email ? styles.error : styles.noError
                                }
                                value={props.billingInfo._email}
                                placeholder="janedoe@gmail.com"
                                onChangeText={text =>
                                    (props.billingInfo._email = text)
                                }
                            />
                        </View>
                        <View style={styles.elementColumn}>
                            <Text>Phone</Text>
                            <TextInput
                                style={
                                    errors.phone ? styles.error : styles.noError
                                }
                                value={props.billingInfo._phone}
                                placeholder="(914) 555-0123"
                                textContentType="telephoneNumber"
                                dataDetectorTypes="phoneNumber"
                                keyboardType="phone-pad"
                                maxLength={14}
                                onChangeText={text =>
                                    (props.billingInfo._phone = text)
                                }
                            />
                        </View>
                    </View>
                </View>
                <View style={styles.InfoContainer}>
                    <View style={styles.elementRow}>
                        <View style={styles.elementColumn}>
                            <Text>Address</Text>
                            <TextInput
                                style={
                                    errors.address
                                        ? styles.error
                                        : styles.noError
                                }
                                placeholder="185 Berry Street"
                                value={props.billingInfo._address}
                                onChangeText={text =>
                                    (props.billingInfo._address = text)
                                }
                            />
                        </View>
                    </View>
                    <View style={styles.elementRow}>
                        <View style={styles.elementColumn}>
                            <Text>City</Text>
                            <TextInput
                                style={
                                    errors.city ? styles.error : styles.noError
                                }
                                placeholder="San Francisco"
                                value={props.billingInfo._city}
                                onChangeText={text =>
                                    (props.billingInfo._city = text)
                                }
                            />
                        </View>
                        <View style={styles.elementColumn}>
                            <Text>State</Text>
                            <TextInput
                                style={
                                    errors.state ? styles.error : styles.noError
                                }
                                placeholder="CA"
                                value={props.billingInfo._state}
                                onChangeText={text =>
                                    (props.billingInfo._state = text)
                                }
                            />
                        </View>
                        <View style={styles.elementColumn}>
                            <Text>ZIP</Text>
                            <TextInput
                                style={
                                    errors.zip ? styles.error : styles.noError
                                }
                                placeholder="94107"
                                value={props.billingInfo._zip}
                                onChangeText={text =>
                                    (props.billingInfo._zip = text)
                                }
                                keyboardType="phone-pad"
                            />
                        </View>
                    </View>
                </View>
                <Button
                    title="Submit Billing info and Pay with Card"
                    onPress={() => {
                        errors = props.billingInfo.validateBilling();
                        let validInputs = true;
                        for (const err in errors) {
                            if (errors[err]) {
                                validInputs = false;
                            }
                        }
                        if (validInputs) {
                            handleCardPayPress();
                            console.log(token);
                        }
                    }}
                />
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    mainContainer: {
        // backgroundColor: 'green',
    },
    InfoContainer: {
        flexDirection: 'column',
        justifyContent: 'space-around',
    },
    elementRow: {
        flexDirection: 'row',
    },
    elementColumn: {
        flexDirection: 'column',
        padding: 5,
    },
    error: {
        borderWidth: 1,
        borderColor: 'red',
    },
    noError: {
        borderWidth: 1,
        borderColor: 'green',
    },
});

export default GetBillingInfo;
