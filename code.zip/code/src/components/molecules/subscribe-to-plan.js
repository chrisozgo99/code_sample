//NOT MY WORK
import React from 'react';
import {View, Text, StyleSheet} from 'react-native';

function SubscribeToPlan(props) {
    return (
        <View>
            <Text style={styles.title}>
                Enter your card details.{'\n'}Your subscription will start now.
            </Text>
            <Text>
                • Total due now is ${props.sub._price * 0.01}
                {'\n'}• Subscribing to {props.sub._name}
            </Text>
        </View>
    );
}

const styles = StyleSheet.create({
    title: {
        fontWeight: 'bold',
        fontSize: 16,
    },
});

export default SubscribeToPlan;
