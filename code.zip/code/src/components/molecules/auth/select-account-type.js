import React from 'react';
import {View} from 'react-native';
import {TouchableOpacitySVG} from '_atoms';

function SelectAccountType(props) {
    return (
        <View style={props.selectAccountTypeStyles}>
            <TouchableOpacitySVG
                svg={props.playerSVG}
                selected={props.playerSelected}
                onPress={props.onPressPlayer}
            />
            <TouchableOpacitySVG
                svg={props.coachSVG}
                selected={props.coachSelected}
                onPress={props.onPressCoach}
            />
            <TouchableOpacitySVG
                svg={props.trainerSVG}
                selected={props.trainerSelected}
                onPress={props.onPressTrainer}
            />
        </View>
    );
}

export default SelectAccountType;
