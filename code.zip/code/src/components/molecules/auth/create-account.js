//I created the bare-bones structure for this code and it was expanded on by team members.
//The final version you see here is about 50% not my work.
import React from 'react';
import {View, Text} from 'react-native';
import {ViewAndTextInput, TouchableOpacitySVG} from '_atoms';

function CreateAccount(props) {
    const attr = [
        {
            attribute: props.firstNameAttributes,
            key: 'firstName',
        },
        {
            attribute: props.lastNameAttributes,
            key: 'lastName',
        },
        {
            attribute: props.emailAttributes,
            key: 'email',
        },
        {
            attribute: props.passwordAttributes,
            key: 'password',
        },
    ];

    const components = attr.map(component => {
        return (
            <ViewAndTextInput
                key={component.key}
                textInputViewStyles={props.styles.textInputView}
                textInputStyles={props.styles.textInput}
                attributes={component.attribute}
            />
        );
    });

    return (
        <View style={props.styles.mainView}>
            <View style={props.styles.backButtonView}>
                <TouchableOpacitySVG
                    buttonStyles={props.styles.backButton}
                    onPress={props.onPressBack}
                    svg={props.back}
                />
            </View>
            <View style={props.styles.titleView}>
                <Text style={props.styles.title}>{props.title}</Text>
            </View>
            <View style={props.styles.textInputStyles}>{components}</View>
            <View style={props.styles.allBottomView}>
                <View styles={props.styles.subtitleView}>
                    <Text style={props.styles.subtitle}>{props.subtitle}</Text>
                </View>
                <View style={props.styles.nextButtonView}>
                    <TouchableOpacitySVG
                        buttonStyles={props.styles.nextButton}
                        onPress={props.onPressNext}
                        svg={props.next}
                    />
                </View>
            </View>
        </View>
    );
}

export default CreateAccount;
