//I created the bare-bones structure for this code and it was expanded on by team members.
//The final version you see here is mostly not my work.
/* eslint-disable react-native/no-inline-styles */
import React, {useState} from 'react';
import {
    View,
    Text,
    TouchableOpacity,
    Platform,
    Modal,
    SafeAreaView,
    Button,
} from 'react-native';
import {TouchableOpacitySVG, TouchableOpacityButton} from '_atoms';
import DateTimePicker from '@react-native-community/datetimepicker';
import SegmentedPicker from 'react-native-segmented-picker';
import {PickerOptions} from '_utils';

function CompletePlayerProfile(props) {
    const pickerOptions = new PickerOptions();
    const [dateOfBirth, setDateOfBirth] = useState(
        props.dateOfBirthAttributes.value,
    );
    console.log(dateOfBirth);
    const attr = [
        {
            attribute: props.domHandAttributes,
            key: 'domHand',
            pickerOptions: {
                number: 2,
                options: pickerOptions.dominantHand,
            },
        },
        {
            attribute: props.positionAttributes,
            key: 'position',
            pickerOptions: {
                number: 3,
                options: pickerOptions.position,
            },
        },
        {
            attribute: props.skillLevelAttributes,
            key: 'skillLevel',
            pickerOptions: {
                number: 4,
                options: pickerOptions.skillLevel,
            },
        },
        {
            attribute: props.genderAttributes,
            key: 'gender',
            pickerOptions: {
                number: 6,
                options: pickerOptions.gender,
            },
        },
    ];

    const components = attr.map(component => {
        return (
            <View style={props.styles.inputView} key={component.key}>
                <TouchableOpacity
                    onPress={() => {
                        props.setPickerSelected(component.pickerOptions.number);
                        props.setPickerItems(component.pickerOptions.options);
                        props.setPickerVisable(true);
                    }}>
                    <Text
                        style={
                            component.attribute.value
                                ? props.styles.inputTextSelected
                                : props.styles.inputTextDefault
                        }>
                        {component.attribute.value
                            ? component.attribute.value
                            : component.attribute.placeholder}
                    </Text>
                </TouchableOpacity>
            </View>
        );
    });
    return (
        <View style={props.styles.mainView}>
            <View style={props.styles.titleView}>
                <Text style={props.styles.title}>{props.title}</Text>
            </View>
            <View style={props.styles.formView}>
                {props.datePickerVisable && Platform.OS === 'android' ? (
                    <DateTimePicker
                        testID="dateTimePicker"
                        value={
                            props.dateOfBirthAttributes.value
                                ? props.dateOfBirthAttributes.value
                                : new Date(983319330000)
                        }
                        mode={'date'}
                        is24Hour={true}
                        display="default"
                        onChange={event => {
                            if (event.type === 'dismissed') {
                                props.setDatePickerVisable(false);
                            } else if (event.type === 'set') {
                                props.setDatePickerVisable(false);
                                props.dateOfBirthAttributes.onChangeText(
                                    event.nativeEvent.timestamp,
                                );
                            }
                        }}
                    />
                ) : (
                    <View />
                )}
                {props.datePickerVisable && Platform.OS === 'ios' ? (
                    <Modal
                        animationType={'slide'}
                        transparent={true}
                        visible={props.datePickerVisable}
                        presentationStyle={'overFullScreen'}>
                        <SafeAreaView
                            style={{
                                backgroundColor: 'white',
                                position: 'absolute',
                                bottom: 0,
                                width: '100%',
                            }}>
                            <Button
                                title="Done"
                                onPress={() => {
                                    props.setDatePickerVisable(false);
                                    props.dateOfBirthAttributes.onPress(
                                        dateOfBirth,
                                    );
                                }}
                            />
                            <DateTimePicker
                                testID="dateTimePicker"
                                value={
                                    dateOfBirth === undefined
                                        ? new Date(983319330000)
                                        : new Date(dateOfBirth)
                                }
                                mode={'date'}
                                is24Hour={true}
                                display="default"
                                onChange={(event, date) => {
                                    if (event.type === 'dismissed') {
                                        props.setDatePickerVisable(false);
                                    } else {
                                        setDateOfBirth(
                                            event.nativeEvent.timestamp,
                                        );
                                        console.log(dateOfBirth);
                                    }
                                }}
                            />
                        </SafeAreaView>
                    </Modal>
                ) : (
                    <View />
                )}

                <View style={props.styles.heightWeightView}>
                    <View style={props.styles.heightInputView}>
                        <TouchableOpacity
                            onPress={() => {
                                props.setPickerSelected(0);
                                props.setPickerItems(pickerOptions.height);
                                props.setPickerVisable(true);
                            }}>
                            <Text
                                style={
                                    props.heightAttributes.value
                                        ? props.styles.inputTextSelected
                                        : props.styles.inputTextDefault
                                }>
                                {props.heightAttributes.value
                                    ? props.heightAttributes.value
                                    : props.heightAttributes.placeholder}
                            </Text>
                        </TouchableOpacity>
                    </View>
                    <View style={props.styles.weightInputView}>
                        <TouchableOpacity
                            onPress={() => {
                                props.setPickerSelected(1);
                                props.setPickerItems(pickerOptions.weight);
                                props.setPickerVisable(true);
                            }}>
                            <Text
                                style={
                                    props.weightAttributes.value
                                        ? props.styles.inputTextSelected
                                        : props.styles.inputTextDefault
                                }>
                                {props.weightAttributes.value
                                    ? props.weightAttributes.value
                                    : props.weightAttributes.placeholder}
                            </Text>
                        </TouchableOpacity>
                    </View>
                </View>
                <View style={props.styles.inputView}>
                    <TouchableOpacity
                        onPress={() => {
                            props.setDatePickerVisable(true);
                        }}>
                        <Text
                            style={
                                props.dateOfBirthAttributes.value
                                    ? props.styles.inputTextSelected
                                    : props.styles.inputTextDefault
                            }>
                            {props.dateOfBirthAttributes.value
                                ? new Date(
                                      // eslint-disable-next-line radix
                                      parseInt(
                                          props.dateOfBirthAttributes.value,
                                      ),
                                  ).toLocaleDateString()
                                : props.dateOfBirthAttributes.placeholder}
                        </Text>
                    </TouchableOpacity>
                </View>
                {components}
                <View>
                    <SegmentedPicker
                        visible={props.pickerVisable}
                        options={props.pickerItems}
                        onCancel={() => {
                            props.setPickerVisable(false);
                        }}
                        onConfirm={event => {
                            if (props.pickerSelected === 0) {
                                props.heightAttributes.onChangeText(
                                    event.feet + event.inches,
                                );
                            } else if (props.pickerSelected === 1) {
                                props.weightAttributes.onChangeText(
                                    event.weight,
                                );
                            } else if (props.pickerSelected === 2) {
                                props.domHandAttributes.onChangeText(
                                    event.hand,
                                );
                            } else if (props.pickerSelected === 3) {
                                props.positionAttributes.onChangeText(
                                    event.position,
                                );
                            } else if (props.pickerSelected === 4) {
                                props.skillLevelAttributes.onChangeText(
                                    event.skillLevel,
                                );
                            } else if (props.pickerSelected === 6) {
                                props.genderAttributes.onChangeText(
                                    event.gender,
                                );
                            }
                            props.setPickerVisable(false);
                        }}
                        confirmTextColor={'#E14821'}
                        pickerItemTextColor={'#E14821'}
                    />
                </View>
            </View>
            <View style={props.styles.nextAndSkipView}>
                <View style={props.styles.nextButtonView}>
                    <TouchableOpacitySVG
                        buttonStyles={props.styles.nextButton}
                        onPress={props.onPressNext}
                        svg={props.next}
                    />
                </View>
                <View style={props.skipView}>
                    <TouchableOpacityButton
                        touchableOpacityStyles={props.skipStyles}
                        onPress={props.onPressSkip}
                        viewStyles={props.styles.skipView}
                        textStyles={props.styles.skipTextStyles}
                        text="SKIP"
                    />
                </View>
            </View>
        </View>
    );
}

export default CompletePlayerProfile;
