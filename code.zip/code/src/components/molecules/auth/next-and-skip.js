import React from 'react';
import {View} from 'react-native';
import {TouchableOpacitySVG, TouchableOpacityButton} from '_atoms';
import Next from '_assets/images/auth/orange-next.svg';

function NextAndSkip(props) {
    return (
        <View style={props.nextAndSkipView}>
            <View style={props.nextView}>
                <TouchableOpacitySVG
                    buttonStyles={props.nextButton}
                    onPress={props.onPressNext}
                    svg={<Next />}
                />
            </View>
            <View style={props.skipView}>
                <TouchableOpacityButton
                    touchableOpacityStyles={props.skipStyles}
                    onPress={props.onPressSkip}
                    viewStyles={props.skipView}
                    textStyles={props.skipStyles}
                    text="SKIP"
                />
            </View>
        </View>
    );
}

export default NextAndSkip;
