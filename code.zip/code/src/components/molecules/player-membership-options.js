//NOT MY WORK
import React from 'react';
import {View, StyleSheet, TouchableHighlight} from 'react-native';
import {SubscriptionOption} from '_atoms';

function PlayerMembershipOptions(props) {
    return (
        <View style={styles.container}>
            <TouchableHighlight
                style={
                    props.sub1Selected
                        ? styles.itemSelected
                        : styles.itemNotSelected
                }
                onPress={() => {
                    if (!props.sub1Selected) {
                        props.setSub1Selected(!props.sub1Selected);
                        props.setSub2Selected(!props.sub2Selected);
                    }
                }}>
                <SubscriptionOption
                    subscription={props.sub1}
                    selected={props.sub1Selected}
                />
            </TouchableHighlight>
            <TouchableHighlight
                style={
                    props.sub2Selected
                        ? styles.itemSelected
                        : styles.itemNotSelected
                }
                onPress={() => {
                    if (!props.sub2Selected) {
                        props.setSub1Selected(!props.sub1Selected);
                        props.setSub2Selected(!props.sub2Selected);
                    }
                }}>
                <SubscriptionOption
                    subscription={props.sub2}
                    selected={props.sub2Selected}
                />
            </TouchableHighlight>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        justifyContent: 'space-around',
        padding: 10,
        // backgroundColor: 'yellow',
    },
    itemSelected: {
        padding: 10,
        borderWidth: 2,
        borderColor: 'red',
        // backgroundColor: 'blue',
        justifyContent: 'center',
    },
    itemNotSelected: {
        padding: 10,
        borderWidth: 2,
        borderColor: 'lightgrey',
        // backgroundColor: 'green',
        justifyContent: 'center',
    },
});

export default PlayerMembershipOptions;
