//NOT MY WORK
import React from 'react';
import {View, Text, StyleSheet} from 'react-native';

function SubscriptionOption(props) {
    return (
        <View
            style={
                props.selected !== undefined &&
                props.selected._name === props.name
                    ? styles.selectedBox
                    : styles.notSelectedBox
            }>
            <View style={styles.subscriptionText}>
                <Text
                    style={
                        props.selected !== undefined &&
                        props.selected._name === props.name
                            ? styles.titleSelected
                            : styles.titleNotSelected
                    }>
                    {props.name}
                </Text>
                <Text
                    style={
                        props.selected !== undefined &&
                        props.selected._name === props.name
                            ? styles.priceSelected
                            : styles.priceNotSelected
                    }>
                    ${props.price * 0.01}
                    {props.priceType === 'recurring' ? '/ month' : ''}
                </Text>
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    selectedBox: {
        backgroundColor: '#e14821',
        borderColor: '#e14821',
        borderRadius: 31,
        borderWidth: 2,
        height: '100%',
        width: '100%',
    },
    notSelectedBox: {
        // backgroundColor: 'green',
        borderRadius: 31,
        borderWidth: 2,
        borderColor: '#e14821',
        height: '100%',
        width: '100%',
    },
    subscriptionText: {
        // flexDirection: 'column',
        alignItems: 'center',
        alignContent: 'center',
        paddingTop: '30%',
    },
    titleSelected: {
        color: '#fff',
        fontSize: 20,
        fontFamily: 'AmericanAuto-Bold',
    },
    titleNotSelected: {
        color: '#e14821',
        fontSize: 20,
        fontFamily: 'AmericanAuto-Bold',
    },
    priceSelected: {
        color: '#fff',
        fontSize: 16,
    },
    priceNotSelected: {
        color: '#e14821',
        fontSize: 16,
    },
    selectedText: {
        fontSize: 17,
        color: 'rgba(0,0,0,0.6)',
        textAlign: 'center',
    },
});

export default SubscriptionOption;
