//NOT MY WORK
import React from 'react';
import {Text, View, StyleSheet, TouchableOpacity} from 'react-native';

function ProfileButtonCentered(props) {
    return (
        <TouchableOpacity onPress={props.onPress}>
            <View
                style={props.bottom ? styles.mainViewBottom : styles.mainView}>
                <Text style={styles.text}>{props.title}</Text>
            </View>
        </TouchableOpacity>
    );
}

const styles = StyleSheet.create({
    mainView: {
        borderColor: '#E4E4E4',
        borderTopWidth: 1.5,
        borderBottomWidth: 1.5,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        height: 32,
    },
    text: {
        fontFamily: 'AmericanAuto-Regular',
        fontSize: 16,
        color: '#E14821',
    },
});

export default ProfileButtonCentered;
