//I created the bare-bones structure for this code and it was expanded on by team members.
//The final version you see here is mostly not my work.
import React from 'react';
import {Text, View, Image} from 'react-native';

function UserAttributes({user, styles}) {
    return (
        <View>
            {console.log(user)}
            <View style={styles.profilePictureView}>
                <Image
                    style={styles.profilePicture}
                    source={{
                        uri:
                            user._profilePic === ''
                                ? 'https://firebasestorage.googleapis.com/v0/b/drills-and-skills.appspot.com/o/images%2Fprofile-pics%2Fblank-profile-picture.png?alt=media&token=86e354ea-5008-41e4-b7ba-0f3486b13fb8'
                                : user._profilePic,
                    }}
                />
            </View>
            <Text style={styles.titleText}>
                {user._name.firstName}
                {'\n'}
                {user._name.lastName}
            </Text>
        </View>
    );
}

export default UserAttributes;
