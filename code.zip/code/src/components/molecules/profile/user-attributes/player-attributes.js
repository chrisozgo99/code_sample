//I created the bare-bones structure for this code and it was expanded on by team members.
//The final version you see here is mostly not my work.
import React from 'react';
import {Text, View} from 'react-native';
import UserAttributes from './user-attributes';
import {logOut} from '_services';
import {ProfileButton, ProfileButtonCentered} from '../../index';
import {TermsConditions, ExperiencingIssues} from '_atoms';

function PlayerAttributes({user, styles, navigation}) {
    return (
        <View style={styles.topView}>
            <UserAttributes user={user} styles={styles} />
            <View style={styles.bodyContent}>
                <Text style={styles.subtitleText}>Player Info</Text>
                <View style={styles.userAttributesView}>
                    <View style={styles.userAttributesListView}>
                        <Text style={styles.userAttributes}>
                            Height:{' '}
                            {user._playerInfo.height === null
                                ? 'N/A'
                                : user._playerInfo.height}
                        </Text>
                        <Text style={styles.userAttributes}>
                            Weight:{' '}
                            {user._playerInfo.weight === null
                                ? 'N/A'
                                : user._playerInfo.weight}
                        </Text>
                        <Text style={styles.userAttributes}>
                            Gender:{' '}
                            {user._playerInfo.gender === null
                                ? 'N/A'
                                : user._playerInfo.gender}
                        </Text>
                        <Text style={styles.userAttributes}>
                            Date of Birth:{' '}
                            {user._playerInfo.dateOfBirth === null
                                ? 'N/A'
                                : new Date(
                                      // eslint-disable-next-line radix
                                      parseInt(user._playerInfo.dateOfBirth),
                                  ).toLocaleDateString()}
                        </Text>
                    </View>
                    <View style={styles.userAttributesListView}>
                        <Text style={styles.userAttributes}>
                            Dominant Hand:{' '}
                            {user._playerInfo.domHand === null
                                ? 'N/A'
                                : user._playerInfo.domHand}
                        </Text>
                        <Text style={styles.userAttributes}>
                            Skill Level:{' '}
                            {user._playerInfo.skillLevel === null
                                ? 'N/A'
                                : user._playerInfo.skillLevel}
                        </Text>
                        <Text style={styles.userAttributes}>
                            Position:{' '}
                            {user._playerInfo.position === null
                                ? 'N/A'
                                : user._playerInfo.position}
                        </Text>
                    </View>
                </View>
                {/* <View style={styles.averageGradeView}>
                    <Text style={styles.subtitleText}>Average Grade</Text>
                    <Text style={styles.averageGradeText}>A+</Text>
                </View> */}
                {/* <View style={styles.contentView}>
                    <TouchableOpacity
                        onPress={() =>
                            navigation.navigate('SkillProgressionProgress')
                        }>
                        <SkillProgression
                            skill={'Skill Progression'}
                            progression={'75%'}
                        />
                    </TouchableOpacity>
                </View> */}
                <View style={styles.contentView}>
                    <ProfileButton
                        title={'Edit Profile'}
                        onPress={() => navigation.navigate('EditProfile')}
                    />
                    <ProfileButton
                        title={'Membership'}
                        onPress={() => navigation.navigate('Membership')}
                    />
                    <ProfileButton
                        title={'Change Password'}
                        onPress={() => navigation.navigate('ChangePassword')}
                        bottom={true}
                    />
                </View>
                <View style={styles.contentView}>
                    <ProfileButtonCentered
                        title={'Logout'}
                        onPress={() => logOut(user, {navigation}, 'Landing')}
                    />
                </View>
            </View>
            <View style={styles.contentView}>
                <ExperiencingIssues navigation={navigation} />
            </View>
            <View style={styles.contentView}>
                <TermsConditions />
            </View>
        </View>
    );
}

export default PlayerAttributes;
