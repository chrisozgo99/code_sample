//I created the bare-bones structure for this code and it was expanded on by team members.
//The final version you see here is mostly not my work.
import React from 'react';
import {View} from 'react-native';
import UserAttributes from './user-attributes';
import {ProfileButton, ProfileButtonCentered} from '../../index';
import {logOut} from '_services';
import {TermsConditions, ExperiencingIssues} from '_atoms';

function TrainerAttributes({user, styles, navigation}) {
    return (
        <View style={styles.topView}>
            <UserAttributes user={user} styles={styles} />
            <View style={styles.bodyContent}>
                <View style={styles.contentView}>
                    <ProfileButton
                        title={'Edit Profile'}
                        onPress={() => navigation.navigate('EditProfile')}
                    />
                    <ProfileButton
                        title={'Change Password'}
                        onPress={() => navigation.navigate('ChangePassword')}
                        bottom={true}
                    />
                </View>
                <View style={styles.contentView}>
                    <ProfileButtonCentered
                        title={'Logout'}
                        onPress={() => logOut(user, {navigation}, 'Landing')}
                    />
                </View>
            </View>
            <View style={styles.contentView}>
                <ExperiencingIssues navigation={navigation} />
            </View>
            <View style={styles.contentView}>
                <TermsConditions />
            </View>
        </View>
    );
}

export default TrainerAttributes;
