/* eslint-disable react-native/no-inline-styles */
import React from 'react';
import {View, Text} from 'react-native';
import {ProgressBar} from '_atoms';

function SkillProgression(props) {
    return (
        <View style={{width: '100%', marginBottom: '7%'}}>
            <View
                style={{
                    flexDirection: 'row',
                    marginHorizontal: '9%',
                    marginBottom: '3%',
                    width: '82%',
                    justifyContent: 'space-between',
                }}>
                <Text style={{fontFamily: 'AmericanAuto-Bold', fontSize: 20}}>
                    {props.skill}
                </Text>
                <Text
                    style={{
                        fontFamily: 'AmericanAuto-Bold',
                        fontSize: 20,
                        color: '#e14821',
                    }}>
                    {props.progression}
                </Text>
            </View>
            <ProgressBar progression={props.progression} />
        </View>
    );
}

export default SkillProgression;
