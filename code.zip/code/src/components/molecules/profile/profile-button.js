//NOT MY WORK
import React from 'react';
import {Text, View, StyleSheet, TouchableOpacity} from 'react-native';
import Arrow from '_assets/images/horizontal-arrow.svg';

function ProfileButton(props) {
    return (
        <TouchableOpacity onPress={props.onPress}>
            <View
                style={props.bottom ? styles.mainViewBottom : styles.mainView}>
                <Text style={styles.text}>{props.title}</Text>
                <View style={styles.caret}>
                    <Arrow />
                </View>
            </View>
        </TouchableOpacity>
    );
}

const styles = StyleSheet.create({
    mainView: {
        borderColor: '#E4E4E4',
        borderTopWidth: 1.5,
        flexDirection: 'row',
        alignItems: 'center',
        height: 32,
    },
    mainViewBottom: {
        borderColor: '#E4E4E4',
        borderTopWidth: 1.5,
        borderBottomWidth: 1.5,
        flexDirection: 'row',
        alignItems: 'center',
        height: 32,
    },
    text: {
        fontFamily: 'AmericanAuto-Regular',
        fontSize: 16,
    },
    caret: {
        position: 'absolute',
        right: 0,
    },
});

export default ProfileButton;
