//ALMOST ENTIRELY MY WORK
import React from 'react';
import {SafeAreaView, View} from 'react-native';
import {TextAndTextField} from '_atoms';
import {EditProfilePic} from '../../index';

function EditUserAttributes(props) {
    const userAttributes = props.userTitles.map(title => (
        <TextAndTextField
            key={title.placeholder}
            title={title.placeholder}
            value={title.value}
            onChange={title.onPress}
            styles={props.styles}
        />
    ));

    return (
        <SafeAreaView>
            <EditProfilePic
                attributes={props.attributes}
                profilePicView={props.styles.profilePicView}
                profilePicStyles={props.styles.profilePic}
                defaultImgMargin={props.styles.defaultImgMargin}
            />
            <View style={props.styles.formView}>{userAttributes}</View>
        </SafeAreaView>
    );
}

export default EditUserAttributes;
