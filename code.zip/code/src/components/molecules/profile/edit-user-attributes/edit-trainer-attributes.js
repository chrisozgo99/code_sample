import React from 'react';
import {SafeAreaView} from 'react-native';
import {EditUserAttributes} from '../../index';
import {TextAndTextField} from '_atoms';

function EditTrainerAttributes(props) {
    return (
        <SafeAreaView>
            <EditUserAttributes
                userTitles={props.userTitles}
                attributes={props.attributes}
                styles={props.styles}
            />
        </SafeAreaView>
    );
}

export default EditTrainerAttributes;
