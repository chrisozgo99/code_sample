//I created the bare-bones structure for this code and it was expanded on by team members.
//The final version you see here is mostly not my work.
/* eslint-disable react-native/no-inline-styles */
import React, {useState} from 'react';
import {
    SafeAreaView,
    View,
    Text,
    TouchableOpacity,
    Platform,
    Modal,
    Button,
} from 'react-native';
import {EditUserAttributes} from '../../index';
import DateTimePicker from '@react-native-community/datetimepicker';
import SegmentedPicker from 'react-native-segmented-picker';
import {PickerOptions} from '_utils';

function EditPlayerAttributes(props) {
    const pickerOptions = new PickerOptions();
    const [dateOfBirth, setDateOfBirth] = useState(props.playerTitles[5].value);
    return (
        <SafeAreaView>
            <EditUserAttributes
                userTitles={props.userTitles}
                attributes={props.attributes}
                styles={props.styles}
            />
            <View style={props.styles.formView}>
                {/* This following code desplays a date picker if the button for date is clicked */}
                {props.datePickerVisable && Platform.OS === 'android' ? (
                    <DateTimePicker
                        testID="dateTimePicker"
                        value={
                            props.playerTitles[5].value === null
                                ? new Date(983319330000)
                                : props.playerTitles[5].value
                        }
                        mode={'date'}
                        is24Hour={true}
                        display="default"
                        onChange={event => {
                            if (event.type === 'dismissed') {
                                props.setDatePickerVisable(false);
                            } else if (event.type === 'set') {
                                props.setDatePickerVisable(false);
                                props.playerTitles[5].onPress(
                                    event.nativeEvent.timestamp,
                                );
                            }
                        }}
                    />
                ) : (
                    <View />
                )}
                {props.datePickerVisable && Platform.OS === 'ios' ? (
                    <Modal
                        animationType={'slide'}
                        transparent={true}
                        visible={props.datePickerVisable}
                        presentationStyle={'overFullScreen'}>
                        <SafeAreaView
                            style={{
                                backgroundColor: 'white',
                                position: 'absolute',
                                bottom: 0,
                                width: '100%',
                            }}>
                            <Button
                                title="Done"
                                onPress={() => {
                                    props.setDatePickerVisable(false);
                                    props.playerTitles[5].onPress(dateOfBirth);
                                }}
                            />
                            <DateTimePicker
                                testID="dateTimePicker"
                                value={
                                    dateOfBirth === null
                                        ? new Date(983319330000)
                                        : new Date(dateOfBirth)
                                }
                                mode={'date'}
                                is24Hour={true}
                                display="default"
                                onChange={(event, date) => {
                                    if (event.type === 'dismissed') {
                                        props.setDatePickerVisable(false);
                                    } else {
                                        setDateOfBirth(
                                            event.nativeEvent.timestamp,
                                        );
                                    }
                                }}
                            />
                        </SafeAreaView>
                    </Modal>
                ) : (
                    <View />
                )}
                <View style={props.styles.textInputView}>
                    <Text style={props.styles.textInputTitleText}>Height</Text>
                    <TouchableOpacity
                        style={props.styles.textInput}
                        onPress={() => {
                            props.setPickerSelected(0);
                            props.setPickerItems(pickerOptions.height);
                            props.setPickerVisable(true);
                        }}>
                        <Text style={props.styles.clickableText}>
                            {props.playerTitles[0].value === null
                                ? 'Click to select'
                                : props.playerTitles[0].value}
                        </Text>
                    </TouchableOpacity>
                </View>
                <View style={props.styles.textInputView}>
                    <Text style={props.styles.textInputTitleText}>Weight</Text>
                    <TouchableOpacity
                        style={props.styles.textInput}
                        onPress={() => {
                            props.setPickerSelected(1);
                            props.setPickerItems(pickerOptions.weight);
                            props.setPickerVisable(true);
                        }}>
                        <Text style={props.styles.clickableText}>
                            {props.playerTitles[1].value === null
                                ? 'Click to select'
                                : props.playerTitles[1].value}
                        </Text>
                    </TouchableOpacity>
                </View>
                <View style={props.styles.textInputView}>
                    <Text style={props.styles.textInputTitleText}>
                        Dominant Hand
                    </Text>
                    <TouchableOpacity
                        style={props.styles.textInput}
                        onPress={() => {
                            props.setPickerSelected(2);
                            props.setPickerItems(pickerOptions.dominantHand);
                            props.setPickerVisable(true);
                        }}>
                        <Text style={props.styles.clickableText}>
                            {props.playerTitles[2].value === null
                                ? 'Click to select'
                                : props.playerTitles[2].value}
                        </Text>
                    </TouchableOpacity>
                </View>
                <View style={props.styles.textInputView}>
                    <Text style={props.styles.textInputTitleText}>
                        Position
                    </Text>
                    <TouchableOpacity
                        style={props.styles.textInput}
                        onPress={() => {
                            props.setPickerSelected(3);
                            props.setPickerItems(pickerOptions.position);
                            props.setPickerVisable(true);
                        }}>
                        <Text style={props.styles.clickableText}>
                            {props.playerTitles[3].value === null
                                ? 'Click to select'
                                : props.playerTitles[3].value}
                        </Text>
                    </TouchableOpacity>
                </View>
                <View style={props.styles.textInputView}>
                    <Text style={props.styles.textInputTitleText}>
                        Skill Level
                    </Text>
                    <TouchableOpacity
                        style={props.styles.textInput}
                        onPress={() => {
                            props.setPickerSelected(4);
                            props.setPickerItems(pickerOptions.skillLevel);
                            props.setPickerVisable(true);
                        }}>
                        <Text style={props.styles.clickableText}>
                            {props.playerTitles[4].value === null
                                ? 'Click to select'
                                : props.playerTitles[4].value}
                        </Text>
                    </TouchableOpacity>
                </View>
                <View style={props.styles.textInputView}>
                    <Text style={props.styles.textInputTitleText}>
                        Birthday
                    </Text>
                    <TouchableOpacity
                        style={props.styles.textInput}
                        onPress={() => {
                            props.setDatePickerVisable(true);
                        }}>
                        <Text style={props.styles.clickableText}>
                            {props.playerTitles[5].value === null
                                ? 'Click to select'
                                : new Date(
                                      // eslint-disable-next-line radix
                                      parseInt(props.playerTitles[5].value),
                                  ).toLocaleDateString()}
                        </Text>
                    </TouchableOpacity>
                </View>
                <View style={props.styles.textInputView}>
                    <Text style={props.styles.textInputTitleText}>Gender</Text>
                    <TouchableOpacity
                        style={props.styles.textInput}
                        onPress={() => {
                            props.setPickerSelected(6);
                            props.setPickerItems(pickerOptions.gender);
                            props.setPickerVisable(true);
                        }}>
                        <Text style={props.styles.clickableText}>
                            {props.playerTitles[6].value === null
                                ? 'Click to select'
                                : props.playerTitles[6].value}
                        </Text>
                    </TouchableOpacity>
                </View>
                <View>
                    <SegmentedPicker
                        // native
                        visible={props.pickerVisable}
                        options={props.pickerItems}
                        onCancel={() => {
                            props.setPickerVisable(false);
                        }}
                        onConfirm={event => {
                            if (props.pickerSelected === 0) {
                                props.playerTitles[0].onPress(
                                    event.feet + event.inches,
                                );
                            } else if (props.pickerSelected === 1) {
                                props.playerTitles[1].onPress(event.weight);
                            } else if (props.pickerSelected === 2) {
                                props.playerTitles[2].onPress(event.hand);
                            } else if (props.pickerSelected === 3) {
                                props.playerTitles[3].onPress(event.position);
                            } else if (props.pickerSelected === 4) {
                                props.playerTitles[4].onPress(event.skillLevel);
                            } else if (props.pickerSelected === 6) {
                                props.playerTitles[6].onPress(event.gender);
                            }
                            props.setPickerVisable(false);
                        }}
                        confirmTextColor={'#E14821'}
                        pickerItemTextColor={'#E14821'}
                    />
                </View>
            </View>
        </SafeAreaView>
    );
}

export default EditPlayerAttributes;
