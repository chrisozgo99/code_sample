/* eslint-disable react-native/no-inline-styles */
import React from 'react';
import {View, Image, TouchableOpacity, Text} from 'react-native';
import ImagePicker from 'react-native-image-crop-picker';

function EditProfilePic(props) {
    return (
        <View>
            <View style={props.profilePicView}>
                <TouchableOpacity
                    onPress={() => {
                        ImagePicker.openPicker({
                            width: 1000,
                            height: 1000,
                            cropping: true,
                            cropperCircleOverlay: true,
                            mediaType: 'photo',
                            smartAlbums: [
                                'UserLibrary',
                                'RecentlyAdded',
                                'Favorites',
                                'PhotoStream',
                                'Bursts',
                                'Screenshots',
                                'SelfPortraits',
                            ],
                            cropperChooseText: 'Set Photo',
                            hideBottomControls: true,
                        }).then(props.attributes.onPress);
                    }}>
                    <Image
                        style={props.profilePicStyles}
                        source={{uri: props.attributes.source}}
                    />
                </TouchableOpacity>
            </View>
            <View style={props.defaultImgMargin}>
                <TouchableOpacity
                    style={{alignItems: 'center', justifyContent: 'center'}}
                    onPress={props.attributes.onPressRevertToDefaultImage}>
                    <Text style={{fontSize: 12, color: '#e14821'}}>
                        Revert to Default Image
                    </Text>
                </TouchableOpacity>
            </View>
        </View>
    );
}

export default EditProfilePic;
