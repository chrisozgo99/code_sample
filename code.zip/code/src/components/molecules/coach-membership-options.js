//NOT MY WORK
import React from 'react';
import {View, Text} from 'react-native';
import {SubscriptionOption} from '_atoms';

function CoachMembershipOptions(props) {
    return (
        <View>
            <Text>Canada</Text>
        </View>
    );
}

export default CoachMembershipOptions;
