/* eslint-disable react-native/no-inline-styles */
import React from 'react';
import {View, Text, TouchableHighlight} from 'react-native';
import firestore from '@react-native-firebase/firestore';
import {ProfilePic} from '_atoms';
import {updateLastReadMessage} from '_services';
import {Conversation, convertTimestampToReadableDate} from '_utils';

function MessagePreview(props) {
    function showDot(user, details, messages) {
        if (user._userID === messages[0]._sentBy) {
            //If the current user sent the last message
            return false;
        } else {
            if (user._userID === details.client.value) {
                //If the current user is the client
                if (details.client.lastReadMessage < details.lastUpdated) {
                    //If the last time the current user has looked at the conversation
                    //is before the last time the conversation has been updated
                    return true;
                } else if (
                    details.client.lastReadMessage >= details.lastUpdated
                ) {
                    return false;
                }
            } else if (user._userID === details.trainer.value) {
                //If the current user is the trainer
                if (details.trainer.lastReadMessage < details.lastUpdated) {
                    //If the last time the current user has looked at the conversation
                    //is before the last time the conversation has been updated
                    return true;
                } else if (
                    details.trainer.lastReadMessage >= details.lastUpdated
                ) {
                    return false;
                }
            }
        }
    }

    const styles = {
        pictureStyles: {
            marginRight: 10,
            marginTop: 3,
            marginBottom: 0,
        },
        circle: {
            width: 9,
            height: 9,
            borderRadius: 100,
            backgroundColor: '#E14821',
            marginVertical: '11%',
        },
    };

    return (
        <TouchableHighlight
            style={{
                width: '100%',
                // paddingRight: '25%',
            }}
            underlayColor="lightgray"
            onPress={async () => {
                var updatedConvo;
                if (
                    props.user._userID !==
                    props.conversation.messages[0]._sentBy
                ) {
                    //If person sending the message is not the person who sent the last message
                    if (
                        props.user._userID ===
                        props.conversation.details.client.value
                    ) {
                        //If person who is logged in is the client
                        if (
                            props.conversation.details.client.lastReadMessage <
                            props.conversation.details.lastUpdated
                        ) {
                            updatedConvo = await updateLastReadMessage(
                                props.user,
                                props.conversation,
                            );
                        }
                    } else if (
                        props.user._userID ===
                        props.conversation.details.trainer.value
                    ) {
                        //If the person who is logged in is the trainer
                        if (
                            props.conversation.details.trainer.lastReadMessage <
                            props.conversation.details.lastUpdated
                        ) {
                            updatedConvo = await updateLastReadMessage(
                                props.user,
                                props.conversation,
                            );
                        }
                    }
                }
                if (updatedConvo !== undefined) {
                    var passedConvo = new Conversation(
                        updatedConvo._conversationID,
                        updatedConvo._details,
                        updatedConvo._messages,
                        updatedConvo._video,
                    );
                } else {
                    var passedConvo = new Conversation(
                        props.conversation.conversationID,
                        props.conversation.details,
                        props.conversation.messages,
                        props.conversation.video,
                    );
                }

                props.navigation.navigate('Conversation', {
                    conversation: passedConvo,
                });
            }}>
            <View
                style={{
                    borderBottomWidth: 1,
                    borderBottomColor: 'silver',
                }}>
                <View
                    style={{
                        flexDirection: 'row',
                        width: '100%',
                    }}>
                    <View
                        style={{
                            width: '100%',
                            marginBottom: 10,
                            marginTop: 10,
                        }}>
                        <View
                            style={{
                                flexDirection: 'row',
                                marginHorizontal: '8%',
                            }}>
                            <ProfilePic
                                size={props.size}
                                source={props.source}
                                styles={styles.pictureStyles}
                            />
                            <View style={{width: '60%'}}>
                                <Text
                                    style={{
                                        fontFamily: 'AmericanAuto-Bold',
                                        fontSize: 20,
                                    }}>
                                    {props.user._userType === 'trainers'
                                        ? props.details.client.label
                                        : 'Coach ' +
                                          props.details.trainer.label.split(
                                              ' ',
                                          )[0]}
                                </Text>
                                <Text
                                    style={{
                                        fontFamily: 'AmericanAuto-Regular',
                                        fontSize: 16,
                                    }}>
                                    {props.video.module}
                                    {'\n'}
                                    {props.video.drill}
                                </Text>
                            </View>
                            <View
                                style={{alignItems: 'flex-end', width: '24%'}}>
                                <Text
                                    style={{
                                        fontFamily: 'AmericanAuto-Regular',
                                        fontSize: 16,
                                        textAlign: 'right',
                                    }}>
                                    {convertTimestampToReadableDate(
                                        props.details.lastUpdated,
                                    )}
                                </Text>
                                <View
                                    style={
                                        showDot(
                                            props.user,
                                            props.conversation.details,
                                            props.conversation.messages,
                                        )
                                            ? styles.circle
                                            : null
                                    }
                                />
                            </View>
                        </View>
                    </View>
                </View>
            </View>
        </TouchableHighlight>
    );
}

export default MessagePreview;
