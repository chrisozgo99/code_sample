import React from 'react';
import {View, FlatList, TouchableOpacity} from 'react-native';
import {TrainingModuleBox} from '_atoms';

function TrainingModules(props) {
    const modulesDisplayed = props.modules.map(module => {
        return (
            <View style={props.styles.trainingModuleBoxView} key={module.title}>
                <TouchableOpacity
                    onPress={() => {
                        props.navigation.navigate('Module', {
                            module: module.title.toString(),
                        });
                    }}>
                    <TrainingModuleBox
                        title={module.title.toUpperCase()}
                        modulePNG={module.coverPhoto}
                        moduleOnPress={() => {
                            props.navigation.navigate('Module', {
                                module: module.title.toString(),
                            });
                        }}
                        touchableOpacityStyle={props.styles.touchableOpacityPNG}
                        imageStyle={props.styles.imagePNG}
                        moduleTitleStyle={props.styles.moduleTitle}
                    />
                </TouchableOpacity>
            </View>
        );
    });

    return <View style={props.styles.flatListView}>{modulesDisplayed}</View>;
}

export default TrainingModules;
