import React from 'react';
import {
    View,
    SafeAreaView,
    ScrollView,
    SectionList,
    Text,
    FlatList,
    ActivityIndicator,
} from 'react-native';

import {TrainingDrill} from '_atoms';
import {TouchableOpacitySVG} from '_atoms';

function ModuleVideoList(props) {
    const module = props.module;
    if (props.videos === []) {
        return <ActivityIndicator />;
    } else {
        return (
            <SafeAreaView>
                <SectionList
                    style={props.styles.topView}
                    ListHeaderComponent={
                        <View style={props.styles.headerView}>
                            <View style={props.styles.backButtonView}>
                                <TouchableOpacitySVG
                                    svg={props.back}
                                    onPress={props.onPressBack}
                                />
                            </View>
                            <Text style={props.styles.title}>
                                {props.title.replace(' ', '\n')}
                            </Text>
                        </View>
                    }
                    stickySectionHeadersEnabled={true}
                    sections={props.videos}
                    keyExtractor={(item, index) => item + index}
                    renderSectionHeader={({section}) => (
                        <View style={props.styles.sectionTitleView}>
                            <Text style={props.styles.sectionTitle}>
                                {section.title}
                            </Text>
                        </View>
                    )}
                    renderItem={({item}) => {
                        return (
                            <FlatList
                                data={item}
                                horizontal={true}
                                showsHorizontalScrollIndicator={false}
                                renderItem={({item}) => (
                                    <View>
                                        <TrainingDrill
                                            key={item.key}
                                            videoThumbnail={item.thumbnail}
                                            onPressVideoThumbnail={() =>
                                                props.navigation.navigate(
                                                    'Video',
                                                    {
                                                        video: {
                                                            module: module,
                                                            videoDetails: item,
                                                        },
                                                    },
                                                )
                                            }
                                            drill={item.drill.toUpperCase()}
                                            touchableOpacityStyle={
                                                props.styles.touchableOpacityPNG
                                            }
                                            imageStyle={props.styles.imagePNG}
                                        />
                                    </View>
                                )}
                            />
                        );
                    }}
                />
            </SafeAreaView>
        );
    }
}

export default ModuleVideoList;
