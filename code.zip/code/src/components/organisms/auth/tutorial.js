import React from 'react';
import {View, Text, Image} from 'react-native';
import {BackgroundImage, TouchableOpacitySVG} from '_atoms';
import {NextAndSkip} from '_molecules';

function Tutorial(props) {
    return (
        <View style={props.styles.mainView}>
            <BackgroundImage
                bgView={props.styles.bgView}
                bgImage={props.styles.bgImage}
                bg={props.bg}
            />
            <View style={props.styles.backButtonView}>
                <TouchableOpacitySVG
                    buttonStyles={props.styles.backButton}
                    onPress={props.backOnPress}
                    svg={props.backSVG}
                />
            </View>
            <View style={props.styles.titleView}>
                <Text style={props.styles.title}>{props.title}</Text>
            </View>
            <View style={props.styles.subtitleView}>
                <Text style={props.styles.subtitle}>{props.subtitle}</Text>
            </View>
            <View style={props.styles.imageView}>
                <Image style={props.styles.image} source={props.image} />
            </View>
            <NextAndSkip
                nextAndSkipView={props.styles.nextAndSkipView}
                nextView={props.styles.nextButtonView}
                nextButton={props.styles.nextButton}
                onPressNext={props.onPressNextAndSkip}
                skipView={props.styles.skipButtonView}
                skipStyles={props.styles.skipButton}
                onPressSkip={props.onPressNextAndSkip}
            />
        </View>
    );
}

export default Tutorial;
