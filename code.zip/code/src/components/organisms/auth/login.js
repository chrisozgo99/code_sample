//MOSTLY MY WORK
import React from 'react';
import {
    SafeAreaView,
    View,
    Text,
    TextInput,
    TouchableOpacity,
    ActivityIndicator,
} from 'react-native';
import {TouchableOpacitySVG, BackgroundImage} from '_atoms';

function Login(props) {
    return (
        <SafeAreaView style={props.styles.topView}>
            <BackgroundImage
                bgView={props.styles.bgView}
                bgImage={props.styles.bgImage}
                bg={props.bg}
            />
            <View style={props.styles.backView}>
                <TouchableOpacitySVG
                    buttonStyles={props.styles.backButton}
                    onPress={props.backOnPress}
                    svg={props.backSVG}
                />
            </View>
            <View style={props.styles.titleView}>
                <Text style={props.styles.title}>{props.title}</Text>
            </View>
            <View style={props.styles.textInputView}>
                <TextInput
                    style={props.styles.textInput}
                    onChangeText={props.emailOnChangeText}
                    value={props.emailValue}
                    placeholder={props.emailPlaceholder}
                    autoCapitalize={'none'}
                    autoCompleteType="email"
                />
            </View>
            <View style={props.styles.textInputView}>
                <TextInput
                    style={props.styles.textInput}
                    onChangeText={props.passwordOnChangeText}
                    value={props.passwordValue}
                    secureTextEntry={true}
                    placeholder={props.passwordPlaceholder}
                    autoCapitalize={'none'}
                    autoCompleteType="password"
                />
            </View>
            <View style={props.styles.forgotPasswordView}>
                <TouchableOpacity onPress={props.forgotPasswordOnPress}>
                    <Text style={props.styles.forgotPassword}>
                        Forgot your password?
                    </Text>
                </TouchableOpacity>
            </View>
            <View style={props.styles.loginView}>
                {props.signingIn ? (
                    <ActivityIndicator size="large" color="#E14821" />
                ) : (
                    <TouchableOpacitySVG
                        onPress={props.loginOnPress}
                        svg={props.loginSVG}
                    />
                )}
            </View>
        </SafeAreaView>
    );
}

export default Login;
