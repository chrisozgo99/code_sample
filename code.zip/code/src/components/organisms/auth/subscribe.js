//ABOUT 50% MY WORK
import React from 'react';
import {View, Text, Image} from 'react-native';
import {
    TouchableOpacitySVG,
    BackgroundImage,
    HeaderAndSubheader,
    TouchableOpacityButton,
} from '_atoms';

function Subscribe(props) {
    return (
        <View>
            <BackgroundImage
                bgView={props.styles.bgView}
                bgImage={props.styles.bgImage}
                bg={props.bg}
            />
            <View style={props.styles.backView}>
                <TouchableOpacitySVG
                    buttonStyles={props.styles.backButton}
                    onPress={props.backOnPress}
                    svg={props.backSVG}
                />
            </View>
            <View style={props.styles.titleView}>
                <Text style={props.styles.title}>{props.title}</Text>
            </View>
            <View style={props.styles.contentView}>
                <HeaderAndSubheader
                    textView={props.styles.paragraph1View}
                    headerView={props.styles.header1View}
                    headerStyles={props.styles.header1}
                    header={props.header1}
                    subheaderView={props.styles.subheader1View}
                    subheaderStyles={props.styles.subheader1}
                    subheader={props.subheader1}
                />
                <HeaderAndSubheader
                    textView={props.styles.paragraph2View}
                    headerView={props.styles.header2View}
                    headerStyles={props.styles.header2}
                    header={props.header2}
                    subheaderView={props.styles.subheader2View}
                    subheaderStyles={props.styles.subheader2}
                    subheader={props.subheader2}
                />
                <HeaderAndSubheader
                    textView={props.styles.paragraph3View}
                    headerView={props.styles.header3View}
                    headerStyles={props.styles.header3}
                    header={props.header3}
                    subheaderView={props.styles.subheader3View}
                    subheaderStyles={props.styles.subheader3}
                    subheader={props.subheader3}
                />
            </View>
            <View style={props.styles.upgradeAndSkipView}>
                <View style={props.upgradeView}>
                    <TouchableOpacitySVG
                        buttonStyles={props.styles.upgradeButton}
                        onPress={props.onPressUpgrade}
                        svg={props.upgrade}
                    />
                </View>
                <View style={props.styles.skipButtonView}>
                    <TouchableOpacityButton
                        touchableOpacityStyles={props.styles.skipStyles}
                        onPress={props.onPressSkip}
                        viewStyles={props.styles.skipView}
                        textStyles={props.styles.skipText}
                        text="SKIP"
                    />
                </View>
            </View>
        </View>
    );
}

export default Subscribe;
