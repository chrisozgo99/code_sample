import React from 'react';
import {View, Text} from 'react-native';
import {TouchableOpacitySVG, BackgroundImage} from '_atoms';
import {SelectAccountType} from '_molecules';

function SelectAccount(props) {
    return (
        <View style={props.styles.topView}>
            <BackgroundImage
                bgView={props.styles.bgView}
                bgImage={props.styles.bgImage}
                bg={props.bg}
            />
            <View style={props.styles.backView}>
                <TouchableOpacitySVG
                    onPress={props.backOnPress}
                    svg={props.backSVG}
                />
            </View>
            <View style={props.styles.titleView}>
                <Text style={props.styles.title}>{props.title}</Text>
            </View>
            <SelectAccountType
                playerSVG={props.playerSVG}
                playerSelected={props.playerSelected}
                onPressPlayer={props.onPressPlayer}
                coachSVG={props.coachSVG}
                coachSelected={props.coachSelected}
                onPressCoach={props.onPressCoach}
                trainerSVG={props.trainerSVG}
                trainerSelected={props.trainerSelected}
                onPressTrainer={props.onPressTrainer}
                selectAccountTypeStyles={
                    props.dynamicStyles.selectAccountTypeView
                }
            />
            <View style={props.styles.subtitleView}>
                <Text style={props.styles.subtitleText}>{props.subtitle}</Text>
            </View>
            <View style={props.styles.nextView}>
                <TouchableOpacitySVG
                    onPress={props.nextOnPress}
                    svg={props.nextSVG}
                    buttonStyles={props.styles.buttonStyles}
                />
            </View>
        </View>
    );
}

export default SelectAccount;
