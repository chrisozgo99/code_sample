//NOT MY WORK
import React from 'react';
import {View, Text, ActivityIndicator} from 'react-native';
import {BackgroundImage} from '_atoms';

function Loading(props) {
    return (
        <View style={props.styles.topView}>
            <BackgroundImage
                bgView={props.styles.bgView}
                bgImage={props.styles.bgImage}
                bg={props.bg}
            />
            <View style={props.styles.title}>
                <Text style={props.styles.white}>PAUL</Text>
                <Text style={props.styles.white}>EASTON</Text>
                <Text style={props.styles.orange}>BASKETBALL</Text>
            </View>
            <View style={props.styles.subtitleView}>
                <Text style={props.styles.subtitle}>
                    Get access now to Paul Easton's premier workouts, one-on-one
                    coach guidance, and custom feedback on your workout footage.
                </Text>
            </View>
            <View style={props.styles.buttonView}>
                <ActivityIndicator size="large" color="#E14821" />
                <Text style={props.styles.activityText}>
                    {props.activityText}
                </Text>
            </View>
        </View>
    );
}

export default Loading;
