//NOT MY WORK
import React from 'react';
import {View, Text, TextInput} from 'react-native';
import {TouchableOpacitySVG, BackgroundImage} from '_atoms';

function ForgotPassword(props) {
    return (
        <View style={props.styles.topView}>
            <BackgroundImage
                bgView={props.styles.bgView}
                bgImage={props.styles.bgImage}
                bg={props.bg}
            />
            <View style={props.styles.backButtonView}>
                <TouchableOpacitySVG
                    svg={props.back}
                    onPress={props.onPressBack}
                />
            </View>
            <View style={props.styles.titleView}>
                <Text style={props.styles.titleText}>Reset{'\n'}Password</Text>
            </View>
            <View style={props.styles.textInputView}>
                <TextInput
                    onChangeText={props.onChangeEmailText}
                    autoCapitalize="none"
                    value={props.email}
                    placeholder="Email"
                    style={props.styles.textInput}
                />
            </View>
            <View style={props.styles.loginView}>
                <TouchableOpacitySVG
                    onPress={props.loginOnPress}
                    svg={props.loginSVG}
                />
            </View>
        </View>
    );
}

export default ForgotPassword;
