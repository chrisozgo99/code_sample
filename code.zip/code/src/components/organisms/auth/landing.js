import React from 'react';
import {View, Text} from 'react-native';
import {TouchableOpacitySVG, BackgroundImage} from '_atoms';

function Landing(props) {
    return (
        <View style={props.styles.topView}>
            <BackgroundImage
                bgView={props.styles.bgView}
                bgImage={props.styles.bgImage}
                bg={props.bg}
            />
            <View style={props.styles.title}>
                <Text style={props.styles.white}>PAUL</Text>
                <Text style={props.styles.white}>EASTON</Text>
                <Text style={props.styles.orange}>BASKETBALL</Text>
            </View>
            <View style={props.styles.subtitleView}>
                <Text style={props.styles.subtitle}>
                    Get access now to Paul Easton's premier workouts, one-on-one
                    coach guidance, and custom feedback on your workout footage.
                </Text>
            </View>
            <View style={props.styles.buttonView}>
                <View>
                    <TouchableOpacitySVG
                        onPress={() =>
                            props.navigation.navigate('SelectAccount')
                        }
                        svg={props.createAccount}
                        buttonStyles={props.styles.buttonStyles}
                    />
                </View>
                <View style={props.styles.loginButtonView}>
                    <TouchableOpacitySVG
                        onPress={() => props.navigation.navigate('Login')}
                        svg={props.signIn}
                        buttonStyles={props.styles.buttonStyles}
                    />
                </View>
            </View>
        </View>
    );
}

export default Landing;
