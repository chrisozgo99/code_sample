import React from 'react';
import {View, Text} from 'react-native';
import {TouchableOpacitySVG} from '_atoms';
import {EditProfilePic, NextAndSkip} from '_molecules';

function AddProfilePhoto(props) {
    return (
        <View style={props.styles.mainView}>
            <View style={props.styles.backButtonView}>
                <TouchableOpacitySVG
                    buttonStyles={props.styles.backButton}
                    onPress={props.onPressBack}
                    svg={props.back}
                />
            </View>
            <View style={props.styles.titleAndSubtitleView}>
                <View style={props.styles.titleView}>
                    <Text style={props.styles.title}>{props.title}</Text>
                </View>
                <View style={props.styles.subtitleView}>
                    <Text style={props.styles.subtitle}>{props.subtitle}</Text>
                </View>
            </View>
            <View style={props.styles.profilePhotoView}>
                <EditProfilePic
                    attributes={props.attributes}
                    profilePicView={props.styles.profilePicView}
                    profilePicStyles={props.styles.profilePic}
                    defaultImgMargin={props.styles.defaultImgMargin}
                />
            </View>
            <NextAndSkip
                nextAndSkipView={props.styles.nextAndSkipView}
                nextView={props.styles.nextButtonView}
                nextButton={props.styles.nextButton}
                onPressNext={props.onPressNext}
                skipView={props.styles.skipButtonView}
                skipStyles={props.styles.skipButton}
                onPressSkip={props.onPressSkip}
            />
        </View>
    );
}

export default AddProfilePhoto;
