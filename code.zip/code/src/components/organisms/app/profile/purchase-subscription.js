//NOT MY WORK
import React from 'react';
import {View, Text, TextInput, ActivityIndicator} from 'react-native';
import {TouchableOpacitySVG} from '_atoms';
import {PaymentCardTextField} from 'tipsi-stripe';

function PurchaseSubscription(props) {
    return (
        <View style={props.styles.topView}>
            <View style={props.styles.headerView}>
                <View style={props.styles.backButtonView}>
                    <TouchableOpacitySVG
                        svg={props.back}
                        onPress={props.onPressBack}
                    />
                </View>
                <Text style={props.styles.title}>{props.title}</Text>
            </View>
            <View style={props.styles.formView}>
                <Text style={props.styles.formTitle}>
                    Subscribing to the {props.subscription._name} plan
                </Text>
                <View style={props.styles.form}>
                    {/* <View style={props.styles.textInputView}>
                        <Text style={props.styles.formInputTitle}>
                            First Name
                        </Text>
                        <TextInput
                            style={props.styles.textInput}
                            onChangeText={props.firstNameOnChangeText}
                            value={props.firstNameValue}
                            placeholder={'John'}
                        />
                    </View>
                    <View style={props.styles.textInputView}>
                        <Text style={props.styles.formInputTitle}>
                            Last Name
                        </Text>
                        <TextInput
                            style={props.styles.textInput}
                            onChangeText={props.lastNameOnChangeText}
                            value={props.lastNameValue}
                            placeholder={'Smith'}
                        />
                    </View>
                    <View style={props.styles.textInputView}>
                        <Text style={props.styles.formInputTitle}>Email</Text>
                        <TextInput
                            style={props.styles.textInput}
                            onChangeText={props.emailOnChangeText}
                            value={props.emailValue}
                            placeholder={'johnsmith@gmail.com'}
                            autoCompleteType={'email'}
                            keyboardType={'email-address'}
                        />
                    </View> */}
                    <View style={props.styles.textInputView}>
                        <Text style={props.styles.formInputTitle}>Phone</Text>
                        <TextInput
                            style={props.styles.textInput}
                            onChangeText={props.phoneOnChangeText}
                            value={props.phoneValue}
                            placeholder={'(202)-555-0191'}
                            autoCompleteType={'tel'}
                            keyboardType={'phone-pad'}
                        />
                    </View>
                    <View style={props.styles.textInputView}>
                        <Text style={props.styles.formInputTitle}>Address</Text>
                        <TextInput
                            style={props.styles.textInput}
                            onChangeText={props.addressOnChangeText}
                            value={props.addressValue}
                            placeholder={'225 North Ave'}
                            autoCompleteType={'street-address'}
                        />
                    </View>
                    <View style={props.styles.textInputView}>
                        <Text style={props.styles.formInputTitle}>City</Text>
                        <TextInput
                            style={props.styles.textInput}
                            onChangeText={props.cityOnChangeText}
                            value={props.cityValue}
                            placeholder={'Atlanta'}
                        />
                    </View>
                    <View style={props.styles.textInputView}>
                        <Text style={props.styles.formInputTitle}>State</Text>
                        <TextInput
                            style={props.styles.textInput}
                            onChangeText={props.stateOnChangeText}
                            value={props.stateValue}
                            placeholder={'GA'}
                        />
                    </View>
                    <View style={props.styles.textInputView}>
                        <Text style={props.styles.formInputTitle}>
                            Zip Code
                        </Text>
                        <TextInput
                            style={props.styles.textInput}
                            onChangeText={props.zipCodeOnChangeText}
                            value={props.zipCodeValue}
                            placeholder={'30332'}
                            autoCompleteType={'postal-code'}
                            keyboardType={'numeric'}
                        />
                    </View>
                    <View style={props.styles.fieldView}>
                        <PaymentCardTextField
                            style={props.styles.field}
                            textErrorColor={'#FF0000'}
                            onParamsChange={props.handleCardFieldParamsChange}
                        />
                    </View>
                    {props.loading ? (
                        <ActivityIndicator
                            size="large"
                            style={props.styles.submitView}
                            color={'#FF0000'}
                        />
                    ) : (
                        <View style={props.styles.submitView}>
                            <TouchableOpacitySVG
                                onPress={props.submitOnPress}
                                svg={props.submitSVG}
                            />
                        </View>
                    )}
                </View>
            </View>
        </View>
    );
}

export default PurchaseSubscription;
