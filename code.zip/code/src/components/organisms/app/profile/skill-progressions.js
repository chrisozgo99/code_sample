import React from 'react';
import {View, Text} from 'react-native';
import {TouchableOpacitySVG} from '_atoms';
import {SkillProgression} from '_molecules';

function SkillProgressions(props) {
    const skillProgressionComponents = props.skillAreas.map(skillArea => {
        return (
            <SkillProgression
                key={skillArea.skill}
                skill={skillArea.skill}
                progression={skillArea.progression}
            />
        );
    });

    return (
        <View style={props.styles.topView}>
            <View style={props.styles.headerView}>
                <View style={props.styles.backButtonView}>
                    <TouchableOpacitySVG
                        svg={props.back}
                        onPress={props.onPressBack}
                    />
                </View>
                <Text style={props.styles.title}>{props.title}</Text>
            </View>
            <View style={props.styles.skillProgressions}>
                {skillProgressionComponents}
            </View>
        </View>
    );
}

export default SkillProgressions;
