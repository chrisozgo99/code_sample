import React from 'react';
import {SafeAreaView} from 'react-native';
import {PlayerAttributes, CoachAttributes, TrainerAttributes} from '_molecules';

function UserProfile({user, styles, navigation}) {
    if (user._userType === 'players') {
        return (
            <SafeAreaView>
                <PlayerAttributes
                    user={user}
                    styles={styles}
                    navigation={navigation}
                />
            </SafeAreaView>
        );
    } else if (user._userType === 'coaches') {
        return (
            <SafeAreaView>
                <CoachAttributes
                    user={user}
                    styles={styles}
                    navigation={navigation}
                />
            </SafeAreaView>
        );
    } else if (user._userType === 'trainers') {
        return (
            <SafeAreaView>
                <TrainerAttributes
                    user={user}
                    styles={styles}
                    navigation={navigation}
                />
            </SafeAreaView>
        );
    }
}

export default UserProfile;
