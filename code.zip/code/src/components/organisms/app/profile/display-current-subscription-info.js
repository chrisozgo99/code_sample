//NOT MY WORK
import React from 'react';
import {View, Text, ActivityIndicator} from 'react-native';
import {TouchableOpacitySVG} from '_atoms';
import {SubscriptionOption} from '_molecules';

function DisplayCurrentSubscriptionInfo(props) {
    return (
        <View style={props.styles.topView}>
            <View style={props.styles.headerView}>
                <View style={props.styles.backButtonView}>
                    <TouchableOpacitySVG
                        svg={props.back}
                        onPress={props.onPressBack}
                    />
                </View>
                <Text style={props.styles.title}>Account Information</Text>
            </View>
            <View style={props.styles.subscriptionOptionsView}>
                {props.loading ? (
                    <View style={props.styles.subscriptionOptions}>
                        <ActivityIndicator size={'large'} />
                    </View>
                ) : (
                    <View style={props.styles.subscriptionOptions}>
                        <SubscriptionOption
                            name={props.sub._name}
                            price={props.sub._price}
                            priceType={props.sub._priceType}
                            selected={props.sub}
                        />
                    </View>
                )}
            </View>
            <View>
                {props.loading ? (
                    <View style={props.styles.subscriptionOptions}>
                        <ActivityIndicator size={'large'} />
                    </View>
                ) : (
                    <View>
                        <Text>
                            Currently Subscribed To: {props.sub._name} Plan
                        </Text>
                        <Text>Next Payment Due: {}</Text>
                        <Text>Current Payment Method</Text>
                        <Text>
                            AutoRenew:{' '}
                            {props.fullSubInfo.collection_method ===
                            'charge_automatically'
                                ? 'On'
                                : 'Off'}
                        </Text>
                    </View>
                )}
            </View>
        </View>
    );
}

export default DisplayCurrentSubscriptionInfo;
