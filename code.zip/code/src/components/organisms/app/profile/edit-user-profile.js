import React from 'react';
import {SafeAreaView} from 'react-native';
import {
    EditPlayerAttributes,
    EditCoachAttributes,
    EditTrainerAttributes,
} from '_molecules';

function EditUserProfile(props) {
    if (props.user._userType === 'players') {
        return (
            <SafeAreaView>
                <EditPlayerAttributes
                    userTitles={props.userTitles}
                    playerTitles={props.titles}
                    attributes={props.attributes}
                    styles={props.styles}
                    datePickerVisable={props.datePickerVisable}
                    setDatePickerVisable={props.setDatePickerVisable}
                    dateOfBirth={props.dateOfBirth}
                    setDateOfBirth={props.setDateOfBirth}
                    pickerVisable={props.pickerVisable}
                    setPickerVisable={props.setPickerVisable}
                    pickerItems={props.pickerItems}
                    setPickerItems={props.setPickerItems}
                    pickerSelected={props.pickerSelected}
                    setPickerSelected={props.setPickerSelected}
                />
            </SafeAreaView>
        );
    } else if (props.user._userType === 'coaches') {
        return (
            <SafeAreaView>
                <EditCoachAttributes
                    userTitles={props.userTitles}
                    coachTitles={props.titles}
                    attributes={props.attributes}
                    styles={props.styles}
                />
            </SafeAreaView>
        );
    } else if (props.user._userType === 'trainers') {
        return (
            <SafeAreaView>
                <EditTrainerAttributes
                    userTitles={props.userTitles}
                    trainerTitles={props.titles}
                    attributes={props.attributes}
                    styles={props.styles}
                />
            </SafeAreaView>
        );
    }
}

export default EditUserProfile;
