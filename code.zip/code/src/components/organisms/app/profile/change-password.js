//NOT MY WORK
import React from 'react';
import {View, Text, TextInput} from 'react-native';
import {TouchableOpacitySVG, WhiteButton} from '_atoms';

function ChangePassword(props) {
    return (
        <View style={props.styles.topView}>
            <View style={props.styles.headerView}>
                <View style={props.styles.backButtonView}>
                    <TouchableOpacitySVG
                        svg={props.back}
                        onPress={props.onPressBack}
                    />
                </View>
                <Text style={props.styles.title}>{props.title}</Text>
            </View>
            <View style={props.styles.formView}>
                <View style={props.textInputView}>
                    <TextInput
                        style={props.styles.textInputs}
                        placeholder="Current Password"
                        secureTextEntry={true}
                        value={props.currentPassword}
                        onChangeText={props.currentPasswordOnChangeText}
                    />
                </View>
                <View style={props.textInputView}>
                    <TextInput
                        style={props.styles.textInputs}
                        placeholder="New Password"
                        secureTextEntry={true}
                        value={props.newPassword}
                        onChangeText={props.newPasswordOnChangeText}
                    />
                </View>
                <View style={props.textInputView}>
                    <TextInput
                        style={props.styles.textInputs}
                        placeholder="Confirm New Password"
                        secureTextEntry={true}
                        value={props.verifyNewPassword}
                        onChangeText={props.verifyNewPasswordOnChangeText}
                    />
                </View>
            </View>
            <View style={props.styles.footerView}>
                <View style={props.styles.saveButtonView}>
                    <WhiteButton name="Save" onPress={props.onPressSave} />
                </View>
            </View>
        </View>
    );
}

export default ChangePassword;
