//NOT MY WORK
import React from 'react';
import {
    View,
    Text,
    TouchableOpacity,
    ActivityIndicator,
    Alert,
} from 'react-native';
import {TouchableOpacitySVG, WhiteButton} from '_atoms';
import {SubscriptionOption} from '_molecules';

function DisplaySubscription(props) {
    var subscriptionComponents;
    if (props.subscriptionList === undefined) {
        subscriptionComponents = <View />;
    } else {
        subscriptionComponents = props.subscriptionList.map(product => {
            return (
                <View
                    style={props.styles.subscriptionOptions}
                    key={product._name}>
                    <TouchableOpacity
                        onPress={() => {
                            props.setSelectedSub(product);
                        }}>
                        <SubscriptionOption
                            name={product._name}
                            price={product._price}
                            priceType={product._priceType}
                            selected={props.selectedSub}
                        />
                    </TouchableOpacity>
                </View>
            );
        });
    }

    return (
        <View style={props.styles.topView}>
            <View style={props.styles.headerView}>
                <View style={props.styles.backButtonView}>
                    <TouchableOpacitySVG
                        svg={props.back}
                        onPress={props.onPressBack}
                    />
                </View>
                <Text style={props.styles.title}>{props.title}</Text>
            </View>
            <View style={props.styles.subscriptionOptionsView}>
                {props.loading ? (
                    <ActivityIndicator color="#e14821" size="large" />
                ) : (
                    subscriptionComponents
                )}
            </View>
            <View style={props.styles.subscriptionDescriptionView}>
                <Text style={props.styles.subscriptionDescriptionText}>
                    {props.selectedSub !== undefined
                        ? props.selectedSub._description
                        : 'Please select a product.'}
                </Text>
            </View>
            <View style={props.styles.payButtonView}>
                <WhiteButton
                    name="Start Subscription"
                    onPress={() => {
                        if (!props.selectedSub) {
                            Alert.alert('Please select a membership');
                        } else {
                            props.navigation.navigate('PayMembership', {
                                subSelected: props.selectedSub,
                            });
                        }
                    }}
                />
            </View>
        </View>
    );
}

export default DisplaySubscription;
