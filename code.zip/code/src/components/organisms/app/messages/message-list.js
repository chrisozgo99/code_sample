//ABOUT 50% MY WORK (Split with a team member)
import React from 'react';
import {View, FlatList, Text, SafeAreaView} from 'react-native';
import {MessagePreview} from '_molecules';

function MessageList(props) {
    if (props.messages.length !== 0) {
        return (
            <SafeAreaView style={props.styles.topView}>
                <View style={props.styles.headerView}>
                    <Text style={props.styles.headerTitle}>
                        {props.pageTitle}
                    </Text>
                </View>
                <View style={props.styles.listView}>
                    <FlatList
                        style={{height: '100%'}}
                        contentContainerStyle={{alignItems: 'center'}}
                        data={props.messages}
                        renderItem={({item}) => (
                            <MessagePreview
                                user={props.user}
                                conversation={item}
                                key={item.conversationID}
                                size={55}
                                source={item.source}
                                details={item.details}
                                navigation={props.navigation}
                                video={item.video}
                                previewMessage={
                                    item.messages[item.messages.length - 1]
                                        ._content.type === 'video'
                                        ? 'Video'
                                        : item.messages[
                                              item.messages.length - 1
                                          ]._content.contents
                                }
                            />
                        )}
                        keyExtractor={item => item.conversationID}
                    />
                </View>
            </SafeAreaView>
        );
    } else {
        return (
            <SafeAreaView style={props.styles.topView}>
                <View style={props.styles.headerView}>
                    <Text style={props.styles.headerTitle}>
                        {props.pageTitle}
                    </Text>
                </View>
                <View>
                    <Text style={props.styles.noMessagesStatement}>
                        {props.user._userType === 'trainers'
                            ? 'No players have messaged you yet. Please stay tuned!'
                            : "You don't have any messages yet. Watch the videos to start a conversation."}
                    </Text>
                </View>
            </SafeAreaView>
        );
    }
}

export default MessageList;
