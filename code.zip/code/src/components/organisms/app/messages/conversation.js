//MOSTLY MY WORK
/* eslint-disable react-native/no-inline-styles */
import React from 'react';
import {
    View,
    SafeAreaView,
    KeyboardAvoidingView,
    FlatList,
    Image,
    Text,
    Platform,
} from 'react-native';
import {
    MessageInputAndSend,
    MessageContents,
    TouchableOpacitySVG,
} from '_atoms';
import Back from '_assets/images/white-back.svg';

function Conversation({props, conversation, user}) {

    return (
        <KeyboardAvoidingView
            style={{flex: 1}}
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
            <View style={props.styles.topView}>
                <View style={props.styles.headerView}>
                    <View style={props.styles.backButtonView}>
                        <TouchableOpacitySVG
                            svg={<Back />}
                            onPress={props.onPressBack}
                        />
                    </View>
                    <View style={props.styles.header}>
                        <Image
                            source={{uri: props.profilePic}}
                            style={props.styles.profilePic}
                        />
                        <View style={props.styles.convoTitleView}>
                            <Text style={props.styles.coachTitle}>
                                {props.recipient}
                            </Text>
                            <Text style={props.styles.drillTitle}>
                                {props.module}
                            </Text>
                            <Text style={props.styles.drillTitle}>
                                {props.drill}
                            </Text>
                        </View>
                    </View>
                </View>
                <FlatList
                    style={{
                        flex: 0.5,
                        marginBottom: 110,
                        marginTop: 176,
                    }}
                    data={conversation._messages}
                    renderItem={({item}) => (
                        <MessageContents
                            convo={conversation}
                            message={item}
                            user={user}
                            navigation={props.navigation}
                        />
                    )}
                    keyExtractor={message => message._sentAt.toString()}
                    inverted={true}
                />
                <SafeAreaView style={props.styles.messageInputAndSendView}>
                    <MessageInputAndSend
                        placeholder={props.placeholder}
                        onChangeText={props.onChangeText}
                        value={props.value}
                        sendMessage={props.sendMessage}
                        onPressAttachment={props.onPressAttachment}
                    />
                </SafeAreaView>
            </View>
        </KeyboardAvoidingView>
    );
}

export default Conversation;
