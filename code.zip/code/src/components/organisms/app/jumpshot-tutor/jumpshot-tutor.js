import React from 'react';
import {SafeAreaView, View, Text, Image} from 'react-native';
import {WhiteButton} from '_atoms';

function JumpshotTutor(props) {
    return (
        <SafeAreaView style={props.styles.topView}>
            <View style={props.styles.headerView}>
                <Text style={props.styles.title}>{props.title}</Text>
            </View>
            <View style={props.styles.bodyView}>
                <Image style={props.styles.bgImage} source={props.source} />
                <View style={props.styles.whiteButtonView}>
                    <WhiteButton name={props.name} onPress={props.onPress} />
                </View>
            </View>
        </SafeAreaView>
    );
}

export default JumpshotTutor;
