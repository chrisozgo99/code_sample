//MOSTLY NOT MY WORK
import React, {useState} from 'react';
import {View, Text, Linking} from 'react-native';
import {TopTabBar} from '_molecules';
import CountDown from 'react-native-countdown-component';
import {TouchableOpacityButton} from '_atoms';

function Extra(props) {
    const [countdownComplete, setCountdownComplete] = useState(false);
    return (
        <View style={props.styles.topView}>
            <View style={props.styles.headerView}>
                <Text style={props.styles.title}>{props.title}</Text>
            </View>
            <TopTabBar
                navigation={props.navigation}
                training={false}
                extra={true}
                about={false}
            />
            <View style={props.styles.challengeOfTheWeekView}>
                <View style={props.styles.challengeOfTheWeekTitleView}>
                    <Text style={props.styles.challengeOfTheWeek}>
                        {props.challengeOfTheWeek}
                    </Text>
                </View>
                <View style={props.styles.challengeView}>
                    <Text style={props.styles.challenge}>
                        {props.challenge}
                    </Text>
                </View>
                <View style={props.styles.timeRemainingView}>
                    <Text style={props.styles.timeRemaining}>
                        Expires {props.timeRemaining}
                    </Text>
                </View>
            </View>
            <View style={props.styles.zoomView}>
                <View style={props.styles.zoomTitleView}>
                    <Text style={props.styles.zoomTitle}>
                        {props.zoomTitle}
                    </Text>
                </View>
                <View style={props.styles.zoomCountdownView}>
                    {props.liveDateTime !== 0 ? (
                        <CountDown
                            until={props.liveDateTime}
                            onFinish={() => setCountdownComplete(true)}
                            size={props.countdownSize}
                            digitStyle={props.styles.digitStyle}
                            digitTxtStyle={props.styles.digitTxtStyle}
                            separatorStyle={props.styles.separatorStyle}
                            showSeparator
                            timeLabelStyle={props.styles.timeLabelStyle}
                        />
                    ) : (
                        <Text>Loading countdown component...</Text>
                    )}
                    <Text>{props.liveName}</Text>
                </View>
                <View style={props.styles.zoomButtonView}>
                    {!countdownComplete ? (
                        <TouchableOpacityButton
                            touchableOpacityStyles={
                                props.styles.touchableOpacityGrayStyles
                            }
                            viewStyles={props.buttonView}
                            textStyles={
                                props.styles.touchableOpacityGrayTextStyles
                            }
                            text={props.touchableOpacityText}
                        />
                    ) : (
                        <TouchableOpacityButton
                            touchableOpacityStyles={
                                props.styles.touchableOpacityBlackStyles
                            }
                            onPress={() => Linking.openURL(props.liveLink)}
                            viewStyles={props.buttonView}
                            textStyles={
                                props.styles.touchableOpacityBlackTextStyles
                            }
                            text={props.touchableOpacityText}
                        />
                    )}
                </View>
                <View style={props.viewStyles} selected={props} />
            </View>
        </View>
    );
}

export default Extra;
