//MOSTLY MY WORK
import React from 'react';
import {ScrollView, View, Text} from 'react-native';
import {TrainingModules, TopTabBar} from '_molecules';

function TrainingModulesList(props) {
    return (
        <ScrollView style={props.styles.topView}>
            <View style={props.styles.headerView}>
                <Text style={props.styles.titleText}>{props.pageTitle}</Text>
            </View>
            <TopTabBar
                navigation={props.navigation}
                training={true}
                extra={false}
                about={false}
            />
            <TrainingModules
                modules={props.modules}
                navigation={props.navigation}
                styles={props.styles}
            />
        </ScrollView>
    );
}

export default TrainingModulesList;
