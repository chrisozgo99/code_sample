/* eslint-disable react-native/no-inline-styles */
import React from 'react';
import {View} from 'react-native';

function ProgressBar(props) {
    return (
        <View
            style={{
                width: '100%',
                height: 5,
            }}>
            <View
                style={{
                    height: '100%',
                    width: '100%',
                    borderRadius: 5,
                    backgroundColor: 'lightgrey',
                    position: 'absolute',
                }}
            />
            <View
                style={{
                    height: '100%',
                    width: props.progression,
                    borderRadius: 5,
                    backgroundColor: '#e14821',
                    position: 'absolute',
                    alignContent: 'flex-start',
                }}
            />
        </View>
    );
}

export default ProgressBar;
