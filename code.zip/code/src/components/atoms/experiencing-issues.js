//ENTIRELY NOT MY WORK
import React from 'react';
import {View, Text, StyleSheet, Linking} from 'react-native';

function ExperiencingIssues({navigation, IssuesForm}) {
    return (
        <View>
            <Text style={styles.group}>
                <Text>Experiencing Issues? </Text>
                <Text
                    style={styles.link}
                    onPress={() =>
                        Linking.openURL('https://forms.gle/VziLeyYPRiRirNR58')
                    }>
                    Contact Us
                </Text>
            </Text>
        </View>
    );
}

const styles = StyleSheet.create({
    link: {
        color: '#E14821',
    },
    text: {
        color: '#000',
    },
    group: {
        fontFamily: 'AmericanAuto-Regular',
        fontSize: 12,
        textAlign: 'center',
    },
});

export default ExperiencingIssues;
