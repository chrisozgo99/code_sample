import React from 'react';
import {View, TouchableOpacity, Text} from 'react-native';

function TouchableOpacityButton(props) {
    return (
        <TouchableOpacity
            style={props.touchableOpacityStyles}
            onPress={props.onPress}>
            <View style={props.viewStyles} selected={props}>
                <Text style={props.textStyles}>{props.text}</Text>
            </View>
        </TouchableOpacity>
    );
}

export default TouchableOpacityButton;
