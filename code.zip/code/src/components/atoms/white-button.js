//MOSTLY NOT MY WORK
import React from 'react';
import {View, TouchableOpacity, Text, StyleSheet} from 'react-native';

function WhiteButton(props) {
    return (
        <TouchableOpacity onPress={props.onPress}>
            <View style={styles.mainView}>
                <Text style={styles.text}>{props.name}</Text>
            </View>
        </TouchableOpacity>
    );
}

const styles = StyleSheet.create({
    mainView: {
        height: 64,
        width: '100%',
        borderColor: '#000',
        borderWidth: 2,
        borderRadius: 80,
        alignItems: 'center',
        justifyContent: 'center',
    },
    text: {
        fontFamily: 'AmericanAuto-Bold',
        marginTop: '1.5%',
        marginHorizontal: '16%',
        fontSize: 20,
        color: '#000',
    },
});

export default WhiteButton;
