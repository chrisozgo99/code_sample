import React from 'react';
import {View, ImageBackground} from 'react-native';

function BackgroundImage(props) {
    return (
        <View style={props.bgView}>
            <ImageBackground style={props.bgImage} source={props.bg} />
        </View>
    );
}

export default BackgroundImage;
