import React from 'react';
import {View, Text, TextInput} from 'react-native';

function TextAndTextField(props, key) {
    return (
        <View key={key} style={props.styles.textInputView}>
            <Text style={props.styles.textInputTitleText}>{props.title}</Text>
            <TextInput
                onChangeText={props.onChange}
                value={props.value}
                style={props.styles.textInput}
            />
        </View>
    );
}

export default TextAndTextField;
