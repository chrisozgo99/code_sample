import React from 'react';
import {View, Image} from 'react-native';

function ProfilePic(props) {
    return (
        <View style={props.styles}>
            <Image
                // eslint-disable-next-line react-native/no-inline-styles
                style={{
                    width: props.size,
                    height: props.size,
                    borderRadius: 100,
                }}
                source={{uri: props.source}}
            />
        </View>
    );
}

export default ProfilePic;
