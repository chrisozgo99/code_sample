/* eslint-disable react-native/no-inline-styles */
import React from 'react';
import {View, Text} from 'react-native';
import {WebView} from 'react-native-webview';

function VideoPlayer(props) {
    return (
        <View
            style={{
                height: props.height,
                width: props.width,
                marginTop: '5%',
                marginRight: '7%',
                marginLeft: '7%',
                marginBottom: '0%',
            }}>
            <Text
                style={{
                    position: 'absolute',
                    bottom: 0,
                    zIndex: 1,
                    fontSize: 24,
                    color: 'orange',
                    margin: '1%',
                }}>
                {props.drill}
            </Text>
            <WebView
                source={{
                    html: `<html>
                        <body style="background-color: black; border: 2px solid #e14821;
                        border-radius: 100px;">
                            <video style="margin-left: 5%; margin-right: 5%;" width="90%" height="98%" controls>
                                <source src=${props.source} type="video/mp4">
                                Your browser does not support the video 
                            </video>
                        </body>
                    </html>`,
                }}
                scrollEnabled={false}
                bounnces={false}
                allowsFullscreenVideo={true}
                allowsLinkPreview={true}
                style={{
                    width: '100%',
                    height: '100%',
                    borderRadius: 30,
                    backgroundColor: '#e14821',
                }}
            />
        </View>
    );
}

export default VideoPlayer;
