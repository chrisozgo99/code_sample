/* eslint-disable react-native/no-inline-styles */
import React from 'react';
import {View, Text} from 'react-native';
import {SubatomicTouchableOpacitySVG} from '../../subatomic/index';

import Back from '_assets/images/white-back.svg';

function VideoNotch(props) {
    return (
        <View
            style={{
                flex: 1,
                height: '17%',
                width: '100%',
                position: 'absolute',
                flexDirection: 'row',
                justifyContent: 'space-evenly',
                marginTop: '0%',
                backgroundColor: 'black',
                opacity: 0.5,
                borderBottomLeftRadius: 35,
                borderBottomRightRadius: 35,
                display: props.display,
            }}>
            <View
                style={{
                    flex: 1 / 2,
                    alignItems: 'center',
                    justifyContent: 'center',
                    margin: 0,
                }}>
                <View
                    style={{
                        height: '30%',
                        borderRadius: 20,
                        borderWidth: 2,
                        borderColor: 'white',
                        alignItems: 'center',
                        justifyContent: 'center',
                        marginTop: '25%',
                    }}>
                    <Text style={{color: 'white', margin: '5%'}}>
                        {props.videoQuality} {props.frameRate}
                    </Text>
                </View>
            </View>
            <View
                style={{
                    flex: 1 / 2,
                    alignItems: 'center',
                }}>
                <SubatomicTouchableOpacitySVG
                    buttonStyles={{
                        flex: 1,
                        marginTop: '25%',
                        justifyContent: 'center',
                    }}
                    svg={<Back />}
                    onPress={props.onPressBack}
                />
            </View>
        </View>
    );
}

export default VideoNotch;
