//MOSTLY NOT MY WORK
import React from 'react';
import {View, Text} from 'react-native';
import {SubatomicTouchableOpacityPNG} from '../../subatomic/index';

function TrainingModuleBox(props) {
    return (
        <View>
            <SubatomicTouchableOpacityPNG
                png={props.modulePNG}
                onPress={props.moduleOnPress}
                touchableOpacityStyle={props.touchableOpacityStyle}
                imageStyle={props.imageStyle}
            />
            <View style={{position: 'absolute'}}>
                <Text style={props.moduleTitleStyle}>{props.title}</Text>
            </View>
        </View>
    );
}

export default TrainingModuleBox;
