import React from 'react';
import {View, TextInput} from 'react-native';

function ViewAndTextInput(props) {
    return (
        <View style={props.textInputViewStyles}>
            <TextInput
                style={props.textInputStyles}
                onChangeText={props.attributes.onChangeText}
                value={props.attributes.value}
                placeholder={props.attributes.placeholder}
                secureTextEntry={props.attributes.secureTextEntry}
                placeholderTextColor={props.attributes.placeholderTextColor}
                autoCapitalize={props.attributes.autoCapitalize}
            />
        </View>
    );
}

export default ViewAndTextInput;
