import React from 'react';
import {View, Text} from 'react-native';

function HeaderAndSubheader(props) {
    return (
        <View style={props.textView}>
            <View style={props.headerView}>
                <Text style={props.headerStyles}>{props.header}</Text>
            </View>
            <View style={props.subheaderView}>
                <Text style={props.subheaderStyles}>{props.subheader}</Text>
            </View>
        </View>
    );
}

export default HeaderAndSubheader;
