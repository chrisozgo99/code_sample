//ENTIRELY NOT MY WORK
import React from 'react';
import {View, Text, StyleSheet, Linking} from 'react-native';

function TermsConditions(props) {
    return (
        <View>
            <Text style={styles.group}>
                <Text
                    style={styles.link}
                    onPress={() =>
                        Linking.openURL('https://drillsandskills.page.link/ToS')
                    }>
                    Terms & Conditions
                </Text>
                <Text style={styles.text}> and</Text>
                <Text
                    style={styles.link}
                    onPress={() =>
                        Linking.openURL(
                            'https://drillsandskills.page.link/Privacy',
                        )
                    }>
                    {' '}
                    Privacy Policy
                </Text>
                <Text style={styles.text}>
                    {'\n'}Paul Easton Basketball v1.0
                </Text>
            </Text>
        </View>
    );
}

const styles = StyleSheet.create({
    link: {
        color: '#E14821',
    },
    text: {
        color: '#000',
        lineHeight: 18,
    },
    group: {
        fontFamily: 'AmericanAuto-Regular',
        fontSize: 12,
        textAlign: 'center',
    },
});

export default TermsConditions;
