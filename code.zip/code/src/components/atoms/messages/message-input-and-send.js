/* eslint-disable react-native/no-inline-styles */
import React from 'react';
import {View, TextInput} from 'react-native';
import {SubatomicTouchableOpacitySVG} from '../../subatomic/index';

import Send from '_assets/images/app/messages/send.svg';
import Attachment from '_assets/images/app/messages/attachment.svg';

function MessageInputAndSend(props) {
    return (
        <View
            style={{
                flexDirection: 'row',
                width: '100%',
                marginBottom: 0,
                alignSelf: 'center',
                zIndex: 1,
                backgroundColor: 'white',
            }}>
            <View
                style={{
                    position: 'relative',
                    borderColor: '#E14821',
                    borderWidth: 2,
                    borderRadius: 35,
                    alignItems: 'center',
                    width: '65%',
                    marginLeft: '3%',
                }}>
                <TextInput
                    style={{
                        width: '100%',
                        paddingHorizontal: 17,
                        marginTop: 3,
                        paddingTop: 17,
                        paddingBottom: 17,
                        fontSize: 16,
                        maxHeight: 200,
                    }}
                    placeholder={props.placeholder}
                    placeholderTextColor={'black'}
                    onChangeText={props.onChangeText}
                    value={props.value}
                    multiline={true}
                    scrollEnabled={true}
                    textAlignVertical="top"
                    autoCapitalize={'sentences'}
                />
            </View>
            <View style={{justifyContent: 'center'}}>
                <SubatomicTouchableOpacitySVG
                    onPress={props.onPressAttachment}
                    buttonStyles={{
                        paddingLeft: '2%',
                        paddingRight: '4%',
                        alignItems: 'center',
                    }}
                    svg={<Attachment />}
                />
            </View>
            <View style={{justifyContent: 'center'}}>
                <SubatomicTouchableOpacitySVG
                    onPress={props.sendMessage}
                    buttonStyles={{
                        marginLeft: '2%',
                        marginRight: '2%',
                    }}
                    svg={<Send />}
                />
            </View>
        </View>
    );
}

export default MessageInputAndSend;
