/* eslint-disable react-native/no-inline-styles */
import React, {useState} from 'react';
import {View, Text, Platform} from 'react-native';
import {SubatomicProfilePic} from '../../subatomic/index';
import {convertTimestampToReadableDate} from '_utils';
import Video from 'react-native-video';
import VideoPlayer from 'react-native-video-controls';

function MessageContents(props) {
    const [paused, setPaused] = useState(true);
    const profilePhoto = (
        <SubatomicProfilePic
            size={36}
            styles={{
                position: 'absolute',
                bottom: 0,
                marginBottom: '1.5%',
                marginLeft: '2.5%',
            }}
            source={
                props.convo._details.client.value === props.user._userID
                    ? props.convo._details.trainer.profilePic
                    : props.convo._details.client.profilePic
            }
        />
    );
    if (props.message._content.type === 'text') {
        return (
            <View>
                {props.message._sentBy !== props.user._userID
                    ? profilePhoto
                    : null}
                <View
                    style={{
                        marginVertical: '1.5%',
                        marginLeft:
                            props.message._sentBy === props.user._userID
                                ? '11.5%'
                                : '13.5%',
                        marginRight:
                            props.message._sentBy === props.user._userID
                                ? '3%'
                                : '15.5%',
                        alignSelf:
                            props.message._sentBy === props.user._userID
                                ? 'flex-end'
                                : 'flex-start',
                        borderWidth: 1,
                        borderTopRightRadius:
                            props.message._sentBy === props.user._userID
                                ? 32
                                : 32,
                        borderTopLeftRadius:
                            props.message._sentBy === props.user._userID
                                ? 32
                                : 32,
                        borderBottomRightRadius:
                            props.message._sentBy === props.user._userID
                                ? 0
                                : 32,
                        borderBottomLeftRadius:
                            props.message._sentBy === props.user._userID
                                ? 32
                                : 0,
                        borderColor: 'white',
                        backgroundColor:
                            props.message._sentBy === props.user._userID
                                ? '#E14821'
                                : '#E4E4E4',
                    }}>
                    <Text
                        style={{
                            margin: '5%',
                            marginHorizontal: '10%',
                            fontFamily: 'AmericanAuto-Regular',
                            fontSize: 16,
                            color:
                                props.message._sentBy === props.user._userID
                                    ? 'white'
                                    : 'black',
                        }}>
                        {props.message._content.contents}
                    </Text>
                    <Text
                        style={{
                            marginBottom: '2%',
                            marginHorizontal: '10%',
                            fontFamily: 'AmericanAuto-Regular',
                            fontSize: 11,
                            color:
                                props.message._sentBy === props.user._userID
                                    ? 'white'
                                    : 'black',
                        }}>
                        {convertTimestampToReadableDate(props.message._sentAt)}
                    </Text>
                </View>
            </View>
        );
    } else if (props.message._content.type === 'video') {
        return (
            <View>
                {props.message._sentBy !== props.user._userID
                    ? profilePhoto
                    : null}
                <View
                    style={{
                        marginLeft:
                            props.message._sentBy === props.user._userID
                                ? '27%'
                                : '13.5%',
                        height: 300,
                        width: 262,
                        marginVertical: '1.5%',
                        borderRadius: 33,
                        backgroundColor:
                            props.message._sentBy === props.user._userID
                                ? '#E14821'
                                : '#E4E4E4',
                    }}>
                    {Platform.OS === 'android' ? (
                        <VideoPlayer
                            source={{
                                uri: props.message._content.contents,
                                type: 'mp4',
                            }}
                            navigator={props.navigation}
                            disableBack
                            onPlay={() => setPaused(false)}
                            onPause={() => setPaused(true)}
                            onEnd={() => setPaused(true)}
                            paused={paused}
                            seekColor={'E14821'}
                            style={{
                                height: '100%',
                                width: '100%',
                                borderRadius: 33,
                            }}
                        />
                    ) : (
                        <Video
                            source={{
                                uri: props.message._content.contents,
                                type: 'mp4',
                            }}
                            onError={e => console.log(e)}
                            controls={true}
                            paused={paused}
                            playWhenInactive={true}
                            resizeMode="contain"
                            ignoreSilentSwitch={'ignore'}
                            muted={false}
                            style={{
                                height: '100%',
                                width: '100%',
                                borderRadius: 33,
                            }}
                        />
                    )}
                </View>
            </View>
        );
    }
}

export default MessageContents;
