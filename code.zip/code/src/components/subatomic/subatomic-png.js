import React from 'react';
import {TouchableOpacity, View, Image} from 'react-native';

function SubatomicTouchableOpacityPNG(props) {
    return (
        <View>
            <TouchableOpacity
                style={props.touchableOpacityStyle}
                onPress={props.onPress}>
                <Image style={props.imageStyle} source={props.png} />
            </TouchableOpacity>
        </View>
    );
}

export default SubatomicTouchableOpacityPNG;
