import React from 'react';
import {View, TouchableOpacity} from 'react-native';

function SubatomicTouchableOpacitySVG(props) {
    return (
        <View style={props.buttonStyles}>
            <TouchableOpacity onPress={props.onPress}>
                {props.svg}
            </TouchableOpacity>
        </View>
    );
}

export default SubatomicTouchableOpacitySVG;
