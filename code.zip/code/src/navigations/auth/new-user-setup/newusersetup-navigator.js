//NOT MY WORK
import {createStackNavigator} from 'react-navigation-stack';

import PlayerSetupNavigator from './user-type-navigators/playersetup-navigator';
import TrainerSetupNavigator from './user-type-navigators/trainersetup-navigator';
import CoachSetupNavigator from './user-type-navigators/coachsetup-navigator';
import SelectAccountScreen from '_scenes/auth/new-user-setup/select-account-type';
import CreateProfileScreen from '_scenes/auth/new-user-setup/create-profile';

const NewUserSetupNavigatorConfig = {
    initialRouteName: 'SelectAccount',
    header: null,
    headerMode: 'none',
    defaultNavigationOptions: {
        gestureEnabled: false,
    },
};

const RouteConfigs = {
    SelectAccount: {
        screen: SelectAccountScreen,
    },
    CreateProfile: {
        screen: CreateProfileScreen,
    },
    PlayerSetup: PlayerSetupNavigator,
    TrainerSetup: TrainerSetupNavigator,
    CoachSetup: CoachSetupNavigator,
};

const NewUserSetupNavigator = createStackNavigator(
    RouteConfigs,
    NewUserSetupNavigatorConfig,
);

export default NewUserSetupNavigator;
