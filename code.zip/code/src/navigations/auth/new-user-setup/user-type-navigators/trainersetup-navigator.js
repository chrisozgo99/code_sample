//NOT MY WORK
import {createStackNavigator} from 'react-navigation-stack';

import TrainerProfilePhotoScreen from '_scenes/auth/new-user-setup/trainer-auth/trainer-profile-photo';
import ReceiveVideosScreen from '_scenes/auth/new-user-setup/trainer-auth/receive-videos';
import ProvideFeedbackScreen from '_scenes/auth/new-user-setup/trainer-auth/provide-feedback';

const TrainerSetupNavigatorConfig = {
    initialRouteName: 'TrainerProfilePhoto',
    header: null,
    headerMode: 'none',
    defaultNavigationOptions: {
        gestureEnabled: false,
    },
};

const RouteConfigs = {
    TrainerProfilePhoto: {
        screen: TrainerProfilePhotoScreen,
    },
    ReceiveVideos: {
        screen: ReceiveVideosScreen,
    },
    ProvideFeedback: {
        screen: ProvideFeedbackScreen,
    },
};

const TrainerSetupNavigator = createStackNavigator(
    RouteConfigs,
    TrainerSetupNavigatorConfig,
);

export default TrainerSetupNavigator;
