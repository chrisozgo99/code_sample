//NOT MY WORK
import {createStackNavigator} from 'react-navigation-stack';

import CoachProfilePhotoScreen from '_scenes/auth/new-user-setup/coach-auth/coach-profile-photo';
import CoachTutorialScreen from '_scenes/auth/new-user-setup/coach-auth/coach-tutorial';

const CoachSetupNavigatorConfig = {
    initialRouteName: 'CoachProfilePhoto',
    header: null,
    headerMode: 'none',
    defaultNavigationOptions: {
        gestureEnabled: false,
    },
};

const RouteConfigs = {
    CoachProfilePhoto: {
        screen: CoachProfilePhotoScreen,
    },
    CoachTutorial: {
        screen: CoachTutorialScreen,
    },
};

const CoachSetupNavigator = createStackNavigator(
    RouteConfigs,
    CoachSetupNavigatorConfig,
);

export default CoachSetupNavigator;
