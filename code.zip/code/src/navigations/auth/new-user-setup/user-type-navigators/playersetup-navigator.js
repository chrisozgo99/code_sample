//NOT MY WORK
import {createStackNavigator} from 'react-navigation-stack';

import CompletePlayerProfileScreen from '_scenes/auth/new-user-setup/player-auth/complete-player-profile';
import PlayerProfilePhotoScreen from '_scenes/auth/new-user-setup/player-auth/player-profile-photo';
import SubscribeScreen from '_scenes/auth/new-user-setup/player-auth/subscribe';
import DevelopYourSkillsScreen from '_scenes/auth/new-user-setup/player-auth/develop-your-skills';
import RecordYourselfScreen from '_scenes/auth/new-user-setup/player-auth/record-yourself';
import RequestFeedbackScreen from '_scenes/auth/new-user-setup/player-auth/request-feedback';

const PlayerSetupNavigatorConfig = {
    initialRouteName: 'CompletePlayerProfile',
    header: null,
    headerMode: 'none',
    defaultNavigationOptions: {
        gestureEnabled: false,
    },
};

const RouteConfigs = {
    CompletePlayerProfile: {
        screen: CompletePlayerProfileScreen,
    },
    PlayerProfilePhoto: {
        screen: PlayerProfilePhotoScreen,
    },
    DevelopYourSkills: {
        screen: DevelopYourSkillsScreen,
    },
    RecordYourself: {
        screen: RecordYourselfScreen,
    },
    RequestFeedback: {
        screen: RequestFeedbackScreen,
    },
    Subscribe: {
        screen: SubscribeScreen,
    },
};

const PlayerSetupNavigator = createStackNavigator(
    RouteConfigs,
    PlayerSetupNavigatorConfig,
);

export default PlayerSetupNavigator;
