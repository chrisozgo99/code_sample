//NOT MY WORK
import {createStackNavigator} from 'react-navigation-stack';

import NewUserSetupNavigator from './new-user-setup/newusersetup-navigator';

import LandingScreen from '_scenes/auth/landing';
import LoginScreen from '_scenes/auth/login';
import ForgotPasswordScreen from '_scenes/auth/forgot-password';
import LoadingScreen from '_scenes/auth/loading';

const AuthNavigatorConfig = {
    initialRouteName: 'Loading',
    header: null,
    headerMode: 'none',
    defaultNavigationOptions: {
        gestureEnabled: false,
    },
};

const RouteConfigs = {
    Loading: {
        screen: LoadingScreen,
    },
    Landing: {
        screen: LandingScreen,
    },
    Login: {
        screen: LoginScreen,
    },
    SelectAccount: {
        screen: NewUserSetupNavigator,
    },
    ForgotPassword: {
        screen: ForgotPasswordScreen,
    },
};

const AuthNavigator = createStackNavigator(RouteConfigs, AuthNavigatorConfig);

export default AuthNavigator;
