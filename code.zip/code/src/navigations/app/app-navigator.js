//ABOUT 50% MY WORK
/* eslint-disable react-native/no-inline-styles */
import React from 'react';
import {View} from 'react-native';
import Profile from '_assets/images/app/nav-bar/user-profile-icon.svg';
import ProfileSelected from '_assets/images/app/nav-bar/user-profile-icon-selected.svg';
import JumpshotTutor from '_assets/images/app/nav-bar/jumpshot-tutor-icon.svg';
import JumpshotTutorSelected from '_assets/images/app/nav-bar/jumpshot-tutor-icon-selected.svg';
import Training from '_assets/images/app/nav-bar/training-icon.svg';
import TrainingSelected from '_assets/images/app/nav-bar/training-icon-selected.svg';
import Messages from '_assets/images/app/nav-bar/messages-icon.svg';
import MessagesSelected from '_assets/images/app/nav-bar/messages-icon-selected.svg';
import Shop from '_assets/images/app/nav-bar/shop-icon.svg';
import ShopSelected from '_assets/images/app/nav-bar/shop-icon-selected.svg';

import {createBottomTabNavigator} from 'react-navigation-tabs';

import ProfileNavigator from './tab-navigators/profile-navigator';
import JumpshotTutorNavigator from './tab-navigators/jumpshot-tutor-navigator';
import TrainingNavigator from './tab-navigators/training-navigator';
import MessagesNavigator from './tab-navigators/messages-navigator';
import ShopNavigator from './tab-navigators/shop-navigator';

const TabNavigatorConfig = {
    initialRouteName: 'TrainingScreen',
    header: null,
    headerMode: 'none',
    animationEnabled: false,
    tabBarOptions: {
        activeTintColor: 'orange',
        keyboardHidesTabBar: true,
        showLabel: false,
        style: {
            backgroundColor: '#e14218',
        },
    },
};

const RouteConfigs = {
    ViewProfileScreen: {
        screen: ProfileNavigator,
        navigationOptions: ({navigation}) => ({
            tabBarIcon: ({focused, color, size}) => {
                if (focused) {
                    return (
                        <View style={{height: 8, width: 30, marginLeft: 10}}>
                            <ProfileSelected />
                        </View>
                    );
                } else {
                    return (
                        <View style={{height: 8, width: 30, marginLeft: 10}}>
                            <Profile />
                        </View>
                    );
                }
            },
            title: 'Profile',
            animationEnabled: false,
        }),
    },
    JumpshotTutorScreen: {
        screen: JumpshotTutorNavigator,
        navigationOptions: ({navigation}) => ({
            tabBarIcon: ({focused, color, size}) => {
                if (focused) {
                    return (
                        <View style={{height: 8, width: 30, marginLeft: 0}}>
                            <JumpshotTutorSelected />
                        </View>
                    );
                } else {
                    return (
                        <View style={{height: 8, width: 30, marginLeft: 0}}>
                            <JumpshotTutor />
                        </View>
                    );
                }
            },
            title: 'Jumpshot Tutor',
            animationEnabled: false,
        }),
    },
    TrainingScreen: {
        screen: TrainingNavigator,
        navigationOptions: ({navigation}) => ({
            tabBarIcon: ({focused, color, size}) => {
                if (focused) {
                    return (
                        <View style={{height: 20, width: 30, marginLeft: 0}}>
                            <TrainingSelected />
                        </View>
                    );
                } else {
                    return (
                        <View style={{height: 20, width: 30, marginLeft: 0}}>
                            <Training />
                        </View>
                    );
                }
            },
            title: 'Training',
            animationEnabled: false,
        }),
    },
    MessagesScreen: {
        screen: MessagesNavigator,
        navigationOptions: ({navigation}) => ({
            tabBarIcon: ({focused, color, size}) => {
                if (focused) {
                    return (
                        <View style={{height: 5, width: 30, marginLeft: 0}}>
                            <MessagesSelected />
                        </View>
                    );
                } else {
                    return (
                        <View style={{height: 5, width: 30, marginLeft: 0}}>
                            <Messages />
                        </View>
                    );
                }
            },
            title: 'Messages',
            animationEnabled: false,
        }),
    },
    ShopScreen: {
        screen: ShopNavigator,
        navigationOptions: ({navigation}) => ({
            tabBarIcon: ({focused, color, size}) => {
                if (focused) {
                    return (
                        <View style={{height: 15, width: 30, marginLeft: 10}}>
                            <ShopSelected />
                        </View>
                    );
                } else {
                    return (
                        <View style={{height: 15, width: 30, marginLeft: 10}}>
                            <Shop />
                        </View>
                    );
                }
            },
            title: 'Shop',
            animationEnabled: false,
        }),
    },
};

const AppNavigator = createBottomTabNavigator(RouteConfigs, TabNavigatorConfig);

export default AppNavigator;
