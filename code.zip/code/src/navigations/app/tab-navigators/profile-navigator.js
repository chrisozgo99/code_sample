//ABOUT 50% MY WORK
import {createStackNavigator} from 'react-navigation-stack';

import ViewProfileScreen from '_scenes/app/profile/view-profile';
import EditProfileScreen from '_scenes/app/profile/edit-profile';
import MembershipScreen from '_scenes/app/profile/membership';
import ChangePasswordScreen from '_scenes/app/profile/change-password';
import SkillProgressionProgressScreen from '_scenes/app/profile/skill-progression-progress';
import PayMembershipScreen from '_scenes/app/profile/pay-membership';

const ProfileNavigatorConfig = {
    initialRouteName: 'ViewProfile',
    header: null,
    headerMode: 'none',
};

const RouteConfigs = {
    ViewProfile: {
        screen: ViewProfileScreen,
    },
    EditProfile: {
        screen: EditProfileScreen,
    },
    Membership: {
        screen: MembershipScreen,
    },
    PayMembership: {
        screen: PayMembershipScreen,
    },
    ChangePassword: {
        screen: ChangePasswordScreen,
    },
    SkillProgressionProgress: {
        screen: SkillProgressionProgressScreen,
    },
};

const ProfileNavigator = createStackNavigator(
    RouteConfigs,
    ProfileNavigatorConfig,
);

ProfileNavigator.navigationOptions = ({navigation}) => {
    let tabBarVisible;
    if (navigation.state.routes.length >= 1) {
        navigation.state.routes.map(route => {
            if (
                route.routeName === 'SkillProgressionProgress' ||
                route.routeName === 'EditProfilePage'
            ) {
                tabBarVisible = false;
            } else {
                tabBarVisible = true;
            }
        });
    }
    return {
        tabBarVisible,
    };
};

export default ProfileNavigator;
