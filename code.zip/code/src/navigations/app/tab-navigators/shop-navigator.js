//NOT MY WORK
import {createStackNavigator} from 'react-navigation-stack';

import ShopScreen from '_scenes/app/shop/view-shop';

const ShopNavigatorConfig = {
    initialRouteName: 'Shop',
    header: null,
    headerMode: 'none',
};

const RouteConfigs = {
    Shop: {
        screen: ShopScreen,
    },
};

const ShopNavigator = createStackNavigator(RouteConfigs, ShopNavigatorConfig);

export default ShopNavigator;
