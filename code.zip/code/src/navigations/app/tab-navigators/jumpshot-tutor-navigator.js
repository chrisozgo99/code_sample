import {createStackNavigator} from 'react-navigation-stack';

import ViewJumpshotTutorScreen from '_scenes/app/jumpshot-tutor/view-jumpshot-tutor';

const JumpshotTutorNavigatorConfig = {
    initialRouteName: 'ViewJumpshotTutor',
    header: null,
    headerMode: 'none',
};

const RouteConfigs = {
    ViewJumpshotTutor: {
        screen: ViewJumpshotTutorScreen,
    },
};

const JumpshotTutorNavigator = createStackNavigator(
    RouteConfigs,
    JumpshotTutorNavigatorConfig,
);

export default JumpshotTutorNavigator;
