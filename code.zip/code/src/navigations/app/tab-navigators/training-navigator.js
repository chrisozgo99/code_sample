//MOSTLY MY WORK
import {createStackNavigator, TransitionSpecs} from 'react-navigation-stack';

import TrainingModulesScreen from '_scenes/app/training/training-pages/training-modules-list';
import ExtraScreen from '_scenes/app/training/extra';
import AboutScreen from '_scenes/app/training/about';
import ModuleScreen from '_scenes/app/training/training-pages/module';
import VideoScreen from '_scenes/app/training/training-pages/video';
import RecordVideoScreen from '_scenes/app/training/training-pages/record-video';
import ReviewVideoScreen from '_scenes/app/training/training-pages/review-video';

const TrainingNavigatorConfig = {
    initialRouteName: 'TrainingModules',
    header: null,
    headerMode: 'none',
    gestureDirection: 'horizontal',
    defaultNavigationOptions: ({navigation}) => ({
        animationEnabled: true,
    }),
};

const RouteConfigs = {
    TrainingModules: {
        screen: TrainingModulesScreen,
        navigationOptions: {
            animationEnabled: false,
        },
    },
    Extra: {
        screen: ExtraScreen,
        navigationOptions: {
            animationEnabled: false,
        },
    },
    About: {
        screen: AboutScreen,
        navigationOptions: {
            animationEnabled: false,
        },
    },
    Module: {
        screen: ModuleScreen,
    },
    Video: {
        screen: VideoScreen,
    },
    RecordVideo: {
        screen: RecordVideoScreen,
    },
    ReviewVideo: {
        screen: ReviewVideoScreen,
    },
};

const TrainingNavigator = createStackNavigator(
    RouteConfigs,
    TrainingNavigatorConfig,
);

TrainingNavigator.navigationOptions = ({navigation}) => {
    let tabBarVisible;
    if (navigation.state.routes.length >= 1) {
        navigation.state.routes.map(route => {
            if (
                route.routeName === 'RecordVideo' ||
                route.routeName === 'Video' ||
                route.routeName === 'ReviewVideo'
            ) {
                tabBarVisible = false;
            } else {
                tabBarVisible = true;
            }
        });
    }
    return {
        tabBarVisible,
    };
};

export default TrainingNavigator;
