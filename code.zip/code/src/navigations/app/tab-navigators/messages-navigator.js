//ABOUT 50% MY WORK
import {createStackNavigator} from 'react-navigation-stack';

import MessagesScreen from '_scenes/app/messages/view-messages';
import ConversationScreen from '_scenes/app/messages/conversation';

const MessagesNavigatorConfigs = {
    initialRouteName: 'Messages',
    header: null,
    headerMode: 'none',
};

const RouteConfigs = {
    Messages: {
        screen: MessagesScreen,
    },
    Conversation: {
        screen: ConversationScreen,
        options: {
            tabBarVisible: false,
        },
    },
};

const MessagesNavigator = createStackNavigator(
    RouteConfigs,
    MessagesNavigatorConfigs,
);

MessagesNavigator.navigationOptions = ({navigation}) => {
    let tabBarVisible;
    if (navigation.state.routes.length >= 1) {
        navigation.state.routes.map(route => {
            if (route.routeName === 'Conversation') {
                tabBarVisible = false;
            } else {
                tabBarVisible = true;
            }
        });
    }
    return {
        tabBarVisible,
    };
};

export default MessagesNavigator;
