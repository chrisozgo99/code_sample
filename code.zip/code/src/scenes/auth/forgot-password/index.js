//NOT MY WORK
import React, {useState} from 'react';
import {View, Alert} from 'react-native';
import {ForgotPassword} from '_organisms';
import styles from './styles';
import Back from '_assets/images/orange-back.svg';
import ResetPassword from '_assets/images/auth/forgot-password/reset-password.svg';

import {requestPasswordResetEmail} from '_services';

function ForgotPasswordScreen({navigation}) {
    const user = navigation.state;
    const [email, setEmail] = useState('');
    const [error, setError] = useState('');

    return (
        <View>
            <ForgotPassword
                bg={require('_assets/images/auth/login/basketball-grey.png')}
                styles={styles}
                back={<Back />}
                onPressBack={() => {
                    navigation.navigate('Login');
                }}
                email={email}
                onChangeEmailText={text => setEmail(text)}
                loginOnPress={() => {
                    let response = requestPasswordResetEmail(email);
                    response.then(err => {
                        if (typeof err === 'string') {
                            Alert.alert(err);
                        } else {
                            // Create an alert if the email does not error saying it is sent and navigating back to the home page.
                            // Does not check to see if email is in database (to avoid hackers seeing all the emails in the database).
                            Alert.alert(
                                'Message Sent',
                                'If this email account is signed up, a message has been sent. Please follow the instructions in the link and then sign in again.',
                                [
                                    {
                                        text: 'Back to Login',
                                        onPress: () => {
                                            navigation.navigate('Login');
                                        },
                                    },
                                ],
                                {cancelable: false},
                            );
                        }
                    });
                }}
                loginSVG={<ResetPassword />}
            />
        </View>
    );
}

export default ForgotPasswordScreen;
