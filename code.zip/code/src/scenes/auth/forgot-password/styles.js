//NOT MY WORK
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
    topView: {
        width: '100%',
        height: '100%',
    },
    titleView: {},
    titleText: {
        fontFamily: 'AmericanAuto-Bold',
        fontSize: 50,
        textAlign: 'left',
        marginHorizontal: '10%',
        marginTop: '25%',
    },
    backButtonView: {
        paddingTop: '12%',
        paddingLeft: '86%',
        position: 'absolute',
        zIndex: 1,
    },
    textInputView: {
        marginHorizontal: '10%',
        borderBottomWidth: 2,
        borderColor: '#000',
    },
    textInput: {
        fontFamily: 'AmericanAuto-Regular',
        fontSize: 20,
        paddingVertical: '5%',
    },
    bgView: {
        height: '115%',
        width: '115%',
        position: 'absolute',
        opacity: 1,
        resizeMode: 'cover',
    },
    bgImage: {
        height: '100%',
        width: '100%',
    },
    loginView: {
        marginTop: '85%',
        alignSelf: 'center',
    },
});

export default styles;
