//MOSTLY MY WORK
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
    topView: {
        height: '100%',
        width: '100%',
        flex: 1,
        backgroundColor: 'black',
    },
    bgView: {
        height: '100%',
        width: '100%',
        position: 'absolute',
        opacity: 1,
        resizeMode: 'cover',
    },
    bgImage: {
        paddingBottom: '40%',
        height: '100%',
        width: '100%',
    },
    title: {
        marginTop: '30%',
        flex: 1,
    },
    white: {
        color: 'white',
        fontSize: 74,
        fontFamily: 'AmericanAuto-Bold',
        textAlign: 'center',
        lineHeight: 74,
        marginTop: '-5%',
    },
    orange: {
        color: '#e14821',
        fontSize: 50,
        fontFamily: 'AmericanAuto-Bold',
        textAlign: 'center',
        marginTop: '-2%',
    },
    subtitle: {
        color: 'white',
        marginHorizontal: '6%',
        textAlign: 'center',
        fontFamily: 'AmericanAuto-Regular',
        lineHeight: 26,
        fontSize: 16,
        marginBottom: '0%',
    },
    subtitleView: {
        flex: 1.5,
        marginTop: '0%',
    },
    buttonView: {
        marginTop: '0%',
        marginBottom: '10%',
        position: 'absolute',
        bottom: 0,
        width: '100%',
    },
    loginButtonView: {
        marginTop: '5%',
        marginBottom: '10%',
    },
    buttonStyles: {
        justifyContent: 'center',
        alignItems: 'center',
    },
});

export default styles;
