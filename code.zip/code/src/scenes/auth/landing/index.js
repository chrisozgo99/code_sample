//MOSTLY MY WORK
import React from 'react';
import {View, StatusBar} from 'react-native';
import SignIn from '_assets/images/auth/landing/sign-in.svg';
import CreateAccount from '_assets/images/auth/landing/create-account.svg';
import {Landing} from '_organisms';
import styles from './styles';

function LandingScreen({navigation}) {
    return (
        <View style={{flex: 1}}>
            <StatusBar barStyle="light-content" />
            <Landing
                bg={require('_assets/images/auth/landing/bg.jpg')}
                createAccount={<CreateAccount />}
                signIn={<SignIn />}
                navigation={navigation}
                styles={styles}
            />
        </View>
    );
}

export default LandingScreen;
