//NOT MY WORK
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
    topView: {
        height: '100%',
        width: '100%',
    },
    bgView: {
        height: '100%',
        width: '100%',
        position: 'absolute',
        opacity: 1,
        resizeMode: 'cover',
    },
    bgImage: {
        height: '100%',
        width: '100%',
    },
    title: {
        marginTop: '30%',
        flex: 1,
    },
    white: {
        color: 'white',
        fontSize: 74,
        fontFamily: 'AmericanAuto-Bold',
        textAlign: 'center',
        lineHeight: 74,
        marginTop: '-5%',
    },
    orange: {
        color: '#e14821',
        fontSize: 50,
        fontFamily: 'AmericanAuto-Bold',
        textAlign: 'center',
        marginTop: '-2%',
    },
    subtitle: {
        color: 'white',
        marginHorizontal: '6%',
        textAlign: 'center',
        fontFamily: 'AmericanAuto-Regular',
        lineHeight: 26,
        fontSize: 16,
        marginBottom: '0%',
    },
    buttonView: {
        marginTop: '13%',
        marginBottom: '00%',
        flex: 1,
    },
    activityText: {
        color: '#e14821',
        textAlign: 'center',
        fontWeight: 'bold',
        paddingTop: 16,
    },
});

export default styles;
