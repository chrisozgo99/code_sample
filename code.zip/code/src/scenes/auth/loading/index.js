//NOT MY WORK
import React, {useState} from 'react';
import {View, StatusBar} from 'react-native';
import {userIsSignedIn, generateUserForLogin} from '_services';
import {Loading} from '_organisms';
import styles from './styles';

function LoadingScreen({navigation}) {
    let userSignedIn = userIsSignedIn();
    const [loadingText, setLoadingText] = useState(
        userSignedIn ? 'Validate Login' : 'Navigating to landing page',
    );

    if (userSignedIn) {
        generateUserForLogin({navigation}, 'App');
    } else if (!userSignedIn) {
        navigation.navigate('Landing');
    }

    return (
        <View>
            <StatusBar barStyle="light-content" />
            <Loading
                styles={styles}
                bg={require('_assets/images/auth/landing/bg.jpg')}
                navigation={navigation}
                activityText={loadingText}
            />
        </View>
    );
}

export default LoadingScreen;
