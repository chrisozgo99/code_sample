//MOSTLY MY WORK
import React, {useState} from 'react';
import {View, Alert, StatusBar} from 'react-native';
import {SelectAccount} from '_organisms';
import PlayerOutline from '_assets/images/auth/select-account/player-outline.svg';
import CoachOutline from '_assets/images/auth/select-account/coach-outline.svg';
import TrainerOutline from '_assets/images/auth/select-account/trainer-outline.svg';
import PlayerSelected from '_assets/images/auth/select-account/player-selected.svg';
import CoachSelected from '_assets/images/auth/select-account/coach-selected.svg';
import TrainerSelected from '_assets/images/auth/select-account/trainer-selected.svg';

import Back from '_assets/images/white-back.svg';
import Next from '_assets/images/auth/white-next.svg';

import styles from './styles';

function SelectAccountScreen({navigation}) {
    const [playerSelected, setPlayerSelected] = useState(true);
    const [coachSelected, setCoachSelected] = useState(false);
    const [trainerSelected, setTrainerSelected] = useState(false);

    const dynamicStyles = {
        selectAccountTypeView: {
            marginVertical: '15%',
            margin: playerSelected
                ? '5%'
                : coachSelected
                ? '-5%'
                : trainerSelected
                ? '-15%'
                : '2.5',
            width: '110%',
            flexDirection: 'row',
            alignContent: 'center',
            justifyContent: 'space-between',
            flex: 1,
        },
    };

    const handleOnPress = () => {
        if (playerSelected) {
            navigation.navigate('CreateProfile', {
                userType: 'players',
            });
        } else if (coachSelected) {
            navigation.navigate('CreateProfile', {
                userType: 'coaches',
            });
        } else if (trainerSelected) {
            navigation.navigate('CreateProfile', {
                userType: 'trainers',
            });
        } else {
            Alert.alert('Please select your account type.');
        }
    };

    return (
        <View style={{flex: 1}}>
            <StatusBar barStyle="dark-content" />
            <SelectAccount
                bg={
                    playerSelected
                        ? require('_assets/images/auth/select-account/bg-player.png')
                        : coachSelected
                        ? require('_assets/images/auth/select-account/bg-coach.png')
                        : trainerSelected
                        ? require('_assets/images/auth/select-account/bg-trainer.png')
                        : require('_assets/images/auth/select-account/bg-player.png')
                }
                backSVG={<Back />}
                backOnPress={() => navigation.navigate('Landing')}
                title={'Account\nType'}
                playerSVG={
                    playerSelected ? <PlayerSelected /> : <PlayerOutline />
                }
                coachSVG={coachSelected ? <CoachSelected /> : <CoachOutline />}
                trainerSVG={
                    trainerSelected ? <TrainerSelected /> : <TrainerOutline />
                }
                playerSelected={playerSelected}
                onPressPlayer={() => {
                    setPlayerSelected(true);
                    setCoachSelected(false);
                    setTrainerSelected(false);
                }}
                coachSelected={coachSelected}
                onPressCoach={() => {
                    setCoachSelected(true);
                    setPlayerSelected(false);
                    setTrainerSelected(false);
                }}
                trainerSelected={trainerSelected}
                onPressTrainer={() => {
                    setTrainerSelected(true);
                    setPlayerSelected(false);
                    setCoachSelected(false);
                }}
                subtitle={
                    playerSelected
                        ? 'I want to get better at playing basketball.'
                        : coachSelected
                        ? 'I want to get better at coaching basketball.'
                        : trainerSelected
                        ? "I am one of Paul Easton's trainers."
                        : ''
                }
                nextSVG={<Next />}
                nextOnPress={() => handleOnPress()}
                styles={styles}
                dynamicStyles={dynamicStyles}
            />
        </View>
    );
}

export default SelectAccountScreen;
