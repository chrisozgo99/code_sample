//MOSTLY NOT MY WORK
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
    topView: {
        height: '100%',
        width: '100%',
        backgroundColor: 'grey',
        flex: 1,
    },
    bgView: {
        height: '100%',
        width: '100%',
        position: 'absolute',
        opacity: 1,
        resizeMode: 'cover',
    },
    bgImage: {
        height: '100%',
        width: '100%',
    },
    backView: {
        paddingTop: '12%',
        paddingLeft: '86%',
        position: 'absolute',
        zIndex: 1,
    },
    titleView: {
        width: '100%',
    },
    title: {
        width: '100%',
        paddingLeft: '9.6%',
        paddingTop: '20%',
        textAlign: 'left',
        fontSize: 55,
        fontFamily: 'AmericanAuto-Bold',
        color: '#FFFFFF',
        opacity: 1,
    },
    subtitleView: {
        flex: 1,
        marginBottom: '20%',
    },
    subtitleText: {
        textAlign: 'center',
        fontFamily: 'AmericanAuto-Bold',
        fontSize: 18,
        color: '#FFFFFF',
    },
    nextView: {
        position: 'absolute',
        bottom: 0,
        width: '100%',
        marginBottom: '15%',
        flex: 1,
    },
    buttonStyles: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    buttonView: {
        flex: 1,
    },
});

export default styles;
