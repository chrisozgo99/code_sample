//NOT MY WORK
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
    mainView: {
        height: '100%',
        width: '100%',
    },
    backButtonView: {
        paddingTop: '12%',
        paddingLeft: '86%',
        position: 'absolute',
        zIndex: 1,
    },
    titleView: {},
    title: {
        width: '100%',
        paddingTop: '20%',
        paddingLeft: '9.6%',
        textAlign: 'left',
        fontSize: 55,
        fontFamily: 'AmericanAuto-Bold',
        opacity: 1,
    },
    textInputView: {
        marginHorizontal: '10%',
        marginVertical: '3%',
    },
    textInputStyles: {},
    textInput: {
        fontSize: 20,
        borderWidth: 2,
        fontFamily: 'AmericanAuto-Regular',
        paddingBottom: '5%',
        borderBottomColor: 'black',
        borderTopColor: 'transparent',
        borderLeftColor: 'transparent',
        borderRightColor: 'transparent',
    },
    subtitleView: {},
    allBottomView: {
        // position: 'absolute',
        // bottom: 0,
        width: '100%',
        marginBottom: '15%',
    },
    subtitle: {
        fontFamily: 'AmericanAuto-Regular',
        fontSize: 12,
        textAlign: 'center',
        width: '100%',
        marginBottom: '10%',
    },
    nextButtonView: {},
    nextButton: {
        justifyContent: 'center',
        alignItems: 'center',
    },
});

export default styles;
