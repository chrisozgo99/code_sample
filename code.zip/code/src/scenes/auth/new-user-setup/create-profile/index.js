//ABOUT 50% MY WORK
/* eslint-disable react-native/no-inline-styles */
import React, {useState} from 'react';
import {ScrollView, View, StatusBar} from 'react-native';
import {CreateAccount} from '_molecules';
import Back from '_assets/images/orange-back.svg';
import Next from '_assets/images/auth/orange-next.svg';
import {createNewUserIsSuccessful} from '_services';
import styles from './styles';

function CreateProfileScreen({navigation}) {
    const userType = navigation.state.params.userType;

    const [firstName, setFirstName] = useState();
    const [lastName, setLastName] = useState();
    const [email, setEmail] = useState();
    const [password, setPassword] = useState();

    const firstNameInput = {
        onChangeText: text => setFirstName(text),
        value: firstName,
        placeholder: 'First Name',
    };

    const lastNameInput = {
        onChangeText: text => setLastName(text),
        value: lastName,
        placeholder: 'Last Name',
    };

    const emailInput = {
        onChangeText: text => setEmail(text),
        value: email,
        placeholder: 'Email',
        autoCapitalize: 'none',
    };

    const passwordInput = {
        onChangeText: text => setPassword(text),
        value: password,
        placeholder: 'Password',
        autoCapitalize: 'none',
        secureTextEntry: true,
    };

    const handleNext = () => {
        console.log('clicked');
        createNewUserIsSuccessful(
            email,
            password,
            firstName,
            lastName,
            {navigation},
            userType === 'players'
                ? 'CompletePlayerProfile'
                : userType === 'coaches'
                ? 'CoachProfilePhoto'
                : 'TrainerProfilePhoto',
            userType,
        );
    };

    return (
        <ScrollView
            contentContainerStyle={{
                flexGrow: 1,
            }}
            style={{flex: 1}}>
            <StatusBar barStyle="dark-content" />
            <CreateAccount
                styles={styles}
                back={<Back />}
                onPressBack={() => navigation.navigate('SelectAccount')}
                title={'Create\nYour Profile'}
                firstNameAttributes={firstNameInput}
                lastNameAttributes={lastNameInput}
                emailAttributes={emailInput}
                passwordAttributes={passwordInput}
                // subtitle={
                //     'By tapping "Next", you agree to our \nTerms & Conditions and Privacy Policy'
                // }
                next={<Next />}
                onPressNext={() => handleNext()}
            />
        </ScrollView>
    );
}

export default CreateProfileScreen;
