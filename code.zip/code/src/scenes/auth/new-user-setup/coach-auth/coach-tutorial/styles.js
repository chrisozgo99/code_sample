//NOT MY WORK
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
    mainView: {flex: 1},
    bgView: {
        height: '100%',
        width: '100%',
        position: 'absolute',
        opacity: 1,
        resizeMode: 'cover',
    },
    bgImage: {
        height: '100%',
        width: '100%',
    },
    backButtonView: {
        position: 'absolute',
        paddingTop: '12%',
        paddingLeft: '86%',
    },
    backButton: {},
    titleView: {},
    title: {
        width: '100%',
        paddingTop: '15%',
        paddingLeft: '9.6%',
        textAlign: 'left',
        fontSize: 50,
        fontFamily: 'AmericanAuto-Bold',
        opacity: 1,
    },
    subtitleView: {},
    subtitle: {
        fontSize: 16,
        fontFamily: 'AmericanAuto-Regular',
        paddingLeft: '9.6%',
        textAlign: 'left',
        lineHeight: 20,
    },
    imageView: {
        width: '100%',
        alignItems: 'center',
    },
    image: {
        height: 700,
        width: 510,
    },
    nextAndSkipView: {
        position: 'absolute',
        bottom: 0,
        width: '100%',
        backgroundColor: 'white',
        paddingBottom: '8%',
    },
    nextButtonView: {width: '100%'},
    nextButton: {
        justifyContent: 'center',
        alignItems: 'center',
        margin: '5%',
    },
    skipButtonView: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    skipButton: {
        fontFamily: 'AmericanAuto-Bold',
        fontSize: 16,
        color: '#E14821',
        textAlign: 'center',
    },
});

export default styles;
