//NOT MY WORK
import React from 'react';
import {View} from 'react-native';
import {Tutorial} from '_organisms';

import Back from '_assets/images/orange-back';

import styles from './styles';

function CoachTutorialScreen({navigation}) {
    const user = navigation.state.params.user;
    return (
        <View style={{flex: 1}}>
            <Tutorial
                bg={null}
                styles={styles}
                backOnPress={() => navigation.navigate('PlayerProfilePhoto')}
                backSVG={<Back />}
                title={'Watch\nVideos'}
                subtitle={
                    "Watch Paul Easton's curated video tutorials to\nimprove your coaching in all facets of the game.\nNew videos are added periodically."
                }
                image={require('_assets/images/auth/tutorials/develop-your-skills.png')}
                onPressNextAndSkip={() =>
                    navigation.navigate('App', {
                        user: user,
                    })
                }
            />
        </View>
    );
}

export default CoachTutorialScreen;
