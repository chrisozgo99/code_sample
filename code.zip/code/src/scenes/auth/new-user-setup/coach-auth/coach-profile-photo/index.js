//ALMOST ENTIRELY MY WORK
import React, {useState} from 'react';
import {View} from 'react-native';

import {AddProfilePhoto} from '_organisms';
import {pushImageToStorage, setDefaultImage} from '_services';

import Back from '_assets/images/back.svg';
import Next from '_assets/images/auth/landing/create-account.svg';
import styles from './styles';

function CoachProfilePhotoScreen({navigation}) {
    const user = navigation.state.params.user;
    const [profilePic, setProfilePic] = useState(user._profilePic);
    const profilePicAttributes = {
        profilePic: profilePic,
        onPress: image => setProfilePic(image.path),
        source:
            profilePic === ''
                ? 'https://firebasestorage.googleapis.com/v0/b/drills-and-skills.appspot.com/o/images%2Fprofile-pics%2Fblank-profile-picture.png?alt=media&token=86e354ea-5008-41e4-b7ba-0f3486b13fb8'
                : profilePic,
    };

    const handleNext = () => {
        if (profilePic === '') {
            setDefaultImage(user, {navigation}, 'CoachTutorial');
        } else {
            pushImageToStorage(profilePic, user, {navigation}, 'CoachTutorial');
        }
    };

    return (
        <View style={{flex: 1}}>
            <AddProfilePhoto
                title={'Add A\nProfile Photo'}
                subtitle="Put a face to your name."
                attributes={profilePicAttributes}
                onPressNext={() => handleNext()}
                next={<Next />}
                onPressSkip={() =>
                    setDefaultImage(user, {navigation}, 'CoachTutorial')
                }
                styles={styles}
            />
        </View>
    );
}

export default CoachProfilePhotoScreen;
