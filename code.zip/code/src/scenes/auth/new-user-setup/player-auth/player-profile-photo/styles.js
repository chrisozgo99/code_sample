//NOT MY WORK
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
    mainView: {
        flex: 1,
    },
    titleAndSubtitleView: {},
    titleView: {},
    title: {
        width: '100%',
        paddingTop: '20%',
        paddingLeft: '9.6%',
        textAlign: 'left',
        fontSize: 50,
        fontFamily: 'AmericanAuto-Bold',
        opacity: 1,
    },
    subtitleView: {},
    subtitle: {
        paddingLeft: '9.6%',
        fontSize: 20,
        fontFamily: 'AmericanAuto-Bold',
        color: '#E14821',
    },
    profilePhotoView: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    profilePicView: {},
    profilePic: {
        width: 200,
        height: 200,
        borderRadius: 100,
        justifyContent: 'center',
        alignContent: 'center',
        marginTop: '35%',
    },
    defaultImgMargin: {
        marginTop: '-10%',
    },
    nextAndSkipView: {
        position: 'absolute',
        bottom: 0,
        marginBottom: '10%',
        width: '100%',
    },
    nextButtonView: {
        width: '100%',
        justifyContent: 'center',
        alignItems: 'center',
    },
    nextButton: {
        marginBottom: '5%',
    },
    skipButtonView: {
        width: '100%',
    },
    skipStyles: {},
    skipButton: {
        fontFamily: 'AmericanAuto-Bold',
        fontSize: 16,
        color: '#E14821',
        textAlign: 'center',
    },
});

export default styles;
