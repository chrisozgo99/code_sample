import React from 'react';
import {View} from 'react-native';
import {Tutorial} from '_organisms';

import Back from '_assets/images/orange-back';

import styles from './styles';

function RequestFeedbackScreen({navigation}) {
    const user = navigation.state.params.user;
    console.log(user);
    return (
        <View style={{flex: 1}}>
            <Tutorial
                bg={null}
                backOnPress={() => navigation.navigate('RecordYourself')}
                backSVG={<Back />}
                title={"Request\nFeedback"}
                subtitle={
                    'Our trainers will grade your performance\nand provide tips and comments to help you\nrefine your skills.'
                }
                image={require('_assets/images/auth/tutorials/request-feedback.png')}
                onPressNextAndSkip={() =>
                    navigation.navigate('Subscribe', {
                        user: user,
                    })
                }
                styles={styles}
            />
        </View>
    );
}

export default RequestFeedbackScreen;
