//NOT MY WORK
import React from 'react';
import {View} from 'react-native';
import {Tutorial} from '_organisms';

import Back from '_assets/images/orange-back';

import styles from './styles';

function RecordYourselfScreen({navigation}) {
    const user = navigation.state.params.user;
    console.log(user);
    return (
        <View style={{flex: 1}}>
            <Tutorial
                bg={null}
                backOnPress={() => navigation.navigate('DevelopYourSkills')}
                backSVG={<Back />}
                title={"Record\nYourself"}
                subtitle={
                    'Want customized feedback based on your\n performance? Record a video of yourself\npracticing a drill and submit it for review'
                }
                image={require('_assets/images/auth/tutorials/record-yourself.png')}
                onPressNextAndSkip={() =>
                    navigation.navigate('RequestFeedback', {
                        user: user,
                    })
                }
                styles={styles}
            />
        </View>
    );
}

export default RecordYourselfScreen;
