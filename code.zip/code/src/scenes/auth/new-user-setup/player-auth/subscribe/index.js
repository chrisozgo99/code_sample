//NOT MY WORK
import React from 'react';
import {View, ScrollView, StatusBar} from 'react-native';
import {Subscribe} from '_organisms';

import Back from '_assets/images/orange-back.svg';
import Upgrade from '_assets/images/auth/subscribe/upgrade-orange.svg';

import styles from './styles';

function SubscribeScreen({navigation}) {
    const user = navigation.state.params.user;
    console.log(user);
    return (
        <ScrollView style={{flex: 1, backgroundColor: 'black'}}>
            <StatusBar barStyle="light-content" />
            <View>
                <Subscribe
                    bg={require('_assets/images/auth/subscribe/subscribe-now.png')}
                    // image={require('_assets/images/auth/subscribe/black-colour.png')}
                    backSVG={<Back />}
                    backOnPress={() => navigation.navigate('App', {user: user})}
                    title={'Subscribe\nNow'}
                    header1={'Access premier workouts'}
                    subheader1={
                        "Unlock Paul Easton's tailored video drills to\nhelp you improve your game in 7 key skill\nareas."
                    }
                    header2={'Custom feedback'}
                    subheader2={
                        'Get specific advice from our trainers on\nareas for improvement based on your video\nfootage.'
                    }
                    header3={'Billing monthly, cancel anytime'}
                    subheader3={'\nTerms & Conditions\nPrivacy Policy'}
                    upgrade={<Upgrade />}
                    onPressUpgrade={() => {
                        navigation.navigate('App', {user: user});
                        navigation.navigate('Membership');
                    }}
                    onPressSkip={() => navigation.navigate('App', {user: user})}
                    styles={styles}
                />
            </View>
        </ScrollView>
    );
}

export default SubscribeScreen;
