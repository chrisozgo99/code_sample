//NOT MY WORK
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
    bgView: {
        height: '100%',
        width: '100%',
        position: 'absolute',
        opacity: 1,
        resizeMode: 'cover',
    },
    bgImage: {
        height: '85%',
        width: '100%',
        marginTop: '-4%',
    },
    imageView: {
        height: '100%',
        width: '100%',
        position: 'absolute',
        opacity: 1,
        resizeMode: 'cover',
    },
    image: {
        height: '45%',
        width: '100%',
        marginTop: '145.4%',
    },
    backView: {
        paddingTop: '12%',
        paddingLeft: '86%',
    },
    backButton: {},
    titleAndSubtitleView: {},
    titleView: {},
    title: {
        width: '100%',
        paddingTop: '4.8%',
        textAlign: 'center',
        fontSize: 50,
        fontFamily: 'AmericanAuto-Bold',
        color: 'white',
        opacity: 1,
    },
    contentView: {},
    paragraph1View: {},
    header1View: {
        marginTop: '8%',
        marginBottom: '5%',
    },
    header1: {
        textAlign: 'center',
        fontFamily: 'AmericanAuto-Bold',
        fontSize: 20,
        color: '#E14821',
        lineHeight: 30,
    },
    subheader1View: {},
    subheader1: {
        textAlign: 'center',
        fontFamily: 'AmericanAuto-Regular',
        fontSize: 16,
        color: 'white',
    },
    paragraph2View: {},
    header2View: {
        marginTop: '8%',
        marginBottom: '5%',
    },
    header2: {
        textAlign: 'center',
        fontFamily: 'AmericanAuto-Bold',
        fontSize: 20,
        color: '#E14821',
        lineHeight: 30,
    },
    subheader2View: {},
    subheader2: {
        textAlign: 'center',
        fontFamily: 'AmericanAuto-Regular',
        fontSize: 16,
        color: 'white',
    },
    paragraph3View: {backgroundColor: 'black'},
    header3View: {
        marginTop: '8%',
    },
    header3: {
        textAlign: 'center',
        fontFamily: 'AmericanAuto-Bold',
        fontSize: 20,
        color: '#E14821',
        lineHeight: 30,
        marginBottom: '3%',
    },
    subheader3View: {
        marginBottom: '5%',
    },
    subheader3: {
        textAlign: 'center',
        fontFamily: 'AmericanAuto-Regular',
        fontSize: 12,
        color: '#E14821',
    },
    upgradeAndSkipView: {
        marginTop: '7%',
        marginBottom: '5%',
    },
    upgradeView: {},
    upgradeButton: {
        justifyContent: 'center',
        alignItems: 'center',
        marginVertical: '5%',
    },
    skipButtonView: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    skipStyles: {},
    skipView: {},
    skipText: {
        fontFamily: 'AmericanAuto-Bold',
        fontSize: 16,
        color: '#E14821',
        textAlign: 'center',
    },
});

export default styles;
