import React from 'react';
import {View} from 'react-native';
import {Tutorial} from '_organisms';

import Back from '_assets/images/orange-back';

import styles from './styles';

function DevelopYourSkillsScreen({navigation}) {
    const user = navigation.state.params.user;
    return (
        <View style={{flex: 1}}>
            <Tutorial
                bg={null}
                styles={styles}
                backOnPress={() => navigation.navigate('PlayerProfilePhoto')}
                backSVG={<Back />}
                title={'Develop\nYour Skills'}
                subtitle={
                    "Watch Paul Easton's curated video drills to\nimprove your game, one rep at a time.\nNew videos are always being added."
                }
                image={require('_assets/images/auth/tutorials/develop-your-skills.png')}
                onPressNextAndSkip={() =>
                    navigation.navigate('RecordYourself', {
                        user: user,
                    })
                }
            />
        </View>
    );
}

export default DevelopYourSkillsScreen;
