//NOT MY WORK
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
    mainView: {
        height: '100%',
        width: '100%',
    },
    title: {
        width: '100%',
        paddingTop: '20%',
        paddingBottom: 32,
        marginHorizontal: '10%',
        textAlign: 'left',
        fontSize: 55,
        fontFamily: 'AmericanAuto-Bold',
        opacity: 1,
    },
    heightWeightView: {
        flexDirection: 'row',
        borderBottomWidth: 2,
        borderColor: 'black',
    },
    heightInputView: {
        width: '50%',
    },
    weightInputView: {
        width: '50%',
    },
    dropDownStyles: {
        backgroundColor: '#F2F2F2',
        fontFamily: 'AmericanAuto-Regular',
        fontSize: 20,
    },
    dropDownContainer: {
        height: 40,
        marginHorizontal: '10%',
    },
    placeholderStyle: {
        color: '#C9C9C9',
    },
    textInput: {
        fontSize: 20,
        borderWidth: 2,
        fontFamily: 'AmericanAuto-Regular',
        paddingBottom: '5%',
        borderBottomColor: 'black',
        borderTopColor: 'transparent',
        borderLeftColor: 'transparent',
        borderRightColor: 'transparent',
    },
    nextButtonView: {},
    nextButton: {
        marginBottom: '5%',
        justifyContent: 'center',
        alignItems: 'center',
    },
    nextAndSkipView: {
        width: '100%',
        // position: 'absolute',
        // bottom: 0,
        marginTop: '0%',
        zIndex: 1,
    },
    skipView: {
        marginBottom: '5%',
    },
    skipTextStyles: {
        fontFamily: 'AmericanAuto-Bold',
        fontSize: 16,
        color: '#E14821',
        textAlign: 'center',
        paddingBottom: 32,
    },
    formView: {
        marginHorizontal: '10%',
        paddingBottom: 32,
    },
    inputTextDefault: {
        fontSize: 20,
        fontFamily: 'AmericanAuto-Regular',
        color: '#C7C7CD',
        marginVertical: 16,
    },
    inputTextSelected: {
        fontSize: 20,
        fontFamily: 'AmericanAuto-Regular',
        color: '#E14821',
        marginVertical: 16,
    },
    inputView: {
        borderBottomWidth: 2,
        borderColor: 'black',
    },
});

export default styles;
