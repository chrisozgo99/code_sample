//MOSTLY NOT MY WORK
/* eslint-disable react-native/no-inline-styles */
import React, {useState} from 'react';
import {ScrollView, StatusBar} from 'react-native';
import Next from '_assets/images/auth/orange-next.svg';
import {CompletePlayerProfile} from '_molecules';
import {setDatabaseInfo} from '_services';
import styles from './styles';

function CompletePlayerProfileScreen({navigation}) {
    const user = navigation.state.params.user;
    console.log(user);
    const [height, setHeight] = useState();
    const [weight, setWeight] = useState();
    const [domHand, setDomHand] = useState();
    const [position, setPosition] = useState();
    const [skillLevel, setSkillLevel] = useState();
    const [dateOfBirth, setDateOfBirth] = useState();
    const [gender, setGender] = useState();
    const [datePickerVisable, setDatePickerVisable] = useState(false);
    const [pickerVisable, setPickerVisable] = useState(false);
    const [pickerItems, setPickerItems] = useState();
    const [pickerSelected, setPickerSelected] = useState();

    const heightInput = {
        onChangeText: text => setHeight(text),
        value: height,
        placeholder: 'Height',
    };

    const weightInput = {
        onChangeText: text => setWeight(text),
        value: weight,
        placeholder: 'Weight',
    };

    const domHandInput = {
        onChangeText: text => setDomHand(text),
        value: domHand,
        placeholder: 'Dominant Hand',
    };

    const positionInput = {
        onChangeText: text => setPosition(text),
        value: position,
        placeholder: 'Position',
    };

    const skillLevelInput = {
        onChangeText: text => setSkillLevel(text),
        value: skillLevel,
        placeholder: 'Skill Level',
    };

    const dateOfBirthInput = {
        onPress: text => setDateOfBirth(text),
        value: dateOfBirth,
        placeholder: 'Birthday',
    };

    const genderInput = {
        onChangeText: text => setGender(text),
        value: gender,
        placeholder: 'Gender',
    };

    const handleNext = () => {
        user.completeProfile(
            height,
            weight,
            domHand,
            position,
            skillLevel,
            dateOfBirth,
            gender,
        );
        setDatabaseInfo(
            user._userType,
            user,
            {navigation},
            'PlayerProfilePhoto',
        );
    };

    const handleSkip = () => {
        setDatabaseInfo(
            user._userType,
            user,
            {navigation},
            'PlayerProfilePhoto',
        );
    };

    return (
        <ScrollView
            contentContainerStyle={{
                flexGrow: 1,
            }}
            style={{flex: 1}}>
            <StatusBar barStyle="dark-content" />
            <CompletePlayerProfile
                styles={styles}
                onPressSkip={() => handleSkip()}
                title={'Complete\nYour Profile'}
                heightAttributes={heightInput}
                weightAttributes={weightInput}
                domHandAttributes={domHandInput}
                positionAttributes={positionInput}
                skillLevelAttributes={skillLevelInput}
                dateOfBirthAttributes={dateOfBirthInput}
                genderAttributes={genderInput}
                next={<Next />}
                onPressNext={() => handleNext()}
                datePickerVisable={datePickerVisable}
                setDatePickerVisable={event => setDatePickerVisable(event)}
                pickerVisable={pickerVisable}
                setPickerVisable={event => setPickerVisable(event)}
                pickerItems={pickerItems}
                setPickerItems={event => setPickerItems(event)}
                pickerSelected={pickerSelected}
                setPickerSelected={event => setPickerSelected(event)}
            />
        </ScrollView>
    );
}

export default CompletePlayerProfileScreen;
