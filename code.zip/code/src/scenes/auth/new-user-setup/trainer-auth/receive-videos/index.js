//NOT MY WORK
import React from 'react';
import {View} from 'react-native';
import {Tutorial} from '_organisms';

import Back from '_assets/images/orange-back';

import styles from './styles';

function ReceiveVideosScreen({navigation}) {
    const user = navigation.state.params.user;
    return (
        <View style={{flex: 1}}>
            <Tutorial
                bg={null}
                backOnPress={() => navigation.navigate('RecordYourself')}
                backSVG={<Back />}
                title={'Receive\nVideos'}
                subtitle={
                    "You will receive videos from different players\nlooking for feedback on their performances\nof Paul Easton's drills."
                }
                image={require('_assets/images/auth/tutorials/receive-videos.png')}
                onPressNextAndSkip={() =>
                    navigation.navigate('ProvideFeedback', {
                        user: user,
                    })
                }
                styles={styles}
            />
        </View>
    );
}

export default ReceiveVideosScreen;
