//NOT MY WORK
import React from 'react';
import {View} from 'react-native';
import {Tutorial} from '_organisms';

import Back from '_assets/images/orange-back';

import styles from './styles';

function ProvideFeedbackScreen({navigation}) {
    const user = navigation.state.params.user;
    return (
        <View style={{flex: 1}}>
            <Tutorial
                bg={null}
                backOnPress={() => navigation.navigate('RecordYourself')}
                backSVG={<Back />}
                title={'Provide\nFeedback'}
                subtitle={
                    "Use text or video to comment on the\nplayer's performance. Give the player\nguidance on how they can improve."
                }
                image={require('_assets/images/auth/tutorials/receive-videos.png')}
                onPressNextAndSkip={() =>
                    navigation.navigate('App', {
                        user: user,
                    })
                }
                styles={styles}
            />
        </View>
    );
}

export default ProvideFeedbackScreen;
