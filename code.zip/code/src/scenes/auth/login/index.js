//ABOUT 50% MY WORK
import React, {useState} from 'react';
import {View, ScrollView, StatusBar} from 'react-native';
import {Login} from '_organisms';

import {signInUser, userIsSignedIn, generateUserForLogin} from '_services';

import Back from '_assets/images/orange-back.svg';
import SignIn from '_assets/images/auth/login/sign-in-orange.svg';
import styles from './styles';

function LoginScreen({navigation}) {
    const [email, setEmail] = useState();
    const [password, setPassword] = useState();
    const [isLoggedIn, setisLoggedIn] = useState(userIsSignedIn());
    const [signingIn, setSigningIn] = useState(false);

    if (isLoggedIn) {
        generateUserForLogin({navigation}, 'App');
    }

    const loginHandler = () => {
        setSigningIn(true);
        let signInError = signInUser(email, password);
        signInError.then(err => {
            if (typeof err === 'string') {
                setEmail('');
                setPassword('');
                setSigningIn(false);
            } else {
                setisLoggedIn(userIsSignedIn());
                if (isLoggedIn) {
                    generateUserForLogin({navigation}, 'App');
                }
                setSigningIn(false);
            }
        });
    };

    return (
        <ScrollView
            contentContainerStyle={{
                flexGrow: 1,
            }}
            style={{flex: 1, backgroundColor: 'white'}}>
            <StatusBar barStyle="dark-content" />
            <Login
                bg={require('_assets/images/auth/login/basketball-grey.png')}
                backSVG={<Back />}
                backOnPress={() => navigation.navigate('Landing')}
                title="Sign In"
                emailOnChangeText={text => setEmail(text)}
                emailValue={email}
                emailPlaceholder="Email"
                passwordOnChangeText={text => setPassword(text)}
                passwordValue={password}
                passwordPlaceholder="Password"
                forgotPasswordOnPress={() =>
                    navigation.navigate('ForgotPassword')
                }
                loginSVG={<SignIn />}
                loginOnPress={() => loginHandler()}
                styles={styles}
                signingIn={signingIn}
            />
        </ScrollView>
    );
}

export default LoginScreen;
