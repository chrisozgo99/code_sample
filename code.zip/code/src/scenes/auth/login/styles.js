//ABOUT 50% MY WORK
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
    topView: {
        height: '100%',
        width: '100%',
        flex: 1,
        backgroundColor: 'white',
    },
    bgView: {
        height: '115%',
        width: '115%',
        position: 'absolute',
        top: 0,
        opacity: 1,
        resizeMode: 'cover',
    },
    bgImage: {
        height: '100%',
        width: '100%',
    },
    backView: {
        paddingTop: '2%',
        paddingLeft: '86%',
        // position: 'absolute',
        zIndex: 1,
    },
    titleView: {},
    title: {
        width: '100%',
        paddingTop: '5%',
        paddingLeft: '9.6%',
        textAlign: 'left',
        fontSize: 55,
        fontFamily: 'AmericanAuto-Bold',
        opacity: 1,
    },
    textInputView: {
        marginHorizontal: '10%',
        marginVertical: '3%',
    },
    textInput: {
        fontSize: 20,
        borderWidth: 2,
        fontFamily: 'AmericanAuto-Regular',
        paddingBottom: '5%',
        borderBottomColor: 'black',
        borderTopColor: 'transparent',
        borderLeftColor: 'transparent',
        borderRightColor: 'transparent',
    },
    forgotPasswordView: {},
    forgotPassword: {
        width: '100%',
        paddingTop: '10%',
        paddingLeft: '9.6%',
        textAlign: 'left',
        fontSize: 20,
        fontFamily: 'AmericanAuto-Bold',
        color: '#E14821',
        opacity: 1,
        marginBottom: '75%',
    },
    loginView: {
        width: '100%',
        alignItems: 'center',
        // marginTop: '55%',
    },
});

export default styles;
