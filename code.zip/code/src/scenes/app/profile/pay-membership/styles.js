//NOT MY WORK
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
    field: {
        width: '100%',
        fontFamily: 'AmericanAuto-Regular',
        fontSize: 16,
        justifyContent: 'center',
    },
    fieldView: {
        borderBottomWidth: 1.5,
        // borderTopWidth: 1.5,
        borderColor: '#E4E4E4',
        flexDirection: 'row',
        height: 40,
        alignItems: 'center',
        marginHorizontal: '10%',
    },
    topView: {
        height: '100%',
        width: '100%',
        backgroundColor: '#E14821',
    },
    headerView: {
        // height: '100%',
    },
    backButtonView: {
        position: 'absolute',
        paddingLeft: '86%',
        paddingTop: '12%',
        zIndex: 999,
    },
    title: {
        marginHorizontal: '10%',
        color: '#FFFFFF',
        textAlign: 'left',
        fontFamily: 'AmericanAuto-Bold',
        fontSize: 50,
        paddingBottom: '9%',
        paddingTop: '20%',
    },
    formView: {
        backgroundColor: 'white',
        height: '100%',
        width: '100%',
        borderRadius: 40,
    },
    formTitle: {
        fontFamily: 'AmericanAuto-Bold',
        fontSize: 20,
        textAlign: 'center',
        paddingTop: '4%',
        paddingBottom: '4%',
        marginHorizontal: '10%', // This will make the text wrap
    },
    form: {
        height: '100%',
    },
    textInput: {
        textAlign: 'right',
        color: '#E14821',
        fontFamily: 'AmericanAuto-Regular',
        fontSize: 16,
        position: 'absolute',
        right: 0,
    },
    textInputView: {
        borderBottomWidth: 1.5,
        borderColor: '#E4E4E4',
        flexDirection: 'row',
        height: 40,
        alignItems: 'center',
        marginHorizontal: '10%',
    },
    formInputTitle: {
        fontFamily: 'AmericanAuto-Regular',
        fontSize: 16,
    },
    // formInLineItem: {
    //     flexDirection: 'row',
    // },
    // textInputInline: {
    //     textAlign: 'right',
    //     color: '#E14821',
    //     fontFamily: 'AmericanAuto-Regular',
    //     fontSize: 16,
    //     flexDirection: 'row',
    //     // flex: 1,
    //     // position: 'absolute',
    //     width: '50%',
    //     // right: 0,
    // },
    // textInputInlineView: {
    //     flexDirection: 'row',
    //     alignItems: 'center',
    //     borderWidth: 1.5,
    //     borderColor: '#E4E4E4',
    //     borderLeftWidth: 0,
    //     borderRightWidth: 0,
    //     height: 40,
    //     marginHorizontal: '10%',
    //     // justifyContent: 'space-between',
    // },
    submitView: {
        alignItems: 'center',
        // position: 'absolute',
        // bottom: 0,
        paddingTop: 42,
        paddingBottom: 16,
    },
});

export default styles;
