//NOT MY WORK
import React, {useState} from 'react';
import {Alert, ScrollView, Button} from 'react-native';
import {getUserOnAppSide} from '_utils/user-functionality';
import {BillingInfo} from '_utils';
import {purchaseProduct, signUpForSubscription} from '_services';
import {PurchaseSubscription} from '_organisms';
import Back from '_assets/images/white-back.svg';
import Submit from '_assets/images/app/profile/membership/submit-button.svg';
import styles from './styles';
import functions from '@react-native-firebase/functions';

function PayMembershipScreen({navigation}) {
    const user = getUserOnAppSide(navigation);
    console.log(user);
    // var token = null;
    const selectedProduct = navigation.state.params.subSelected;
    console.log(selectedProduct);

    const [phone, setPhone] = useState(null);
    const [address, setAddress] = useState(null);
    const [city, setCity] = useState(null);
    const [state, setState] = useState(null);
    const [zipCode, setZipCode] = useState(null);
    const [cardParams, setCardParams] = useState(null);
    const [cardValid, setCardValid] = useState(false);
    const [loading, setLoading] = useState(false);

    const handleCardFieldParamsChange = (valid, params) => {
        setCardParams(params);
        setCardValid(valid);
        console.log(`
            Valid: ${valid}
            Number: ${params.number || '-'}
            Month: ${params.expMonth || '-'}
            Year: ${params.expYear || '-'}
            CVC: ${params.cvc || '-'}
        `);
    };

    let handlePayment = async billingInfo => {
        let formatedCardParams = {
            number: cardParams.number,
            exp_month: cardParams.expMonth,
            exp_year: cardParams.expYear,
            cvc: cardParams.cvc,
            name: billingInfo._name,
            address_line1: billingInfo._address,
            address_city: billingInfo._city,
            address_state: billingInfo._state,
            address_zip: billingInfo._zip,
        };
        if (selectedProduct._priceType === 'one_time') {
            await purchaseProduct(
                user._stripeInfo.customerID,
                formatedCardParams,
                selectedProduct._priceId,
                navigation,
                selectedProduct._id,
                user,
            );
            setLoading(false);
        } else if (selectedProduct._priceType === 'recurring') {
            await signUpForSubscription(
                user._stripeInfo.customerID,
                formatedCardParams,
                selectedProduct,
                navigation,
                user,
            );
            setLoading(false);
        }
    };

    return (
        <ScrollView
            // eslint-disable-next-line react-native/no-inline-styles
            contentContainerStyle={{
                flexGrow: 1,
            }}>
            <Button
                title={'Get Customer Info'}
                onPress={() => {
                    functions()
                        .httpsCallable('retrieveCustomer')({
                            customer: user._stripeInfo.customerID,
                        })
                        .then(customer => {
                            console.log(customer);
                        });
                }}
            />
            <PurchaseSubscription
                back={<Back />}
                title={'Enter Your Info'}
                onPressBack={() => navigation.navigate('Membership')}
                styles={styles}
                subscription={navigation.state.params.subSelected}
                phoneValue={phone}
                phoneOnChangeText={value => setPhone(value)}
                addressValue={address}
                addressOnChangeText={value => setAddress(value)}
                cityValue={city}
                cityOnChangeText={value => setCity(value)}
                stateValue={state}
                stateOnChangeText={value => setState(value)}
                zipCodeValue={zipCode}
                zipCodeOnChangeText={value => setZipCode(value)}
                handleCardFieldParamsChange={handleCardFieldParamsChange}
                loading={loading}
                submitOnPress={() => {
                    setLoading(true);
                    let billingInfo = new BillingInfo(
                        user._name.firstName + ' ' + user._name.lastName,
                        user._email,
                        phone,
                        address,
                        city,
                        state,
                        zipCode,
                    );
                    let errors = billingInfo.validateBilling();
                    let validInputs = true;
                    for (const err in errors) {
                        if (errors[err]) {
                            validInputs = false;
                            Alert.alert(
                                `Check the ${err} field for errors and try again.`,
                            );
                            setLoading(false);
                            break;
                        }
                    }
                    if (!cardValid && validInputs) {
                        Alert.alert('Card input not valid. Please try again.');
                        setLoading(false);
                    }
                    if (validInputs && cardValid) {
                        handlePayment(billingInfo);
                    }
                }}
                submitSVG={<Submit />}
            />
        </ScrollView>
    );
}

export default PayMembershipScreen;
