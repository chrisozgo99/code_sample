//NOT MY WORK
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
    topView: {
        height: '100%',
        width: '100%',
    },
    profilePicture: {
        width: 110,
        height: 110,
        borderRadius: 100,
    },
    profilePictureView: {
        alignItems: 'center',
        paddingTop: 46,
    },
    titleText: {
        fontFamily: 'AmericanAuto-Bold',
        fontSize: 50,
        textAlign: 'center',
        paddingTop: 16,
    },
    subtitleText: {
        textAlign: 'left',
        fontFamily: 'AmericanAuto-Bold',
        fontSize: 20,
    },
    averageGradeText: {
        fontFamily: 'AmericanAuto-Bold',
        fontSize: 36,
        color: '#E14821',
        position: 'absolute',
        right: 0,
        top: 5,
    },
    bodyContent: {
        marginHorizontal: '9%',
    },
    contentView: {
        paddingTop: 30,
    },
    averageGradeView: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingTop: 16,
    },
    userAttributes: {
        fontFamily: 'AmericanAuto-Regular',
        fontSize: 16,
        paddingTop: 8,
    },
    userAttributesView: {
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    userAttributesListView: {},
});

export default styles;
