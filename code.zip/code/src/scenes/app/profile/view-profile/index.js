//MOSTLY NOT MY WORK
import React from 'react';
import {View, ScrollView} from 'react-native';
import {getUserOnAppSide} from '_utils';
import {UserProfile} from '_organisms';
import styles from './styles';

function ViewProfileScreen({navigation}) {
    const user = getUserOnAppSide(navigation);
    return (
        <ScrollView style={{flex: 1}}>
            <View style={{flex: 1}}>
                <UserProfile
                    user={user}
                    styles={styles}
                    navigation={navigation}
                />
            </View>
        </ScrollView>
    );
}

export default ViewProfileScreen;
