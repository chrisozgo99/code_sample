//NOT MY WORK
import React, {useState} from 'react';
import {View} from 'react-native';
import {generateMembershipList, getSubscriptionInfo} from '_services';
import {DisplaySubscription, DisplayCurrentSubscriptionInfo} from '_organisms';
import {getUserOnAppSide} from '_utils/user-functionality';
import Back from '_assets/images/orange-back.svg';
import SubscriptionButton from '_assets/images/app/profile/membership/start-subscription.svg';
import styles from './styles';

function MembershipScreen({navigation}) {
    const user = getUserOnAppSide(navigation);
    // TODO: Add in functionality for changing subscription.

    const [selectedSub, setSelectedSub] = useState();
    const [subInfo, setSubInfo] = useState();
    const [membershipList, setMembershipList] = useState(undefined);
    const [loading, setLoading] = useState(true);

    if (loading) {
        if (user._stripeInfo.productID !== null) {
            getSubscriptionInfo(
                user._stripeInfo.subscriptionID,
                user._stripeInfo.productID,
            ).then(data => {
                console.log(data);
                setSelectedSub(data.formattedSub);
                setSubInfo(data.fullSubInfo);
                setLoading(false);
            });
        } else {
            generateMembershipList().then(response => {
                let list = [];
                for (var i = 0; i < response.length; i++) {
                    if (response[i]._userType === user._userType) {
                        list.push(response[i]);
                    }
                }
                setMembershipList(list);
                setLoading(false);
            });
        }
    }

    return (
        <View style={{flex: 1}}>
            {user._stripeInfo.subscriptionID === null ? (
                <DisplaySubscription
                    title={'Start Your\nSubscription'}
                    back={<Back />}
                    onPressBack={() => navigation.navigate('ViewProfile')}
                    styles={styles}
                    subscriptionButton={<SubscriptionButton />}
                    loading={loading}
                    navigation={navigation}
                    subscriptionList={membershipList}
                    selectedSub={selectedSub}
                    setSelectedSub={event => setSelectedSub(event)}
                />
            ) : (
                <DisplayCurrentSubscriptionInfo
                    back={<Back />}
                    onPressBack={() => navigation.navigate('ViewProfile')}
                    styles={styles}
                    navigation={navigation}
                    user={user}
                    loading={loading}
                    fullSubInfo={subInfo}
                    sub={selectedSub}
                />
            )}
        </View>
    );
}

export default MembershipScreen;
