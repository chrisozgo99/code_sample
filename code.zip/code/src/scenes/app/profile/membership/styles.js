//NOT MY WORK
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
    topView: {
        height: '100%',
        width: '100%',
    },
    backButtonView: {
        position: 'absolute',
        paddingLeft: '86%',
        paddingTop: '12%',
        zIndex: 999,
    },
    payButtonView: {
        justifyContent: 'flex-end',
        alignItems: 'center',
        position: 'absolute',
        bottom: 0,
        marginBottom: '10%',
        width: '100%',
    },
    subscriptionDescriptionText: {
        fontFamily: 'AmericanAuto-Regular',
        fontSize: 16,
        lineHeight: 26,
        textAlign: 'left',
        alignContent: 'center',
        alignItems: 'center',
    },
    subscriptionOptions: {
        borderRadius: 2,
        borderColor: '#e14821',
        width: 160,
        height: 160,
    },
    subscriptionOptionsView: {
        flexDirection: 'row',
        justifyContent: 'space-evenly',
        alignItems: 'center',
        paddingTop: '8%',
    },
    subscriptionDescriptionView: {
        flexDirection: 'row',
        width: 302,
        height: 101,
        paddingTop: '5%',
        marginHorizontal: '10%',
    },
    title: {
        fontFamily: 'AmericanAuto-Bold',
        fontSize: 50,
        textAlign: 'left',
        marginHorizontal: '10%',
        paddingTop: '20%',
    },
});

export default styles;
