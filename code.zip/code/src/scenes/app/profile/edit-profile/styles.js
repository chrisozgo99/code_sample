//ABOUT 50% MY WORK
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
    backButtonView: {
        alignItems: 'flex-end',
        justifyContent: 'flex-end',
        marginRight: '9%',
        marginTop: '2%',
    },
    backButton: {},
    titleAndSubtitleView: {},
    titleView: {},
    title: {
        fontSize: 36,
    },
    subtitleView: {},
    subtitle: {
        fontSize: 12,
    },
    profilePhotoView: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    profilePicView: {
        alignItems: 'center',
        paddingTop: 8,
    },
    profilePic: {
        width: 150,
        height: 150,
        borderRadius: 100,
        justifyContent: 'center',
        alignContent: 'center',
    },
    defaultImgMargin: {
        marginTop: '2%',
    },
    nextButtonView: {},
    nextButton: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    skipButtonView: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    skipButton: {},
    formView: {
        marginHorizontal: '10%',
        paddingTop: 36,
    },
    textInputView: {
        flexDirection: 'row',
        alignItems: 'center',
        borderColor: '#E4E4E4',
        borderBottomWidth: 1.5,
        padding: 8,
    },
    textInputTitleText: {
        fontFamily: 'AmericanAuto-Regular',
        fontSize: 16,
    },
    textInput: {
        position: 'absolute',
        right: 0,
        textAlign: 'right',
        fontFamily: 'AmericanAuto-Regular',
        fontSize: 16,
        color: '#E14821',
    },
    clickableText: {
        textAlign: 'right',
        fontFamily: 'AmericanAuto-Regular',
        fontSize: 16,
        color: '#E14821',
    },
});

export default styles;
