//MOSTLY MY WORK
import React, {useState} from 'react';
import {View, ScrollView, SafeAreaView, Platform} from 'react-native';
import {getUserOnAppSide, collectEditInfo} from '_utils/user-functionality';
import {EditUserProfile} from '_organisms';

import styles from './styles';
import {WhiteButton, TouchableOpacitySVG} from '_atoms';
import Back from '_assets/images/orange-back.svg';

function EditProfileScreen({navigation}) {
    const user = getUserOnAppSide(navigation);

    const platform = Platform.OS;

    const [datePickerVisable, setDatePickerVisable] = useState(false);
    const [pickerVisable, setPickerVisable] = useState(false);
    const [pickerItems, setPickerItems] = useState();
    const [pickerSelected, setPickerSelected] = useState();

    const isPlayer = user._userType === 'players';
    const isCoach = user._userType === 'coaches';
    const isTrainer = user._userType === 'trainers';

    const [firstName, setFirstName] = useState(user._name.firstName);
    const [lastName, setLastName] = useState(user._name.lastName);
    const [email, setEmail] = useState(user._email);
    const [profilePic, setProfilePic] = useState(user._profilePic);

    const [height, setHeight] = useState(
        isPlayer ? user._playerInfo.height : null,
    );
    const [weight, setWeight] = useState(
        isPlayer ? user._playerInfo.weight : null,
    );
    const [domHand, setDomHand] = useState(
        isPlayer ? user._playerInfo.domHand : null,
    );
    const [position, setPosition] = useState(
        isPlayer ? user._playerInfo.position : null,
    );
    const [skillLevel, setSkillLevel] = useState(
        isPlayer ? user._playerInfo.skillLevel : null,
    );
    const [dateOfBirth, setDateOfBirth] = useState(
        isPlayer ? user._playerInfo.dateOfBirth : null,
    );
    const [gender, setGender] = useState(
        isPlayer ? user._playerInfo.gender : null,
    );

    const [coachYearsExp, setCoachYearsExp] = useState(
        isCoach ? user._yearsExp : null,
    );
    const [coachGender, setCoachGender] = useState(
        isCoach ? user._gender : null,
    );

    const [trainerYearsExp, setTrainerYearsExp] = useState(
        isTrainer ? user._yearsExp : null,
    );
    const [trainerGender, setTrainerGender] = useState(
        isTrainer ? user._gender : null,
    );

    const userTitles = [
        {
            placeholder: 'First Name',
            value: firstName,
            onPress: event => setFirstName(event),
            attribute: '_name.firstName',
        },
        {
            placeholder: 'Last Name',
            value: lastName,
            onPress: event => setLastName(event),
            attribute: '_name.lastName',
        },
    ];

    const profilePicAttributes = {
        profilePic: profilePic,
        onPress: image => setProfilePic(image.path),
        source:
            profilePic === ''
                ? 'https://firebasestorage.googleapis.com/v0/b/drills-and-skills.appspot.com/o/images%2Fprofile-pics%2Fblank-profile-picture.png?alt=media&token=86e354ea-5008-41e4-b7ba-0f3486b13fb8'
                : profilePic,
        onPressRevertToDefaultImage: () =>
            setProfilePic(
                'https://firebasestorage.googleapis.com/v0/b/drills-and-skills.appspot.com/o/images%2Fprofile-pics%2Fblank-profile-picture.png?alt=media&token=86e354ea-5008-41e4-b7ba-0f3486b13fb8',
            ),
    };

    const playerTitles = [
        {
            placeholder: 'Height',
            value: height,
            onPress: event => setHeight(event),
            attribute: 'height',
        },
        {
            placeholder: 'Weight',
            value: weight,
            onPress: event => setWeight(event),
            attribute: 'weight',
        },
        {
            placeholder: 'Dominant Hand',
            value: domHand,
            onPress: event => setDomHand(event),
            attribute: 'domHand',
        },
        {
            placeholder: 'Position',
            value: position,
            onPress: event => setPosition(event),
            attribute: 'position',
        },
        {
            placeholder: 'Skill Level',
            value: skillLevel,
            onPress: event => setSkillLevel(event),
            attribute: 'skillLevel',
        },
        {
            placeholder: 'Birthday',
            value: dateOfBirth,
            onPress: event => setDateOfBirth(event),
            attribute: 'dateOfBirth',
        },
        {
            placeholder: 'Gender',
            value: gender,
            onPress: event => setGender(event),
            attribute: 'gender',
        },
    ];

    const coachTitles = [
        {
            placeholder: 'Years Experience',
            value: coachYearsExp,
            onPress: event => setCoachYearsExp(event),
            attribute: 'yearsExp',
        },
        {
            placeholder: 'Gender',
            value: coachGender,
            onPress: event => setCoachGender(event),
            attribute: 'gender',
        },
    ];

    const trainerTitles = [
        {
            placeholder: 'Years Experience',
            value: trainerYearsExp,
            onPress: event => setTrainerYearsExp(event),
            attribute: '_yearsExp',
        },
        {
            placeholder: 'Gender',
            value: trainerGender,
            onPress: event => setTrainerGender(event),
            attribute: 'gender',
        },
    ];

    return (
        <ScrollView style={{flex: 1}}>
            <SafeAreaView>
                <View style={styles.backButtonView}>
                    <TouchableOpacitySVG
                        svg={<Back />}
                        onPress={() => navigation.navigate('ViewProfile')}
                    />
                </View>
                <EditUserProfile
                    user={user}
                    userTitles={userTitles}
                    titles={
                        user._userType === 'players'
                            ? playerTitles
                            : user._userType === 'coaches'
                            ? coachTitles
                            : trainerTitles
                    }
                    attributes={profilePicAttributes}
                    styles={styles}
                    datePickerVisable={datePickerVisable}
                    setDatePickerVisable={event => setDatePickerVisable(event)}
                    pickerVisable={pickerVisable}
                    setPickerVisable={event => setPickerVisable(event)}
                    pickerItems={pickerItems}
                    setPickerItems={event => setPickerItems(event)}
                    pickerSelected={pickerSelected}
                    setPickerSelected={event => setPickerSelected(event)}
                />
                <View
                    // eslint-disable-next-line react-native/no-inline-styles
                    style={{
                        alignItems: 'center',
                        paddingTop: 70,
                        paddingBottom: 50,
                    }}>
                    <WhiteButton
                        name="Save"
                        onPress={() => {
                            collectEditInfo(
                                user,
                                profilePic === user._profilePic
                                    ? null
                                    : profilePic,
                                userTitles,
                                playerTitles,
                                coachTitles,
                                trainerTitles,
                                {navigation},
                                'ViewProfile',
                            );
                        }}
                    />
                </View>
            </SafeAreaView>
        </ScrollView>
    );
}

export default EditProfileScreen;
