import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
    topView: {
        backgroundColor: '#e14821',
        height: '100%',
    },
    headerView: {
        marginTop: '13%',
        marginBottom: '13%',
        width: '100%',
    },
    backButtonView: {
        alignItems: 'flex-end',
        justifyContent: 'flex-end',
        marginRight: '9%',
    },
    title: {
        fontFamily: 'AmericanAuto-Bold',
        fontSize: 50,
        color: 'white',
        textAlign: 'left',
        marginHorizontal: '10%',
    },
    skillProgressions: {
        backgroundColor: 'white',
        width: '100%',
        height: '100%',
        paddingTop: '15%',
        borderTopLeftRadius: 32,
        borderTopRightRadius: 32,
    },
});

export default styles;
