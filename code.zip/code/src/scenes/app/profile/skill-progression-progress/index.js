import React from 'react';
import {View, StatusBar} from 'react-native';
import {SkillProgressions} from '_organisms';

import Back from '_assets/images/white-back.svg';

import styles from './styles';

function SkillProgressionProgressScreen({navigation}) {
    const skillAreas = [
        {
            skill: 'Ball Handling',
            progression: '75%',
        },
        {
            skill: 'Dribble Moves',
            progression: '75%',
        },
        {
            skill: 'Shooting',
            progression: '75%',
        },
        {
            skill: 'Finishing',
            progression: '75%',
        },
        {
            skill: 'Defense & Rebounding',
            progression: '75%',
        },
        {
            skill: 'Basketball IQ',
            progression: '75%',
        },
        {
            skill: 'Elite Guard Play',
            progression: '75%',
        },
    ];

    return (
        <View>
            <StatusBar barStyle="light-content" />
            <SkillProgressions
                title={'Skill\nProgression'}
                back={<Back />}
                onPressBack={() => navigation.navigate('ViewProfile')}
                skillAreas={skillAreas}
                styles={styles}
            />
        </View>
    );
}

export default SkillProgressionProgressScreen;
