//NOT MY WORK
import React, {useState} from 'react';
import {View, Alert, SafeAreaView} from 'react-native';
import {updatePassword} from '_services';
import {ChangePassword} from '_organisms';
import styles from './styles';
import Back from '_assets/images/orange-back.svg';
import SaveButton from '_assets/images/app/profile/save-button-white.svg';

function ChangePasswordScreen({navigation}) {
    const [currentPassword, setCurrentPassword] = useState();
    const [newPassword, setNewPassword] = useState();
    const [verifyNewPassword, setVerifyNewPassword] = useState();

    return (
        <View style={{flex: 1}}>
            <SafeAreaView style={{flex: 1}}>
                <ChangePassword
                    styles={styles}
                    back={<Back />}
                    onPressBack={() => navigation.navigate('ViewProfile')}
                    title={'Change\nPassword'}
                    currentPassword={currentPassword}
                    currentPasswordOnChangeText={text =>
                        setCurrentPassword(text)
                    }
                    newPassword={newPassword}
                    newPasswordOnChangeText={text => setNewPassword(text)}
                    verifyNewPassword={verifyNewPassword}
                    verifyNewPasswordOnChangeText={text =>
                        setVerifyNewPassword(text)
                    }
                    saveButton={<SaveButton />}
                    onPressSave={() => {
                        if (
                            !(
                                currentPassword &&
                                newPassword &&
                                verifyNewPassword
                            )
                        ) {
                            Alert.alert('Please fill in all fields.');
                        } else if (newPassword !== verifyNewPassword) {
                            Alert.alert(
                                'Please make sure your new passwords match.',
                            );
                        } else {
                            // eslint-disable-next-line prettier/prettier
                            updatePassword(currentPassword, newPassword, {navigation});
                        }
                    }}
                />
            </SafeAreaView>
        </View>
    );
}

export default ChangePasswordScreen;
