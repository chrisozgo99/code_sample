//NOT MY WORK
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
    topView: {
        // height: '100%',
        // width: '100%',
    },
    title: {
        fontFamily: 'AmericanAuto-Bold',
        fontSize: 50,
        textAlign: 'left',
        marginHorizontal: '10%',
    },
    backButtonView: {
        alignItems: 'flex-end',
        justifyContent: 'flex-end',
        marginRight: '9%',
        marginTop: '2%',
    },
    formView: {
        marginHorizontal: '10%',
    },
    footerView: {
        alignItems: 'center',
        paddingTop: '40%',
    },
    textInputs: {
        fontFamily: 'AmericanAuto-Regular',
        fontSize: 20,
        borderColor: '#000000',
        borderBottomWidth: 2,
        padding: 15,
        color: '#E14821',
    },
    textInputView: {},
    saveButtonView: {},
});

export default styles;
