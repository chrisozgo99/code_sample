/* eslint-disable react-native/no-inline-styles */
import React, {useState, useEffect} from 'react';
import {View, StatusBar, Alert} from 'react-native';
import {JumpshotTutor} from '_organisms';
import {getUserOnAppSide} from '_utils';
import {setTrainerToConversation} from '_services';

import styles from './styles';

function ViewJumpshotTutorScreen({navigation}) {
    const user = getUserOnAppSide(navigation);
    const [trainer, setTrainer] = useState();
    const [trainerHasBeenSet, setTrainerHasBeenSet] = useState(false);
    const videoInfo = {
        module: 'Jumpshot Tutor',
        level: null,
        drill: null,
    };

    const clientInfo = {
        label: user._name.firstName + ' ' + user._name.lastName,
        value: user._userID,
        profilePic: user._profilePic,
        userType: user._userType,
        lastReadMessage: Date.now(),
    };

    const details = {
        client: clientInfo,
        trainer: trainer,
        lastUpdated: null,
    };

    useEffect(() => {
        if (!trainerHasBeenSet) {
            setTrainerToConversation(details, videoInfo).then(chosenTrainer => {
                setTrainer(chosenTrainer);
                setTrainerHasBeenSet(true);
            });
        }
    });

    return (
        <View style={{backgroundColor: 'white', flex: 1}}>
            <StatusBar barStyle="dark-content" />
            <JumpshotTutor
                title={'Jumpshot\nTutor'}
                source={require('_assets/images/app/jumpshot-tutor/bg.png')}
                name={'Request Video Review'}
                onPress={() => {
                    if (user._userType !== 'players') {
                        Alert.alert(
                            'Only players are allowed to request a video review.',
                        );
                    } else {
                        Alert.alert(
                            'Send a video of your jumpshot to recieve a detailed breakdown to help you become a more effective and efficient shooter.',
                        );
                        // console.log(details);
                        navigation.navigate('RecordVideo', {
                            videoInfo: videoInfo,
                            details: details,
                        });
                    }
                }}
                styles={styles}
            />
        </View>
    );
}

export default ViewJumpshotTutorScreen;
