import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
    topView: {
        flex: 1,
        backgroundColor: 'white',
    },
    headerView: {
        flex: 0.25,
        marginTop: '15%',
        marginLeft: '10%',
        zIndex: 1,
    },
    title: {
        fontFamily: 'AmericanAuto-Bold',
        fontSize: 50,
    },
    bodyView: {
        flex: 1,
    },
    bgImage: {
        marginLeft: '-30%',
        height: '100%',
        bottom: 0,
        resizeMode: 'cover',
    },
    whiteButtonView: {
        position: 'absolute',
        bottom: 0,
        width: '80%',
        margin: '10%',
    },
});

export default styles;
