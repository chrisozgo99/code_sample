//NOT MY WORK
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
    topView: {
        height: '100%',
        width: '100%',
        backgroundColor: 'white',
    },
    headerView: {},
    title: {
        fontSize: 50,
        textAlign: 'left',
        fontFamily: 'AmericanAuto-Bold',
        marginTop: '25%',
        marginLeft: '10%',
    },
    challengeOfTheWeekView: {
        marginTop: '8%',
        justifyContent: 'center',
    },
    challengeOfTheWeekTitleView: {
        marginBottom: '3%',
    },
    challengeOfTheWeek: {
        fontSize: 20,
        fontWeight: 'bold',
        textAlign: 'center',
    },
    challengeView: {},
    challenge: {
        fontSize: 16,
        textAlign: 'center',
    },
    timeRemainingView: {},
    timeRemaining: {
        fontSize: 16,
        marginBottom: '10%',
        textAlign: 'center',
    },
    zoomView: {},
    zoomTitleView: {},
    zoomTitle: {
        fontSize: 20,
        fontWeight: 'bold',
        textAlign: 'center',
    },
    zoomCountdownView: {
        marginBottom: '5%',
    },
    zoomButtonView: {
        width: '100%',
        justifyContent: 'center',
        alignItems: 'center',
    },
    touchableOpacityGrayStyles: {
        backgroundColor: '#FFFF',
        borderRadius: 50,
        width: 356,
        height: 64,
        borderWidth: 3,
        justifyContent: 'center',
        borderColor: 'gray',
    },
    touchableOpacityGrayTextStyles: {
        textAlign: 'center',
        marginTop: '1.5%',
        fontSize: 24,
        fontFamily: 'AmericanAuto-Bold',
        color: 'gray',
    },
    touchableOpacityBlackStyles: {
        backgroundColor: '#FFFF',
        borderRadius: 50,
        width: 356,
        height: 64,
        borderWidth: 3,
        justifyContent: 'center',
        borderColor: 'black',
    },
    touchableOpacityBlackTextStyles: {
        textAlign: 'center',
        fontSize: 24,
        marginTop: '1.5%',
        fontFamily: 'AmericanAuto-Bold',
    },
    digitTxtStyle: {
        marginTop: '47%',
        color: '#000',
        fontSize: 50,
        fontFamily: 'AmericanAuto-Bold',
    },
    digitStyle: {backgroundColor: 'transparent'},
    separatorStyle: {
        color: '#000',
    },
    timeLabelStyle: {
        color: '#000',
        fontSize: 16,
        fontFamily: 'AmericanAuto-Regular',
    },
});

export default styles;
