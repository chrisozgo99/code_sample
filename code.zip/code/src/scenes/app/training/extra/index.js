//NOT MY WORK
import React, {useState, useEffect} from 'react';
import {View} from 'react-native';
import {Extra} from '_organisms';

import styles from './styles';
import {
    getWeeklyChallengeFromDatabase,
    getLivestreamFromDatabase,
} from '_services';

function ExtraScreen({navigation}) {
    //const [challengeExpiration, setChallengeExpiration] = useState('');
    const [displayedExp, setDisplayedExp] = useState('');
    const [liveLink, setLiveLink] = useState('https://www.yahoo.com');
    const [liveDateTime, setLiveDateTime] = useState(0);
    const [liveName, setLiveName] = useState('');
    const [challenge, setChallenge] = useState('');
    const [gotChallenge, setGotChallenge] = useState(false);
    const [gotLivestream, setGotLivestream] = useState(false);
    useEffect(() => {
        if (!gotLivestream) {
            getLivestreamFromDatabase().then(list => {
                setGotLivestream(true);
                setLiveLink(list[0].link);
                setLiveName(list[0].name);
                let secs = parseInt(list[0].date.seconds);
                var tempObj = new Date();
                tempObj.setTime(secs * 1000);
                setLiveDateTime(
                    // eslint-disable-next-line prettier/prettier
                    (tempObj.getTime() - (new Date()).getTime()) / 1000,
                );
            });
        }
        if (!gotChallenge) {
            getWeeklyChallengeFromDatabase().then(list => {
                setGotChallenge(true);
                setChallenge(list[0].text);
                let secs = list[0].date.seconds;
                var tempObj = new Date();
                tempObj.setTime(parseInt(secs) * 1000);
                setDisplayedExp(
                    tempObj.getMonth() +
                        1 +
                        '/' +
                        tempObj.getDate() +
                        '/' +
                        tempObj.getFullYear(),
                );
            });
        }
    });

    return (
        <View style={{flex: 1}}>
            <View style={{flex: 1}}>
                <Extra
                    challengeOfTheWeek="Weekly Challenge"
                    title="Tips"
                    navigation={navigation}
                    styles={styles}
                    challenge={challenge}
                    timeRemaining={displayedExp}
                    zoomTitle="Paul Easton will be live in: "
                    liveDateTime={liveDateTime}
                    liveLink={liveLink}
                    touchableOpacityText="Live Zoom Workout"
                    countdownSize={33}
                />
            </View>
        </View>
    );
}

export default ExtraScreen;
