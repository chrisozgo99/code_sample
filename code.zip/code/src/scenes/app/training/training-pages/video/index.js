import React, {useState, useEffect} from 'react';
import {View} from 'react-native';
import {Video} from '_organisms';
import {isConversationInDatabase, setTrainerToConversation} from '_services';
import {getUserOnAppSide} from '_utils';

import Back from '_assets/images/orange-back.svg';
import RequestVideoReview from '_assets/images/app/training/request-video-review.svg';
import SendMessage from '_assets/images/app/training/send-message.svg';

import styles from './styles';

function VideoScreen({navigation}) {
    const user = getUserOnAppSide(navigation);
    const passedVideoInfo = navigation.state.params.video;
    const [trainer, setTrainer] = useState();
    const [trainerHasBeenSet, setTrainerHasBeenSet] = useState(false);
    const videoInfo = {
        module: passedVideoInfo.module,
        level: passedVideoInfo.videoDetails.level,
        drill: passedVideoInfo.videoDetails.drill,
    };

    const clientInfo = {
        label: user._name.firstName + ' ' + user._name.lastName,
        value: user._userID,
        profilePic: user._profilePic,
        userType: user._userType,
        lastReadMessage: Date.now(),
    };

    const details = {
        client: clientInfo,
        trainer: trainer,
        lastUpdated: null,
    };

    useEffect(() => {
        if (user._userType !== 'trainers') {
            if (!trainerHasBeenSet) {
                setTrainerToConversation(details, videoInfo).then(
                    chosenTrainer => {
                        setTrainer(chosenTrainer);
                        setTrainerHasBeenSet(true);
                    },
                );
            }
        }
    });

    return (
        <View style={{height: '100%', width: '100%'}}>
            <Video
                back={<Back />}
                onPressBack={() => navigation.navigate('Module')}
                title={videoInfo.drill}
                height="73%"
                width="83%"
                source={passedVideoInfo.videoDetails.source}
                description={passedVideoInfo.videoDetails.description}
                guidelines={passedVideoInfo.videoDetails.guidelines}
                requestVideoReview={<RequestVideoReview />}
                onPressRequestVideoReview={() =>
                    navigation.navigate('RecordVideo', {
                        videoInfo: videoInfo,
                        details: details,
                    })
                }
                sendMessage={<SendMessage />}
                onPressSendMessage={() =>
                    isConversationInDatabase(details, videoInfo, {navigation})
                }
                user={user}
                styles={styles}
            />
        </View>
    );
}

export default VideoScreen;
