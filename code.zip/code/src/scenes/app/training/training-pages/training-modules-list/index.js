//MY WORK BEFORE LINE 38
import React, {useState, useEffect} from 'react';
import {View} from 'react-native';
import {TrainingModulesList} from '_organisms';
import messaging from '@react-native-firebase/messaging';

import {getListOfModulesFromDatabase, saveTokenToDatabase} from '_services';
import {getUserOnAppSide} from '_utils';

import styles from './styles';

function TrainingModulesScreen({navigation}) {
    const user = getUserOnAppSide(navigation);
    const [modules, setModules] = useState([]);
    const [gotModules, setGotModules] = useState(false);

    useEffect(() => {
        if (!gotModules) {
            getListOfModulesFromDatabase(user).then(dbModules => {
                console.log('updating');
                setModules(dbModules);
            });
        }
        messaging()
            .getToken()
            .then(token => {
                user._tokens.push(token);
                return saveTokenToDatabase(token, user);
            });
        return messaging().onTokenRefresh(token => {
            setGotModules(true);
            saveTokenToDatabase(token, user);
        });
    }, [gotModules, user]);

    return (
        <View style={{flex: 1}}>
            <TrainingModulesList
                modules={modules}
                navigation={navigation}
                styles={styles}
                pageTitle="Training"
            />
        </View>
    );
}

export default TrainingModulesScreen;
