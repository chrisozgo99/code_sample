import React from 'react';
import {View} from 'react-native';
import {About} from '_organisms';
import Website from '_assets/images/app/training/about/website.svg';
import Facebook from '_assets/images/app/training/about/facebook.svg';
import Instagram from '_assets/images/app/training/about/instagram.svg';
import Twitter from '_assets/images/app/training/about/twitter.svg';
import Youtube from '_assets/images/app/training/about/youtube.svg';

import styles from './styles';

function AboutScreen({navigation}) {
    const icons = [
        {
            svg: <Website />,
            link: 'http://iwantskills.com/',
        },
        {
            svg: <Facebook />,
            link: 'https://www.facebook.com/drillsandskillsbball/',
        },
        {
            svg: <Instagram />,
            link: 'https://www.instagram.com/drillsandskillsbball/',
        },
        {
            svg: <Twitter />,
            link: 'https://twitter.com/dskillsbball',
        },
        {
            svg: <Youtube />,
            link: 'https://www.youtube.com/channel/UCBwLoiWFO3K-kffEW-bNulw',
        },
    ];

    return (
        <View>
            <About
                icons={icons}
                title="About"
                message={
                    'Paul Easton Basketball is one of the most elite skills training experiences in the world!\n\nIn person and online, we provide intense skill training and detailed teaching of the game to help you become the best player, coach, or trainer you can be.'
                }
                navigation={navigation}
                styles={styles}
            />
        </View>
    );
}

export default AboutScreen;
