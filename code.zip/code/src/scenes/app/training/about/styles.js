import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
    topView: {
        height: '100%',
        width: '100%',
        backgroundColor: 'white',
    },
    titleView: {},
    title: {
        fontSize: 50,
        textAlign: 'left',
        fontFamily: 'AmericanAuto-Bold',
        marginTop: '25%',
        marginLeft: '10%',
    },
    contentView: {},
    messageView: {width: '82%', marginHorizontal: '9%', marginTop: '10%'},
    message: {fontFamily: 'AmericanAuto-Regular', fontSize: 16, lineHeight: 20},
    socialMediaIconsView: {
        flexDirection: 'row',
        width: '60%',
        marginHorizontal: '20%',
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    iconView: {alignItems: 'center', justifyContent: 'center'},
    socialMediaIcons: {
        alignItems: 'center',
        justifyContent: 'center',
        padding: '3%',
        flex: 1 / 5,
    },
});

export default styles;
