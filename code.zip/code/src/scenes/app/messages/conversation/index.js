//99% MY WORK
/* eslint-disable react-native/no-inline-styles */
import React, {useState, useEffect} from 'react';
import {View} from 'react-native';
import {Conversation} from '_organisms';
import {Message, getUserOnAppSide} from '_utils';
import {
    sendPushNotification,
    updateLastReadMessageInConversation,
} from '_services';
import firestore from '@react-native-firebase/firestore';
import {Conversation as Convo} from '_utils';
import styles from './styles';

function ConversationScreen({navigation}) {
    const [convo, setConvo] = useState(navigation.state.params.conversation);
    const [message, setMessage] = useState(null);
    const user = getUserOnAppSide(navigation);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    async function updateLastReadMessageEdgeCase() {
        if (convo._messages.length > 0) {
            //If the logged in user did not send the last message
            if (user._userID !== convo._messages[0]._sentBy) {
                if (user._userType === 'trainers') {
                    //If the logged in user is a trainer
                    if (
                        convo._details.trainer.lastReadMessage <
                        convo._details.lastUpdated
                    ) {
                        //If the logged in user's lastReadMessage field is
                        //still before the time it was last updated,
                        await updateLastReadMessageInConversation(user, convo);
                    }
                } else if (
                    user._userType === 'players' ||
                    user._userType === 'coaches'
                ) {
                    //If the logged in user is the client
                    if (
                        convo._details.client.lastReadMessage <
                        convo._details.lastUpdated
                    ) {
                        //If the logged in user's lastReadMessage field is
                        //still before the time it was last updated,
                        await updateLastReadMessageInConversation(user, convo);
                    }
                }
            }
        }
    }
    const props = {
        placeholder: 'Message',
        onChangeText: text => setMessage(text),
        value: message,
        sendMessage: async () => {
            if (message !== null) {
                if (message !== '') {
                    const mess = new Message(
                        {
                            type: 'text',
                            contents: message,
                        },
                        user._userID,
                        Date.now(),
                    );
                    const text = message;
                    setMessage('');
                    await convo.addMessage(mess);
                    await sendPushNotification(user, convo, text);
                }
            }
        },
        styles: styles,
        onPressBack: () => navigation.navigate('Messages'),
        onPressAttachment: () => {
            navigation.navigate('RecordVideo', {
                details: convo._details,
                videoInfo: convo._video,
                comingFromConversationPage: true,
            });
        },
        profilePic:
            user._userType === 'trainers'
                ? convo._details.client.profilePic
                : convo._details.trainer.profilePic,
        recipient:
            user._userType === 'trainers'
                ? convo._details.client.label
                : 'Coach ' + convo._details.trainer.label.split(' ')[0],
        module: convo._video.module,
        drill: convo._video.drill,
    };

    useEffect(() => {
        async function updateEdgeCase() {
            await updateLastReadMessageEdgeCase();
        }
        var updateConversation = () => {};
        if (convo._conversationID) {
            updateConversation = firestore()
                .collection('messages')
                .doc(convo._conversationID)
                .onSnapshot(documentSnapshot => {
                    var conversation = new Convo(
                        documentSnapshot.data()._conversationID,
                        documentSnapshot.data()._details,
                        documentSnapshot.data()._messages,
                        documentSnapshot.data()._video,
                    );
                    updateEdgeCase();
                    setConvo(conversation);
                });
        }
        return () => {
            updateConversation();
        };
    }, [convo, updateLastReadMessageEdgeCase]);

    return (
        <View style={{flex: 4, height: '100%', width: '100%'}}>
            <Conversation
                props={props}
                conversation={convo}
                user={user}
                navigation={navigation}
            />
        </View>
    );
}

export default ConversationScreen;
