//50% MY WORK
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
    topView: {
        //top view styles
        backgroundColor: 'white',
        height: '100%',
        flex: 1,
    },
    headerView: {
        //header view styles
        backgroundColor: '#E14821',
        position: 'absolute',
        top: 0,
        height: 176,
        width: '100%',
        borderBottomLeftRadius: 32,
        borderBottomRightRadius: 32,
    },
    backButtonView: {
        alignItems: 'flex-end',
        justifyContent: 'flex-end',
        marginRight: '8%',
        marginTop: '12%',
    },
    header: {
        flexDirection: 'row',
        height: '100%',
        marginLeft: '10%',
        marginBottom: '5%',
    },
    profilePic: {
        //styling for coach's profile picture in conversation page
        height: 72,
        width: 72,
        borderRadius: 36,
    },
    convoTitleView: {
        //styling for view holding the coach and drill
        marginLeft: '8%',
        marginTop: '2%',
    },
    coachTitle: {
        //styles for coach's name in conversation title
        fontFamily: 'AmericanAuto-Bold',
        fontSize: 26,
        textAlign: 'left',
        color: 'white',
    },
    drillTitle: {
        //styling for drill/level title
        fontFamily: 'AmericanAuto-Bold',
        fontSize: 16,
        textAlign: 'left',
        color: 'white',
    },
    messageInputAndSendView: {
        position: 'absolute',
        bottom: 0,
        marginBottom: 30,
        justifyContent: 'center',
        alignItems: 'center',
    },
});

export default styles;
