/* eslint-disable react-native/no-inline-styles */
import React, {useState, useEffect} from 'react';
import {View} from 'react-native';
import {MessageList} from '_organisms';
import {getUserOnAppSide} from '_utils';
import firestore from '@react-native-firebase/firestore';
import styles from './styles';

function MessagesScreen({navigation}) {
    const user = getUserOnAppSide(navigation);
    const [messages, setMessages] = useState([]);

    useEffect(() => {
        const getMessages = firestore()
            .collection('messages')
            .where(
                user._userType === 'trainers'
                    ? '_details.trainer.value'
                    : '_details.client.value',
                '==',
                user._userID,
            )
            .orderBy('_details.lastUpdated', 'desc')
            .onSnapshot(documentSnapshot => {
                console.log(documentSnapshot);
                var snapshotMessages = [];
                documentSnapshot.docs.forEach(doc => {
                    snapshotMessages.push({
                        conversationID: doc.data()._conversationID,
                        details: doc.data()._details,
                        messages: doc.data()._messages,
                        source:
                            user._userType === 'trainers'
                                ? doc.data()._details.client.profilePic
                                : doc.data()._details.trainer.profilePic,
                        video: doc.data()._video,
                    });
                });
                setMessages(snapshotMessages);
            });
        return () => getMessages();
    }, [user]);

    return (
        <View style={{flex: 1}}>
            <View style={{flex: 1}}>
                <MessageList
                    messages={messages}
                    user={user}
                    navigation={navigation}
                    styles={styles}
                    pageTitle="Inbox"
                />
            </View>
        </View>
    );
}

export default MessagesScreen;
