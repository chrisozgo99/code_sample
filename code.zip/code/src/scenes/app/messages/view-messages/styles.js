//NOT MY WORK
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
    topView: {
        //top view styles
        backgroundColor: '#FFFFFF',
        height: '100%',
    },
    headerView: {
        //header view styles
        backgroundColor: '#FFFFFF',
        //flex: 1,
        height: '20%',
    },
    headerTitle: {
        //styling for page title "Inbox"
        fontFamily: 'AmericanAuto-Bold',
        fontSize: 50,
        marginLeft: '10%',
        marginTop: '10%',
    },
    listView: {
        height: '80%',
    },
    convoTitleView: {
        //styling for view holding the coach and drill
        marginLeft: '5%',
        marginTop: '2%',
    },
    coachTitle: {
        //styles for coach's name in conversation title
        fontFamily: 'AmericanAuto-Bold',
        fontSize: 26,
        textAlign: 'left',
        color: 'white',
    },
    drillTitle: {
        //styling for drill/level title
        fontFamily: 'AmericanAuto-Bold',
        fontSize: 16,
        textAlign: 'left',
        color: 'white',
    },
    noMessagesStatement: {
        fontFamily: 'AmericanAuto-Regular',
        fontSize: 20,
        textAlign: 'center',
        margin: '5%',
    },
});

export default styles;
