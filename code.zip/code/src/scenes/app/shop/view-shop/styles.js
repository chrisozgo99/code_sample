//ABOUT 50% MY WORK
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
    topView: {
        backgroundColor: '#FFFF',
    },
    title: {
        marginTop: '6%',
        fontSize: 50,
        marginLeft: '10%',
        fontFamily: 'AmericanAuto-Bold',
        marginBottom: '51%',
    },
    shopStyles: {
        backgroundColor: '#E14821',
        justifyContent: 'center',
        alignItems: 'center',
        marginLeft: '10%',
        marginRight: '10%',
        borderRadius: 100,
    },
    buttonView: {
        width: '100%',
        justifyContent: 'center',
        alignItems: 'center',
    },
    shopButtonTextStyles: {
        fontFamily: 'AmericanAuto-Bold',
        fontSize: 26,
        color: '#FFFF',
        textAlign: 'center',
    },
    bgView: {
        marginTop: '30%',
        height: '85%',
        width: '100%',
        position: 'absolute',
        opacity: 1,
        resizeMode: 'cover',
    },
    bgImage: {
        height: '100%',
        width: '100%',
    },
});

export default styles;
