//ABOUT 50% MY WORK
/* eslint-disable react-native/no-inline-styles */
import React from 'react';
import {View, Text, Linking} from 'react-native';
import {TouchableOpacitySVG, BackgroundImage} from '_atoms';

import Shop from '_assets/images/app/shop/visit-shop.svg';

import styles from './styles';

function ShopScreen({navigation}) {
    return (
        <View style={{flex: 1, height: '100%', backgroundColor: 'white'}}>
            <BackgroundImage
                bgView={styles.bgView}
                bgImage={styles.bgImage}
                bg={require('./Blurred-shop.png')}
            />
            <View style={{flex: 1}}>
                <Text style={styles.title}>
                    {'\n'}Shop{'\n'}
                </Text>
                <View style={styles.buttonView}>
                    <TouchableOpacitySVG
                        svg={<Shop />}
                        onPress={() => {
                            Linking.openURL('http://iwantskills.com/shop');
                        }}
                    />
                </View>
            </View>
        </View>
    );
}

export default ShopScreen;
