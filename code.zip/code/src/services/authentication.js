//I wrote or helped write a lot of these functions.
//I have commented above each function whether or not I wrote it and whether or not someone on my team helped.

//This file deals with functions relating to authentication of a user
import {Alert} from 'react-native';
import firestore from '@react-native-firebase/firestore';
import messaging from '@react-native-firebase/messaging';
import {firebase} from '@react-native-firebase/app';
import auth from '@react-native-firebase/auth';
import Coach from '_utils/users/coach';
import Player from '_utils/users/player';
import Trainer from '_utils/users/trainer';
import {createNewStripeCustomer} from './stripe-calls';
import {removeTokenFromDatabase} from './push-notifications';
import analytics from '@react-native-firebase/analytics';

//I helped write this function with another member of my team
/**
 * Creates a new user with a name, email, and password. The function first checks that firstName and lastName
 * fields are not empty, then proceeds to create a new user with the assigned email and password from the text fields.
 * It then assigns that user the firstName and lastName passed in as parameters, and if there are no errors with this
 * process, it navigates to the page taken as a parameter
 *
 * @param {*} email The new user's email address
 * @param {*} password The new user's password
 * @param {*} firstName The new user's first name
 * @param {*} lastName The new user's last name
 * @param {*} {navigation} Parameter allowing navigation to be called from within the function, for timing purposes
 * @param {*} nav Page to which the user should navigate too, if everything is successful
 * @param {*} userType is the string representing the user type selected.
 */
async function createNewUserIsSuccessful(
    email,
    password,
    firstName,
    lastName,
    {navigation},
    nav,
    userType,
) {
    if (!firstName) {
        return Alert.alert('Please enter a first name');
    } else if (!lastName) {
        return Alert.alert('Please enter a last name');
    } else if (!email) {
        return Alert.alert('Please enter an email');
    } else if (!password) {
        return Alert.alert('Please enter a password');
    }

    const token = await messaging().getToken();

    let newUser;

    auth()
        .createUserWithEmailAndPassword(email, password)
        .then(() => {
            if (userType === 'coaches') {
                newUser = new Coach(
                    firstName,
                    lastName,
                    email,
                    firebase.auth().currentUser.uid,
                    '',
                    [token],
                    null,
                    null,
                    null,
                );
            } else if (userType === 'players') {
                newUser = new Player(
                    firstName,
                    lastName,
                    email,
                    firebase.auth().currentUser.uid,
                    '',
                    [token],
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                );
            } else if (userType === 'trainers') {
                newUser = new Trainer(
                    firstName,
                    lastName,
                    email,
                    firebase.auth().currentUser.uid,
                    '',
                    [token],
                    null,
                    null,
                );
            }
            firestore()
                .collection(userType)
                .doc(firebase.auth().currentUser.uid)
                .set(newUser);
        })
        .then(() => {
            firebase.auth().currentUser.updateProfile({
                displayName: firstName + ' ' + lastName,
            });
        })
        // The coach and the players should be the only ones that need customer accounts.
        .then(() => {
            if (userType === 'players' || userType === 'coaches') {
                let newStripeCustomer = createNewStripeCustomer(
                    firstName + ' ' + lastName,
                    email,
                );
                newStripeCustomer.then(response => {
                    console.log(response);
                    newUser._stripeInfo = {
                        customerID: response.id,
                        subscriptionID: null,
                        productID: null,
                    };
                    firestore()
                        .collection(userType)
                        .doc(firebase.auth().currentUser.uid)
                        .set(newUser);
                });
            }
        })
        .then(() => {
            navigation.navigate(nav, {
                user: newUser,
            });
        })
        .catch(error => {
            if (error.code === 'auth/email-already-in-use') {
                Alert.alert('That email address is already in use.');
            } else if (error.code === 'auth/invalid-email') {
                Alert.alert('Please enter a valid email address');
            } else if (error.code === 'auth/weak-password') {
                Alert.alert(
                    'The password is too weak. Your password should contain at least 6 characters.',
                );
            } else {
                Alert.alert(error);
            }
        });
}

//I wrote this function
/**
 * Signs in a user with an email and password. Returns a string representing an error if there were any. If there are not any errors,
 * it calls firebase.auth() to authenticate the user. All errors are handdled based on documentation here.
 * https://firebase.google.com/docs/reference/js/firebase.auth.Auth#signinwithemailandpassword.
 *
 * @param {*} email represents the email of the user attempting to log in
 * @param {*} password represents the password of the user trying to log in
 * @returns a promise representing the error message that arises during the process. If no errors, it will return the userObject.
 */
async function signInUser(email, password) {
    if (!email) {
        return Alert.alert('No email entered. Please enter an email.');
    } else if (!password) {
        return Alert.alert('No password. Please enter a password');
    }

    const userInfo = firebase
        .auth()
        .signInWithEmailAndPassword(email, password)
        .catch(error => {
            if (error.code === 'auth/wrong-password') {
                return Alert.alert('Incorrect password. Please try again');
            } else if (error.code === 'auth/invalid-email') {
                return Alert.alert('Invalid Email');
            } else if (error.code === 'auth/user-not-found') {
                return Alert.alert('Username not found. Please try again.');
            } else {
                return Alert.alert(error);
            }
        });
    return userInfo;
}

//I helped write this function with another member of my team
/**
 * Function that generates an Object of type according to the userType. If the user logging in is a player,
 * it will instantiate a Player object with all of that player's attributes and pass it App-side. If the
 * user is trainer, it will instantiate a Trainer object with all of that trainer's attributes and pass it
 * App-side. If the user is a coach, it will instantiate a Coach object and pass it App-side. The function
 * queries the entire players collection, followed by the entire coach collection, followed by the trainers
 * collection to search for the user because this is the order of likelihood that the user is of one of those
 * types. Kind of inefficient, but we cannot think of a better way to do this currently. Current issue is that
 * if it finds the user in the players collection, it still queries coach and trainer collections as well. It
 * should probably be simplified to 3 different functions that are called in Login as 3 if statements cascading
 * down.
 *
 * @param {*} {navigation} Allows navigation to occur from within the function
 * @param {*} nav The navigator which should be navigated to
 */
function generateUserForLogin({navigation}, nav) {
    analytics()
        .logLogin({method: 'email'})
        .then(event => {
            console.log(event);
            firestore()
                .collection('players')
                .doc(firebase.auth().currentUser.uid)
                .get()
                .then(player => {
                    if (player.exists) {
                        const p = player._data;
                        const loggedInUser = new Player(
                            p._name.firstName,
                            p._name.lastName,
                            p._email,
                            p._userID,
                            p._profilePic,
                            p._tokens,
                            p._playerInfo.height,
                            p._playerInfo.weight,
                            p._playerInfo.domHand,
                            p._playerInfo.position,
                            p._playerInfo.skillLevel,
                            p._playerInfo.dateOfBirth,
                            p._playerInfo.gender,
                            p._stripeInfo,
                        );
                        navigation.navigate(nav, {
                            user: loggedInUser,
                        });
                    }
                });
            firestore()
                .collection('coaches')
                .doc(firebase.auth().currentUser.uid)
                .get()
                .then(coach => {
                    if (coach.exists) {
                        console.log('Coach exists');
                        const c = coach._data;
                        const loggedInUser = new Coach(
                            c._name.firstName,
                            c._name.lastName,
                            c._email,
                            c._userID,
                            c._profilePic,
                            c._tokens,
                            c._yearsExp,
                            c._gender,
                            c._stripeInfo,
                        );
                        navigation.navigate(nav, {
                            user: loggedInUser,
                        });
                    }
                });
            firestore()
                .collection('trainers')
                .doc(firebase.auth().currentUser.uid)
                .get()
                .then(trainer => {
                    if (trainer.exists) {
                        console.log('Trainer exists');
                        const t = trainer._data;
                        const loggedInUser = new Trainer(
                            t._name.firstName,
                            t._name.lastName,
                            t._email,
                            t._userID,
                            t._profilePic,
                            t._tokens,
                            t._yearsExp,
                            t._gender,
                        );
                        navigation.navigate(nav, {
                            user: loggedInUser,
                        });
                    }
                });
        });
}

//I did not write this function
/**
 * A function to check if the user is logged in or not. If they are logged in, user will be a user object. If not, it will be null, which is a falsy value.
 *
 * @returns a boolean representing if a user is logged in or not.
 */
function userIsSignedIn() {
    let user = firebase.auth().currentUser;
    if (user) {
        return true;
    } else {
        return false;
    }
}

//I did not write this function
/**
 * An asyncronous function that requests that a password reset email be sent to the email passed in. It handles the email error of no email being entered, as well
 * as errors from the firebase function. Returns them as a promise representing the string.
 *
 * @param {*} email is a string representing the email that the password reset email is going to be sent to.
 * @returns a promise that, once fufiled, represents the string of any errors that occured. If no errors occured, then it return null.
 */
async function requestPasswordResetEmail(email) {
    if (!email) {
        return 'No email entered. Please enter an email.';
    }

    const resposeInfo = firebase
        .auth()
        .sendPasswordResetEmail(email)
        .catch(error => {
            if (error === 'auth/invalid-email') {
                return 'Invalid Email. Please enter a valid email.';
            } else if (error === 'auth/user-not-found') {
                return resposeInfo;
            } else {
                return 'Incorrect information.';
            }
        });
    return resposeInfo;
}

//I did not write this function
/**
 * Function for user to be able to log out and return to login screen.
 *
 * @param {*} {navigation} Allows for navigation from within the function
 * @param {*} nav Page to navigate to
 */
async function logOut(user, {navigation}, nav) {
    await removeTokenFromDatabase(user);

    firebase
        .auth()
        .signOut()
        .then(() => {
            navigation.navigate(nav);
        })
        .catch(error => {
            Alert.alert(error);
        });
}

//I did not write this function
/**
 * This function grabs the current user, creates a credential from the current email and
 * password (which you should ask the user for first) and then calls reauthenticateWithCredential,
 * which returns a promise.
 *
 * @param {*} currentPassword is the password of the current user logged in that you would like to reauthenticate.
 * @returns a promise representing the credential of the current user. Can also throw errors so make sure you catch.
 */
function reauthenticate(currentPassword) {
    var user = firebase.auth().currentUser;
    var cred = firebase.auth.EmailAuthProvider.credential(
        user.email,
        currentPassword,
    );
    return user.reauthenticateWithCredential(cred);
}

//I did not write this function
/**
 * Update your password using built in firebase user and then navigate away.
 *
 * @param {*} currentPassword is the current password of the current user logged in. Needed to reauthenticate the user
 * before changing their password.
 * @param {*} newPassword is the new password that the user wants.
 * @param {*} {navigation} is the navigation object so the user can navigate.
 */
function updatePassword(currentPassword, newPassword, {navigation}) {
    var user = firebase.auth().currentUser;

    reauthenticate(currentPassword)
        .then(() => {
            user.updatePassword(newPassword)
                .then(() => {
                    navigation.navigate('ViewProfile');
                })
                .catch(error => Alert.alert(error.message));
        })
        .catch(error => Alert.alert(error.message));
}

export {
    createNewUserIsSuccessful,
    signInUser,
    generateUserForLogin,
    userIsSignedIn,
    requestPasswordResetEmail,
    logOut,
    updatePassword,
};
