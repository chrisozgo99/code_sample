//I wrote the first two functions in this file and did not write the last two

//This file contains functions related to the training modules in the database
import firestore from '@react-native-firebase/firestore';

async function getTrainingModuleFromDatabase(module) {
    const coverPhotos = [
        require('_assets/images/app/training/module/image5.png'),
        require('_assets/images/app/training/module/image4.png'),
        require('_assets/images/app/training/module/image13.png'),
        require('_assets/images/app/training/module/image2.png'),
        require('_assets/images/app/training/module/image9.png'),
        require('_assets/images/app/training/module/image6.png'),
        require('_assets/images/app/training/module/image10.png'),
        require('_assets/images/app/training/module/image11.png'),
        require('_assets/images/app/training/module/image3.png'),
        require('_assets/images/app/training/module/image7.png'),
        require('_assets/images/app/training/module/image1.png'),
        require('_assets/images/app/training/module/image8.png'),
        require('_assets/images/app/training/module/image12.png'),
        require('_assets/images/app/training/module/image14.png'),
    ];
    return await firestore()
        .collection('modules')
        .where('module.name', '==', module)
        .get()
        .then(returnedModule => {
            const data = returnedModule._docs[0].data();
            var counter = 0;
            for (var vid in data.module.videos) {
                data.module.videos[vid].data.forEach(video => {
                    video.thumbnail = coverPhotos[counter];
                    counter++;
                    if (counter >= coverPhotos.length) {
                        counter = 0;
                    }
                });
            }
            return data;
        });
}

async function getListOfModulesFromDatabase(user) {
    const coverPhotos = [
        require('_assets/images/app/training/dribble-moves.png'),
        require('_assets/images/app/training/finishing.png'),
        require('_assets/images/app/training/defense.png'),
        require('_assets/images/app/training/ball-handling.png'),
        require('_assets/images/app/training/basketball-iq.png'),
        require('_assets/images/app/training/elite-guard-play.png'),
        require('_assets/images/app/training/shooting.png'),
    ];

    return await firestore()
        .collection('modules')
        .where(
            'module.userType',
            '==',
            user._userType === 'coaches' ? 'coaches' : 'players',
        )
        .get()
        .then(modules => {
            var listOfModules = [];
            var counter = 0;
            modules._docs.forEach(doc => {
                if (doc._data.module.name !== 'Jumpshot Tutor') {
                    listOfModules.push({
                        title: doc._data.module.name,
                        coverPhoto: coverPhotos[counter],
                    });
                    counter++;
                    if (counter >= coverPhotos.length) {
                        counter = 0;
                    }
                }
            });
            return listOfModules;
        });
}
async function getWeeklyChallengeFromDatabase() {
    return await firestore()
        .collection('challenge')
        .get()
        .then(query => {
            //console.log(query);
            var listOfChallenges = [];
            query.forEach(doc => {
                listOfChallenges.push({
                    text: doc.data().challenge,
                    date: doc.data().date,
                    // data: doc.data(),
                });
            });
            return listOfChallenges;
        })
        .catch(function(error) {
            throw error;
        });
}
async function getLivestreamFromDatabase() {
    return await firestore()
        .collection('livestream')
        .get()
        .then(query => {
            //console.log(query);
            var listOfLivestreams = [];
            query.forEach(doc => {
                listOfLivestreams.push({
                    link: doc.data().link,
                    date: doc.data().date,
                    name: doc.data().name,
                });
            });
            return listOfLivestreams;
        })
        .catch(function(error) {
            throw error;
        });
}

export {
    getTrainingModuleFromDatabase,
    getListOfModulesFromDatabase,
    getWeeklyChallengeFromDatabase,
    getLivestreamFromDatabase,
};
