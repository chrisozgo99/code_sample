//NOT MY WORK
import functions from '@react-native-firebase/functions';
import {Subscription} from '_utils';
import {setUserInDatabase} from '../services/db-calls';

/**
 *This Function is to play around with stripe api to figure out if it works
 *
 */
function fetchProduct() {
    return functions()
        .httpsCallable('helloWorld')()
        .then(response => {
            console.log(response);
        });
}

function createNewSubscriptionObject(productId, priceId) {
    console.log('Reached Create new subscription');
    return functions()
        .httpsCallable('retriveStripeProduct')({id: productId})
        .then(response => {
            var id, name, image, description, price;
            id = response.data.id;
            name = response.data.name;
            image = response.data.images;
            description = response.data.description;
            console.log(
                'Reached one inner loop. ' + id + name + image + description,
            );
            return functions()
                .httpsCallable('retriveStripePrice')({id: priceId})
                .then(response => {
                    console.log('Reached even more inner product');
                    price = response.data.unit_amount;
                    return new Subscription(
                        id,
                        name,
                        image,
                        description,
                        price,
                    );
                });
        });
}

// TODO: Add error suppression or error handling.
/**
 * Create a new Stripe customer object using the stripe API and cloud functions.
 *
 * @param {*} name a string representing the name of the new stripe customer.
 * @param {*} email a string representng the email of the new stripe customer.
 * @returns a promise that when resolved, represents the newly created customer object.
 */
function createNewStripeCustomer(name, email) {
    return functions()
        .httpsCallable('createNewStripeCustomer')({
            // name: name,
            // email: email,
        })
        .then(response => {
            return response.data;
        });
}

function updateDefaultPayment(sourceID, customerID) {
    // TODO: Delete duplicate cards
    return functions()
        .httpsCallable('updateDefaultPayment')({
            customer: customerID,
            sourceID: sourceID,
        })
        .then(customer => {
            return customer;
        })
        .catch(err => {
            console.log(err);
        });
}

async function signUpForSubscription(
    customerId,
    cardInfo,
    subscription,
    navigation,
    user,
) {
    return functions()
        .httpsCallable('createToken')({card: cardInfo})
        .then(token => {
            console.log(token);
            return functions()
                .httpsCallable('createSource')({
                    customerId: customerId,
                    source: token.data.id,
                })
                .then(source => {
                    console.log(source);
                    return updateDefaultPayment(source.data.id, customerId)
                        .then(customer => {
                            console.log(customer);
                            return functions()
                                .httpsCallable('signUpForSubscription')({
                                    customer: customerId,
                                    priceId: subscription._priceId,
                                })
                                .then(createdSub => {
                                    console.log(createdSub);
                                    console.log('User');
                                    console.log(user);
                                    user._stripeInfo.subscriptionID =
                                        createdSub.data.id;
                                    user._stripeInfo.productID =
                                        subscription._id;
                                    setUserInDatabase(user).then(() => {
                                        navigation.navigate('Membership');
                                    });
                                    // FIXME: Record somewhere that this person has paid.
                                });
                        })
                        .catch(err => {
                            console.log(err);
                        });
                })
                .catch(err => {
                    console.log(err);
                });
        })
        .catch(err => {
            console.log(err);
        });
}

/**
 * This function is to complete a purchase of any non-reaccuring payment
 *
 * @param {*} customerId Represents the customer id that is purchasing
 * @param {*} cardInfo
 * @returns
 */
async function purchaseProduct(
    customerId,
    cardInfo,
    priceId,
    navigation,
    productID,
    user,
) {
    return functions()
        .httpsCallable('createToken')({card: cardInfo})
        .then(token => {
            console.log(token.data.id);
            return (
                functions()
                    .httpsCallable('createSource')({
                        customerId: customerId,
                        source: token.data.id,
                    })
                    // TODO: Check if person already has card on file.
                    .then(source => {
                        console.log('got to function to update defualt');
                        return updateDefaultPayment(
                            source.data.id,
                            customerId,
                        ).then(customer => {
                            console.log(customer);
                            return functions()
                                .httpsCallable('createInvoiceItem')({
                                    customerID: customerId,
                                    priceID: priceId,
                                })
                                .then(invoiceItem => {
                                    console.log(invoiceItem);
                                    return functions()
                                        .httpsCallable('createInvoice')({
                                            customerID: customerId,
                                        })
                                        .then(invoice => {
                                            console.log(invoice);
                                            return functions()
                                                .httpsCallable('payInvoice')({
                                                    invoiceID: invoice.data.id,
                                                })
                                                .then(invoicePaid => {
                                                    if (
                                                        invoicePaid.data
                                                            .status === 'paid'
                                                    ) {
                                                        user._stripeInfo.productID = productID;
                                                        setUserInDatabase(
                                                            user,
                                                        ).then(() => {
                                                            navigation.navigate(
                                                                'Membership',
                                                            );
                                                        });
                                                    }
                                                })
                                                .catch(err => {
                                                    console.log(err);
                                                });
                                        })
                                        .catch(err => {
                                            console.log(err);
                                        });
                                });
                        });
                    })
                    .catch(err => {
                        console.log(err);
                    })
                    .catch(err => {
                        console.log(err);
                    })
            );
        })
        .catch(err => {
            console.log(err);
        });
}

// TODO: Add any error handling/ suppression needed.
/**
 * Calls stripe to find the most recent info about a specifc customer and then copys
 * that information to firebase.
 *
 * @param {*} user is the front end user object that is being updated.
 * @returns a promise that when resolved will have updated the users information in 
 * firebase to match the stripe info.
 */
function updateStripeInfoOnFirebase(user) {
    return functions()
        .httpsCallable('retrieveCustomer')({customer: user._stripeInfo.id})
        .then(stripeCustomer => {
            console.log(stripeCustomer.data);
            user._stripeInfo = stripeCustomer.data;
            setUserInDatabase(user);
        });
}

async function generateMembershipList() {
    return functions()
        .httpsCallable('listAllProducts')()
        .then(productList => {
            var listOfSubscriptions = [];
            for (var i = 0; i < productList.data.data.length; i++) {
                var tempSub = new Subscription(
                    productList.data.data[i].id,
                    productList.data.data[i].name,
                    productList.data.data[i].description,
                    null,
                    null,
                    null,
                    productList.data.data[i].metadata._userType,
                );
                listOfSubscriptions.push(tempSub);
            }
            return generatePriceList(listOfSubscriptions).then(
                completedSubObjects => {
                    return completedSubObjects;
                },
            );
        });
}

async function generatePriceList(subscriptionList) {
    return functions()
        .httpsCallable('retriveAllPrices')()
        .then(priceList => {
            for (var i = 0; i < subscriptionList.length; i++) {
                for (var j = 0; j < priceList.data.data.length; j++) {
                    if (
                        priceList.data.data[j].product ===
                        subscriptionList[i]._id
                    ) {
                        subscriptionList[i]._priceId =
                            priceList.data.data[j].id;
                        subscriptionList[i]._priceType =
                            priceList.data.data[j].type;
                        subscriptionList[i]._price =
                            priceList.data.data[j].unit_amount_decimal;
                    }
                }
            }
            return subscriptionList;
        });
}

function getSubscriptionInfo(subscriptionID, productID) {
    if (subscriptionID === null) {
        return functions()
            .httpsCallable('getProductInfo')({productID: productID})
            .then(product => {
                console.log(product);
            });
    } else {
        return functions()
            .httpsCallable('getSubscriptionInfo')({
                subscriptionID: subscriptionID,
            })
            .then(subscription => {
                // console.log(subscription);
                return functions()
                    .httpsCallable('getProductInfo')({
                        productID: productID,
                    })
                    .then(product => {
                        // console.log(product);
                        let formattedSubscription = new Subscription(
                            product.data.id,
                            product.data.name,
                            product.data.description,
                            subscription.data.plan.id,
                            'recurring',
                            subscription.data.plan.amount,
                            product.data.metadata._userType,
                        );
                        return {
                            formattedSub: formattedSubscription,
                            fullSubInfo: subscription.data,
                        };
                    });
            });
    }
}

export {
    fetchProduct,
    createNewSubscriptionObject,
    createNewStripeCustomer,
    updateStripeInfoOnFirebase,
    generateMembershipList,
    purchaseProduct,
    signUpForSubscription,
    getSubscriptionInfo,
};
