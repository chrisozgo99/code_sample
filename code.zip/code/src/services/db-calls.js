//I wrote both of these functions

//This file contains miscellaneous database-related functions
import {Alert} from 'react-native';
import firestore from '@react-native-firebase/firestore';

/**
 * Update the datbase with a specific usertype and the based on a user object. Will overwrite all existing information
 * in the existing document with the new information in the user object passed in.
 *
 * @param {*} userType Type of user: either player, coach, or trainer
 * @param {*} userObject The object representing the user
 * @param {*} {navigation} Allows for navigation from within the function
 * @param {*} nav The page to which should be navigated
 */
async function setDatabaseInfo(userType, userObject, {navigation}, nav) {
    var pushedObject = userObject;
    var pushedObjectTokens = userObject._tokens;
    var uniqueTokens = [];
    for (var i = 0; i < pushedObjectTokens.length; i++) {
        if (!uniqueTokens.includes(pushedObjectTokens[i])) {
            uniqueTokens.push(pushedObjectTokens[i]);
        }
    }
    pushedObject._tokens = uniqueTokens;
    await firestore()
        .collection(userType)
        .doc(userObject._userID)
        .set(userObject)
        .then(() => {
            navigation.navigate(nav, {
                user: userObject,
            });
        })
        .catch(err => {
            Alert.alert(err);
        });
}

/**
 * Utility function that is used quite a bit in other database calls. Takes a user as a parameter
 * and sets that user in the appropriate spot in the database. A .then() can be chained off of this
 * function as well, allowing you to insert it into another function and continue your code.
 *
 * @param {*} user The user that will be set in the database
 * @returns A user being set in the database
 */
async function setUserInDatabase(user) {
    return await firestore()
        .collection(user._userType)
        .doc(user._userID)
        .set(user);
}

export {setDatabaseInfo, setUserInDatabase};
