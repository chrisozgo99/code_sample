export {setDatabaseInfo, setUserInDatabase} from './db-calls';

export {
    createNewUserIsSuccessful,
    signInUser,
    generateUserForLogin,
    userIsSignedIn,
    requestPasswordResetEmail,
    logOut,
    updatePassword,
} from './authentication';

export {
    pushImageToStorage,
    editImageInStorage,
    setDefaultImage,
} from './storage';

export {
    getTrainingModuleFromDatabase,
    getListOfModulesFromDatabase,
    getWeeklyChallengeFromDatabase,
    getLivestreamFromDatabase,
} from './training-modules';

export {
    addConversationToDatabase,
    updateConversation,
    updateConversationDetails,
    isConversationInDatabase,
    addVideoReferenceToConversation,
    updateLastReadMessage,
    updateLastReadMessageInConversation,
    setTrainerToConversation,
} from './messages';

export {
    fetchProduct,
    createNewSubscriptionObject,
    createNewStripeCustomer,
    updateStripeInfoOnFirebase,
    generateMembershipList,
    purchaseProduct,
    signUpForSubscription,
    getSubscriptionInfo,
} from './stripe-calls';

export {
    requestUserPermission,
    saveTokenToDatabase,
    removeTokenFromDatabase,
    sendPushNotification,
    handleNotification,
} from './push-notifications';
