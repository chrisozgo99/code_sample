import User from './user';

/**
 * Player class definition. The player extends user and all of its attributes and methods.
 * In addition it has many more attributes including height, weight, dominant hand, position,
 * skill level, date of birth, and gender. The player will be able to edit any of these attributes
 * at any time within the app.
 * @class Player
 * @extends {User}
 */
class Player extends User {
    /**
     *Creates an instance of Player.
     * @param {*} firstName The Player's first name
     * @param {*} lastName The Player's last name
     * @param {*} email The Player's email
     * @param {*} userID The Player's unique userID
     * @param {*} profilePic The Player's profile picture
     * @param {*} tokens The device tokens the User is registered on
     * @param {*} height The Player's height
     * @param {*} weight The Player's weight
     * @param {*} domHand The Player's dominant hand
     * @param {*} position The Player's position
     * @param {*} skillLevel The Player's skill level
     * @param {*} dateOfBirth The Player's date of birth
     * @param {*} gender The Player's gender
     * @param {*} stripeInfo The players information related to stripe
     * @memberof Player
     */
    constructor(
        firstName,
        lastName,
        email,
        userID,
        profilePic,
        tokens,
        height,
        weight,
        domHand,
        position,
        skillLevel,
        dateOfBirth,
        gender,
        stripeInfo,
    ) {
        super(
            firstName,
            lastName,
            email,
            userID,
            'players',
            profilePic,
            tokens,
        );
        this._playerInfo = {
            height: height,
            weight: weight,
            domHand: domHand,
            position: position,
            skillLevel: skillLevel,
            dateOfBirth: dateOfBirth,
            gender: gender,
        };
        this._stripeInfo = stripeInfo;
    }

    /**
     * Allows the player to change their height
     * @param {any} newHeight
     */
    set height(newHeight) {
        this._playerInfo.height = newHeight;
    }

    /**
     * Allows the player to change their weight
     * @param {any} newWeight
     */
    set weight(newWeight) {
        this._playerInfo.weight = newWeight;
    }

    /**
     * Allows the player to change their dominant hand
     * @param {any} newDomHand
     */
    set domHand(newDomHand) {
        this._playerInfo.domHand = newDomHand;
    }

    /**
     * Allows the player to change their position
     * @param {any} newPosition
     */
    set position(newPosition) {
        this._playerInfo.position = newPosition;
    }

    /**
     * Allows the player to change their skill level
     * @param {any} newSkillLevel
     */
    set skillLevel(newSkillLevel) {
        this._playerInfo.skillLevel = newSkillLevel;
    }

    /**
     * Allows the player to change their date of birth
     * @param {any} newDateOfBirth
     */
    set dateOfBirth(newDateOfBirth) {
        this._playerInfo.dateOfBirth = newDateOfBirth;
    }

    /**
     * Allows the player to change their gender
     * @param {any} newGender
     */
    set gender(newGender) {
        this._playerInfo.gender = newGender;
    }

    /**
     * Allows the user to update all their information on the CompletePlayerProfileScreen.
     * Either in the design, or through restrictions that should be added to this function,
     * a player should not be allowed to enter false information. The method, as currently
     * constructed, does not account for these inevitable errors.
     *
     * @param {*} newHeight The Player's new height
     * @param {*} newWeight The Player's new weight
     * @param {*} newDomHand The Player's new dominant hand
     * @param {*} newPosition The Player's new position
     * @param {*} newSkillLevel The Player's new skill level
     * @param {*} newDateOfBirth The Player's new date of birth
     * @param {*} newGender The Player's new gender
     * @memberof Player
     */
    completeProfile(
        newHeight,
        newWeight,
        newDomHand,
        newPosition,
        newSkillLevel,
        newDateOfBirth,
        newGender,
    ) {
        this._playerInfo = {
            height: newHeight,
            weight: newWeight,
            domHand: newDomHand,
            position: newPosition,
            skillLevel: newSkillLevel,
            dateOfBirth: newDateOfBirth,
            gender: newGender,
        };
    }
}

export default Player;
