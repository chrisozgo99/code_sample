import User from './user';

/**
 * Coach class definition. The coach extends user and all of its attributes and methods.
 * In addition it has its own unique attributes: years of experience and gender. A coach
 * is still a client, like a player, but has access to a different set of videos than a
 * player.
 * @class Coach
 * @extends {User}
 */
class Coach extends User {
    /**
     *Creates an instance of Coach.
     * @param {*} firstName The Coach's first name
     * @param {*} lastName The Coach's last name
     * @param {*} email The Coach's email
     * @param {*} userID The Coach's unqiue userID
     * @param {*} profilePic The Coach's profile picture
     * @param {*} tokens The device tokens the User is registered on
     * @param {*} yearsExp The Coach's years of experience
     * @param {*} gender The Coach's gender
     * @memberof Coach
     */
    constructor(
        firstName,
        lastName,
        email,
        userID,
        profilePic,
        tokens,
        yearsExp,
        gender,
        stripeInfo,
    ) {
        super(
            firstName,
            lastName,
            email,
            userID,
            'coaches',
            profilePic,
            tokens,
        );
        this._yearsExp = yearsExp;
        this._gender = gender;
        this._stripeInfo = stripeInfo;
    }

    /**
     * Allows the coach to change their gender
     * @param {any} newGender
     */
    set gender(newGender) {
        this._gender = newGender;
    }

    set yearsExp(yearsExp) {
        this._yearsExp = yearsExp;
    }

    completeProfile(yearsExp, gender) {
        this._yearsExp = yearsExp;
        this._gender = gender;
    }
}

export default Coach;
