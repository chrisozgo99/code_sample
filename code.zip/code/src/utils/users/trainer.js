import User from './user';
/**
 * Trainer class definition. The trainer extends user and all of its attributes and methods.
 * In addition it has its own unique attributes: years of experience and gender. A trainer is
 * not a paying customer and rather provides feedback for players on their technique. Once implemented,
 * trainers will have different methods than players and coaches, although a trainer seems identical to
 * a coach right now.
 * @class Trainer
 * @extends {User}
 */
class Trainer extends User {
    /**
     *Creates an instance of Trainer.
     * @param {*} firstName The Trainer's first name
     * @param {*} lastName The Trainer's last name
     * @param {*} email The Trainer's eamil
     * @param {*} userID The Trainer's unique userID
     * @param {*} profilePic The Trainer's profile picture
     * @param {*} tokens The device tokens the User is registered on
     * @param {*} yearsExp The Trainer's number of yeras of experience
     * @param {*} gender The Trainer's gender
     * @memberof Trainer
     */
    constructor(
        firstName,
        lastName,
        email,
        userID,
        profilePic,
        token,
        yearsExp,
        gender,
    ) {
        super(
            firstName,
            lastName,
            email,
            userID,
            'trainers',
            profilePic,
            token,
        );
        this._yearsExp = yearsExp;
        this._gender = gender;
    }

    /**
     * Allows the trainer to change their gender
     * @param {any} newGender
     */
    set gender(newGender) {
        this._gender = newGender;
    }

    completeProfile(yearsExp, gender) {
        this._yearsExp = yearsExp;
        this._gender = gender;
    }
}

export default Trainer;
