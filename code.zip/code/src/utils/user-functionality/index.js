//I wrote or helped write some of these functions
//I have commented above each function whether or not I wrote it or if someone on my team helped.

import {updateConversationDetails} from '../../services/messages';
import {editImageInStorage} from '../../services/storage';
import {setDatabaseInfo} from '../../services/db-calls';
import {Platform} from 'react-native';

//I wrote this function
/**
 * Helper function to return a corresponding user object
 * on the app side of the component
 *
 * @param {*} props The properties of the functional component
 * @returns The properties of the functional component
 */
function getProps(props) {
    return props;
}

//I wrote this function
/**
 * Function to return the user object corresponding to the logged-in
 * user on App. Works for all top level scenes within each each stack
 * navigation of the bottom tab navigator
 *
 * @param {*} props the properties of the functional component
 * @returns The corresponding user object to the user who is logged in
 */
function getUserOnAppSide(props) {
    return getProps(props)
        .dangerouslyGetParent()
        .dangerouslyGetParent().state.params.user;
}

//I wrote this function
/**
 * Function to return user object corresponding to logged-in user on App.
 * Works for all pages within TrainingModulesNavigator.
 *
 * @param {*} props the properties of the functional component
 * @returns The corresponding user object to the user who is logged in
 */
function getUserOnTrainingPages(props) {
    return getProps(props)
        .dangerouslyGetParent()
        .dangerouslyGetParent()
        .dangerouslyGetParent().state.params.user;
}

//I wrote this function
/**
 * Function that collects all the information on the Edit Profile page and
 * maps it to the current user Object on the App side. It then calls another
 * function, setDatabaseInfo, to map the updated user object to the corresponding
 * place in the database. Finally it navigates back to a desired screen.
 *
 * @param {*} user The current user object
 * @param {*} profilePic The location in storage of the user's profile pic
 * @param {*} userTitles Array of attributes that all users share
 * @param {*} playerTitles Array of player-specific attributes
 * @param {*} coachTitles Array of coach-specific attributes
 * @param {*} trainerTitles Array of trainer-specific attributes
 * @param {*} {navigation} Allows for navigation from within the function
 * @param {*} nav The page to which the function should navigate
 */
function collectEditInfo(
    user,
    profilePic,
    userTitles,
    playerTitles,
    coachTitles,
    trainerTitles,
    {navigation},
    nav,
) {
    user._name.firstName = userTitles[0].value;
    user._name.lastName = userTitles[1].value;
    editImageInStorage(profilePic, user)
        .then(() => {
            if (
                profilePic ===
                'https://firebasestorage.googleapis.com/v0/b/drills-and-skills.appspot.com/o/images%2Fprofile-pics%2Fblank-profile-picture.png?alt=media&token=86e354ea-5008-41e4-b7ba-0f3486b13fb8'
            ) {
                user._profilePic = profilePic;
            }
            if (user._userType === 'players') {
                return playerTitles.map(attr => {
                    console.log(attr);
                    const val = attr.attribute;
                    user._playerInfo[val] = attr.value;
                });
            } else if (user._userType === 'coaches') {
                return coachTitles.map(attr => {
                    const val = attr.attribute;
                    user[val] = attr.value;
                });
            } else if (user._userType === 'trainers') {
                return trainerTitles.map(attr => {
                    const val = attr.attribute;
                    user[val] = attr.value;
                });
            }
        })
        .then(() => {
            updateConversationDetails(user);
        })
        .then(() => {
            setDatabaseInfo(user._userType, user, {navigation}, nav);
        })
        .catch(error => console.log(error));
}

//I did not write this function
function convertTimestampToReadableDate(timestamp) {
    var currentTime = Date.now();
    var currentDate = new Date(currentTime).toLocaleDateString();
    var timestampDate = new Date(timestamp).toLocaleDateString();
    var yesterday = new Date(
        currentTime - 1000 * 60 * 60 * 24,
    ).toLocaleDateString();
    if (currentDate === timestampDate) {
        var date = new Date(timestamp).toLocaleTimeString();
        const dateComponents = date.split(':');
        if (Platform.OS === 'ios') {
            const amOrPM = dateComponents[2].split(' ')[1];
            return dateComponents[0] + ':' + dateComponents[1] + ' ' + amOrPM;
        } else {
            if (dateComponents[0] < 13) {
                return dateComponents[0] + ':' + dateComponents[1] + ' AM';
            } else {
                const formattedHour = dateComponents[0] - 12;
                return formattedHour + ':' + dateComponents[1] + ' PM';
            }
        }
    } else if (timestampDate === yesterday) {
        return 'Yesterday';
    } else {
        return timestampDate;
    }
}

export {
    getUserOnAppSide,
    collectEditInfo,
    getUserOnTrainingPages,
    convertTimestampToReadableDate,
};
