//NOT MY WORK
/**
 * Message class definition representing an individual message sent from a user. Each message belongs
 * to a specific conversation (tracked by conversationID) and holds information of
 * when the message was sent and who sent the message.
 *
 * @class Message
 */
class Message {
    /**
     *Creates an instance of Message.
     * @param {*} content contents of message
     * @param {*} sentBy ID of user that sent the message
     * @param {*} sentAt timestamp of message
     * @memberof Message
     */
    constructor(content, sentBy, sentAt) {
        this._content = {
            type: content.type,
            contents: content.contents,
        };
        this._sentBy = sentBy;
        this._sentAt = sentAt;
    }
}

export default Message;
