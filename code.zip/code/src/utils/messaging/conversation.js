//ABOUT 50% MY WORK

import {
    addConversationToDatabase,
    updateConversation,
} from '../../services/messages';

var uuid = require('react-native-uuid');

/**
 * Conversation class definition representing one conversation on the messages page of the app.
 * Each conversation occurs between a client (paying player/coach) and one of Paul's trainers,
 * and pertains to a specific drill module.
 *
 * @class Conversation
 */
class Conversation {
    /**
     *Creates an instance of Conversation.
     * @param {*} conversationID conversation's unique ID from database
     * @param {*} client player or coach ("client") of the conversation
     * @param {*} trainer Paul's trainer of the conversation
     * @param {*} message first message sent in the conversation
     * @param {*} video an object contain all the specific details of the associated training video
     * @param {*} lastUpdated timestamp of most recent message in conversation
     * @memberof Conversation
     */
    constructor(conversationID, details, messages, video) {
        this._conversationID = conversationID;
        if (messages === null) {
            this._messages = [];
        } else {
            this._messages = messages;
        }
        this._video = {
            module: video.module,
            level: video.level,
            drill: video.drill,
        };
        this._details = {
            client: details.client,
            trainer: details.trainer,
            lastUpdated: details.lastUpdated,
        };
    }

    /**
     * Allows a message to be added to the messages array in the conversation. If the messages array is zero (first message
     * being added to conversation), the message is added then the conversation is added to the messages collection in the database.
     * If the message is not the first in the array, the message is added to the array then the conversation is updated in the database.
     * Also updates lastUpdated field based off when the passed in message was sent.
     *
     * @param {*} message message added to conversation
     * @memberof Conversation
     */
    async addMessage(message) {
        this._details.lastUpdated = message._sentAt;
        if (this._messages.length === 0) {
            this._messages.push(message);
            await addConversationToDatabase(this);
        } else {
            this._messages.unshift(message);
            await updateConversation(this);
        }
    }

    /**
     * Allows a message to be added to the messages array in the conversation. Also updates the lastUpdated
     * field based off when the passed in message was sent. This method does not update the conversation in
     * the database and should only be used when multiple messages are being sent at once, such as when a
     * player sends both a video message and a text message at the same time, and they should both be updated
     * in Firebase simultaneously at a later point in time.
     *
     * @param {*} message message added to conversation
     * @memberof Conversation
     */
    addMessageWithoutPushingToDatabase(message) {
        this._details.lastUpdated = message._sentAt;
        this._messages.unshift(message);
    }

    /**
     * Assigns a trainer to the specific conversation
     * @param {*} newTrainer the trainer assigned to the conversation
     * @memberof Conversation
     */
    set trainer(newTrainer) {
        this._details.trainer = newTrainer;
    }
}

export default Conversation;
