//NOT MY WORK
class BillingInfo {
    constructor(name, email, phone, address, city, state, zip) {
        this._name = name;
        this._email = email;
        this._phone = phone;
        this._address = address;
        this._city = city;
        this._state = state;
        this._zip = zip;
    }
    validateBilling() {
        // These are regex leterals that check and see if the inputed date matchs up.
        const Email = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        const Phone = /^\s*(?:\+?(\d{1,3}))?[-. (]*(\d{3})[-. )]*(\d{3})[-. ]*(\d{4})(?: *x(\d+))?\s*$/;
        const ZipCode = /(^\d{5}$)|(^\d{5}-\d{4}$)/;
        return {
            name: this._name === null || this._name === '',
            email:
                this._name === null ||
                this._name === '' ||
                !Email.test(String(this._email).toLowerCase()),
            phone:
                this._phone === null ||
                this._phone === '' ||
                !Phone.test(String(this._phone)),
            address: this._address === null || this._address === '',
            city: this._city === null || this._city === '',
            state:
                this._state === null ||
                this._state === '' ||
                this._state.length !== 2,
            zip:
                this._zip === null ||
                this._zip === '' ||
                !ZipCode.test(String(this._zip)),
        };
    }
}

export default BillingInfo;
