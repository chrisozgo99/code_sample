//NOT MY WORK
class Subscription {
    /**
     * Creates an instance of Subscription.
     * @param {*} id is the product id from stripe
     * @param {*} name is the name of the product from stripe
     * @param {*} description is the description of the product from stripe
     * @param {*} priceId is the id of the stripe price object
     * @param {*} priceType is wether or not the payment is reocurring or not.
     * @param {*} price is the price of the subscription
     * @param {*} userType is the userType of the subscription object
     * @memberof Subscription
     */
    constructor(id, name, description, priceId, priceType, price, userType) {
        this._id = id;
        this._name = name;
        this._description = description;
        this._priceId = priceId;
        this._priceType = priceType;
        this._price = price;
        this._userType = userType;
    }
}

export default Subscription;
